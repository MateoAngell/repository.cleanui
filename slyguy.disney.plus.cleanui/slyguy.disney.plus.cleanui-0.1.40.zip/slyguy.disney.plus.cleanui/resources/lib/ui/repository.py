import traceback
import unicodedata

import xbmc

from .models import Card, Rail, Screen
from . import constants as C


_core = None

# enhanced_limit unificado para consultas de entidad, de modo que la misma
# página se reutilice desde la caché compartida (movie/show/season detail).
ENTITY_ENHANCED_LIMIT = 30


def _get_core():
    global _core
    if _core is None:
        import resources.lib.plugin as plugin_module
        _core = plugin_module
    return _core


def _log(context, exc=None):
    if exc is None:
        detail = traceback.format_exc()
    else:
        detail = '{}\n{}'.format(exc, traceback.format_exc())

    xbmc.log(
        '[CLEANUI] repository.{}:\n{}'.format(context, detail),
        xbmc.LOGERROR,
    )


def _item_path(item):
    return getattr(item, 'path', '') or ''


def _item_art(item):
    return getattr(item, 'art', {}) or {}


def _item_info(item):
    return getattr(item, 'info', {}) or {}


def _item_label(item):
    return getattr(item, 'label', '') or ''


def _item_context(item):
    return list(getattr(item, 'context', []) or [])


class Repository(object):

    def _containers(self, info):
        """Accept both the real uppercase key and legacy lowercase key."""
        core = _get_core()
        return (
            info.get(core.CONTAINERS)
            or info.get('CONTAINERS')
            or info.get('containers')
            or {}
        )

    def _actions(self, info):
        core = _get_core()
        return (
            info.get(core.ACTIONS)
            or info.get('ACTIONS')
            or info.get('actions')
            or {}
        )

    def _normalize_art(self, art):
        art = dict(art or {})
        # _get_art() ya proporciona fanart, poster, thumb, banner, clearlogo.
        # Solo rellenar las claves que falten con los fallbacks que _get_art()
        # no garantiza, conservando la salida esperada por el resto del código.
        if not art.get('fanart'):
            art['fanart'] = (
                art.get('banner')
                or art.get('thumb')
                or art.get('poster')
                or ''
            )
        if not art.get('poster'):
            art['poster'] = (
                art.get('keyart')
                or art.get('thumb')
                or art.get('fanart')
                or ''
            )
        if not art.get('thumb'):
            art['thumb'] = (
                art.get('thumbnail')
                or art.get('banner')
                or art.get('fanart')
                or art.get('poster')
                or ''
            )
        if not art.get('banner'):
            art['banner'] = (
                art.get('fanart')
                or art.get('thumb')
                or art.get('poster')
                or ''
            )
        art['clearlogo'] = art.get('clearlogo') or ''
        return art

    def _kind_from_item(self, item):
        media_type = _item_info(item).get('mediatype', '')

        if media_type == 'movie':
            return Card.MOVIE
        if media_type == 'tvshow':
            return Card.SHOW
        if media_type == 'season':
            return Card.SEASON
        if media_type == 'episode':
            return Card.EPISODE
        if media_type in ('video', 'musicvideo'):
            return Card.VIDEO

        return Card.COLLECTION

    def card_from_item(self, item, row=None):
        core = _get_core()

        kind = self._kind_from_item(item)
        art = self._normalize_art(_item_art(item))
        item_path = _item_path(item)

        deeplink_id = ''
        show_id = ''
        season_id = ''

        if isinstance(row, dict):
            try:
                actions = core._get_actions(row)
                playback = actions.get(core.PLAYBACK) or {}
                browse = actions.get(core.BROWSE) or {}

                deeplink_id = (
                    playback.get('deeplinkId')
                    or browse.get('deeplinkId')
                    or row.get('deeplinkId')
                    or ''
                ).replace('entity-', '')

                show_id = (
                    browse.get('pageId')
                    or row.get('pageId')
                    or ''
                )

                season_id = row.get('seasonId') or ''
            except Exception:
                _log('card_from_item.actions')

        open_path = ''
        play_path = ''

        if kind == Card.MOVIE:
            play_path = item_path

            if deeplink_id:
                open_path = core.plugin.url_for(
                    core.clean_ui_movie,
                    deeplinkid=deeplink_id,
                )

        elif kind == Card.SHOW:
            if show_id:
                open_path = core.plugin.url_for(
                    core.clean_ui_show,
                    showid=show_id,
                )
            elif item_path:
                open_path = item_path

        elif kind == Card.SEASON:
            open_path = item_path

        elif kind in (Card.EPISODE, Card.VIDEO):
            play_path = item_path

        else:
            open_path = item_path

        return Card(
            label=_item_label(item),
            kind=kind,
            art=art,
            info=dict(_item_info(item)),
            open_path=open_path,
            play_path=play_path,
            trailer_path=_item_info(item).get('trailer', '') or '',
            context=_item_context(item),
            source_item=item,
            deeplink_id=deeplink_id,
            show_id=show_id,
            season_id=season_id,
        )

    def _card_from_raw(self, raw_item):
        core = _get_core()

        if not isinstance(raw_item, dict):
            return None

        if not raw_item.get('actions'):
            return None

        try:
            parsed = core.parse_row(raw_item)
            card = self.card_from_item(parsed, row=raw_item)
        except Exception:
            _log('_card_from_raw.parse_row')
            return None

        if not card.label:
            return None

        if not card.open_path and not card.play_path:
            return None

        return card

    def _rail_from_items(self, items, title, style, rail_id=''):
        cards = []

        for raw_item in items or []:
            card = self._card_from_raw(raw_item)
            if card:
                cards.append(card)

        return Rail(
            title=title,
            items=cards,
            style=style,
            rail_id=rail_id,
        )

    def _normalize_home_text(self, value):
        value = str(value or '').lower()
        # Descomponer marcas diacríticas y descartarlas (más rápido y
        # completo que reemplazos manuales).
        value = unicodedata.normalize('NFKD', value)
        value = value.encode('ascii', 'ignore').decode('ascii')
        return ' '.join(value.split())

    def _exclude_home_container(self, container):
        """Exclude sports and premium-subscription promotional rails."""
        if not isinstance(container, dict):
            return True

        visuals = container.get('visuals') or {}
        style_data = container.get('style') or {}

        if isinstance(style_data, dict):
            style_name = style_data.get('name', '')
        else:
            style_name = str(style_data)

        title = (
            visuals.get('name')
            or visuals.get('title')
            or ''
        )

        searchable = self._normalize_home_text(
            '{} {}'.format(title, style_name)
        )

        sports_markers = (
            'espn',
            'deporte',
            'deportes',
            'sport',
            'sports',
        )

        premium_markers = (
            'incluido con tu suscripcion premium',
            'incluido en tu suscripcion premium',
            'included with your premium subscription',
            'premium subscription',
        )

        if any(marker in searchable for marker in sports_markers):
            xbmc.log(
                '[CLEANUI] Rail Home excluido por contenido deportivo: '
                'id={} titulo={!r}'.format(
                    container.get('id', ''),
                    title,
                ),
                xbmc.LOGINFO,
            )
            return True

        if any(marker in searchable for marker in premium_markers):
            xbmc.log(
                '[CLEANUI] Rail Home excluido por promocion premium: '
                'id={} titulo={!r}'.format(
                    container.get('id', ''),
                    title,
                ),
                xbmc.LOGINFO,
            )
            return True

        return False

    def build_home(self):
        return self._build_browse_home(
            ref_id='home',
            title='Inicio',
            screen_type=Screen.HOME,
        )

    def build_movies_home(self):
        return self._build_browse_home(
            ref_id='movies',
            title='Películas',
            screen_type=Screen.COLLECTION,
        )

    def build_series_home(self):
        return self._build_browse_home(
            ref_id='series',
            title='Series',
            screen_type=Screen.COLLECTION,
        )

    def _build_browse_home(self, ref_id, title, screen_type):
        core = _get_core()

        try:
            deeplink_data = core.api.deeplink(ref_id=ref_id)
            actions = core._get_actions(deeplink_data)
            page_id = (actions.get(core.BROWSE) or {}).get('pageId')

            if not page_id:
                raise RuntimeError(
                    'Disney+ no devolvió pageId para {}'.format(ref_id)
                )

            page_data = core.api.page(
                page_id,
                limit=1,
                enhanced_limit=C.HOME_CONTAINER_FETCH,
            )
        except Exception:
            _log('build_browse_home.page.{}'.format(ref_id))
            return Screen(
                screen_type=screen_type,
                title=title,
                rails=[],
            )

        all_containers = list(
            page_data.get('containers', []) or []
        )

        # Preparar primero solamente los contenedores que pueden convertirse
        # en rails. Así los heroes y las marcas no alteran la posición final.
        eligible_containers = []
        for container in all_containers:
            if not isinstance(container, dict):
                continue
            if container.get('type') != 'set':
                continue
            if not container.get('id'):
                continue

            style_data = container.get('style') or {}
            if isinstance(style_data, dict):
                style_name = style_data.get('name', '')
            else:
                style_name = str(style_data)

            style_name = style_name.lower()

            if 'hero' in style_name or 'brand' in style_name:
                continue

            if self._exclude_home_container(container):
                continue

            eligible_containers.append(container)

        def _container_title(container):
            visuals = container.get('visuals') or {}
            return str(
                visuals.get('name')
                or visuals.get('title')
                or ''
            ).lower()

        continue_container = None
        other_containers = []

        for container in eligible_containers:
            if container.get('id') == core.CONTINUE_WATCHING_ID:
                continue_container = container
            else:
                other_containers.append(container)

        # Buscar el rail de recomendaciones independientemente del idioma
        # español/inglés usado por Disney.
        recommendation_index = None

        for index, container in enumerate(other_containers):
            container_title = _container_title(container)
            if (
                'recomend' in container_title
                or 'recommend' in container_title
                or 'para ti' in container_title
                or 'for you' in container_title
            ):
                recommendation_index = index
                break

        ordered_containers = []

        if recommendation_index is not None:
            recommendation_container = other_containers.pop(
                recommendation_index
            )
            ordered_containers.append(recommendation_container)
        elif other_containers:
            # Fallback: conservar el primer rail válido de Disney como primero.
            ordered_containers.append(other_containers.pop(0))

        if continue_container is not None:
            ordered_containers.append(continue_container)

        ordered_containers.extend(other_containers)

        all_containers = ordered_containers

        rails = []

        for container in all_containers:
            if len(rails) >= C.MAX_RAILS_HOME:
                break

            if container.get('type') != 'set':
                continue

            set_id = container.get('id')
            if not set_id:
                continue

            style_data = container.get('style') or {}

            if isinstance(style_data, dict):
                style_name = style_data.get('name', '')
            else:
                style_name = str(style_data)

            style_name = style_name.lower()

            if 'hero' in style_name or 'brand' in style_name:
                continue

            set_kwargs = {
                'page': 1,
                'limit': C.HOME_ITEM_LIMIT,
            }
            if set_id == core.CONTINUE_WATCHING_ID:
                set_kwargs['_skip_cache'] = True
                xbmc.log(
                    '[CLEANUI] Continue Watching carga inicial sin cache',
                    xbmc.LOGINFO,
                )

            try:
                set_data = core.api.set(
                    set_id,
                    **set_kwargs
                )
            except Exception:
                _log('build_home.set.{}'.format(set_id))
                continue

            cards = []

            for raw_item in set_data.get('items', []) or []:
                card = self._card_from_raw(raw_item)

                if card:
                    cards.append(card)

                if len(cards) >= C.HOME_ITEM_LIMIT:
                    break

            if not cards:
                continue

            is_continue = (
                set_id == core.CONTINUE_WATCHING_ID
            )

            if (
                screen_type == Screen.HOME
                and is_continue
            ):
                rail_style = C.STYLE_LANDSCAPE
            else:
                rail_style = C.STYLE_POSTER

            visuals = container.get('visuals') or {}
            rail_title = (
                visuals.get('name')
                or visuals.get('title')
                or 'Disney+'
            )

            if is_continue:
                rail_title = 'Continuar viendo'

            rails.append(Rail(
                title=rail_title,
                items=cards,
                style=rail_style,
                rail_id=set_id,
            ))

            xbmc.log(
                '[CLEANUI] Rail preparado: indice={} id={} '
                'titulo={!r} estilo={} tarjetas={}'.format(
                    len(rails) - 1,
                    set_id,
                    rail_title,
                    rail_style,
                    len(cards),
                ),
                xbmc.LOGINFO,
            )

        # Añadir Industrias después del primer rail NORMAL siguiente a
        # Continue Watching: Recomendaciones -> Continue Watching ->
        # [rail normal] -> Industrias -> resto.
        brands_rail = self._build_brands_rail(core)
        if brands_rail:
            continue_index = -1
            for index, rail in enumerate(rails):
                if rail.rail_id == core.CONTINUE_WATCHING_ID:
                    continue_index = index
                    break
            if continue_index >= 0:
                # Saltar el primer rail normal después de Continue Watching
                insert_at = continue_index + 2
            else:
                # Sin Continue Watching: Recs -> [rail normal] -> Industrias
                insert_at = min(2, len(rails))
            rails.insert(insert_at, brands_rail)
            # La inserción puede generar 25 rails. Conservamos Industrias
            # y descartamos únicamente el último rail ordinario.
            if len(rails) > C.MAX_RAILS_HOME:
                removed_rail = rails.pop()
                xbmc.log(
                    '[CLEANUI] Rail descartado para reservar Industrias: '
                    'id={} titulo={!r}'.format(
                        getattr(removed_rail, 'rail_id', ''),
                        getattr(removed_rail, 'title', ''),
                    ),
                    xbmc.LOGINFO,
                )
            xbmc.log(
                '[CLEANUI] Rail de Industrias preparado: '
                'posicion={} tarjetas={} pantalla={}'.format(
                    rails.index(brands_rail),
                    len(brands_rail.items),
                    screen_type,
                ),
                xbmc.LOGINFO,
            )

        hero = None

        for rail in rails:
            if rail.items:
                hero = rail.items[0]
                break

        xbmc.log(
            '[CLEANUI] Home construida: {} rails'.format(len(rails)),
            xbmc.LOGINFO,
        )

        return Screen(
            screen_type=screen_type,
            title=title,
            hero=hero,
            rails=rails,
        )

    def _build_brands_rail(self, core):
        """Build a brands rail from the Disney+ brands API."""
        try:
            brands_data = core.api.set(
                core.BRANDS_ID,
                page=1,
                limit=C.HOME_ITEM_LIMIT,
            )
        except Exception:
            _log('build_brands_rail.api')
            return None

        cards = []
        for raw_item in brands_data.get('items', []) or []:
            card = self._brand_card_from_raw(raw_item)
            if card:
                cards.append(card)

        if not cards:
            return None

        return Rail(
            title='Industrias',
            items=cards,
            style=C.STYLE_BRAND,
            rail_id='brands',
        )

    def _brand_card_from_raw(self, raw_item):
        """Create a Card from a brand raw item (no actions required)."""
        core = _get_core()

        if not isinstance(raw_item, dict):
            return None

        try:
            visuals = raw_item.get('visuals') or {}
            name = (
                visuals.get('name')
                or visuals.get('title')
                or ''
            )

            art = self._normalize_art(
                core.get_art(raw_item)
            )

            # Las industrias deben conservar el logo transparente de Disney.
            # Si no existe clearlogo, thumb continúa siendo el fallback.
            if art.get('clearlogo'):
                art['brand_logo'] = art['clearlogo']
            else:
                art['brand_logo'] = art.get('thumb') or ''

            actions = raw_item.get('actions') or []
            browse_action = None
            for action in actions:
                if isinstance(action, dict) and action.get('type') == 'browse':
                    browse_action = action
                    break

            browse_id = ''
            page_id = ''

            if browse_action:
                browse_id = browse_action.get('deeplinkId', '')
                page_id = browse_action.get('pageId', '')
            elif actions:
                first_action = actions[0] if isinstance(actions[0], dict) else {}
                browse_id = first_action.get('deeplinkId', '')
                page_id = first_action.get('pageId', '')

            if not name:
                return None

            return Card(
                label=name,
                kind=C.KIND_COLLECTION,
                art=art,
                info={
                    'plot': '',
                    'mediatype': 'video',
                },
                browse_id=page_id or browse_id,
                browse_ref=browse_id,
            )
        except Exception:
            _log('brand_card_from_raw')
            return None

    def build_collection(self, page_id, title):
        """Build a HomeWindow screen from a page_id (industry/brand page)."""
        core = _get_core()

        try:
            page_data = core.api.page(
                page_id,
                limit=1,
                enhanced_limit=C.HOME_CONTAINER_FETCH,
            )
        except Exception:
            _log('build_collection.page')
            return Screen(
                screen_type=Screen.COLLECTION,
                title=title,
                rails=[],
            )

        all_containers = list(
            page_data.get('containers', []) or []
        )

        eligible_containers = []
        for container in all_containers:
            if not isinstance(container, dict):
                continue
            if container.get('type') != 'set':
                continue
            if not container.get('id'):
                continue

            style_data = container.get('style') or {}
            if isinstance(style_data, dict):
                style_name = style_data.get('name', '')
            else:
                style_name = str(style_data)

            style_name = style_name.lower()

            if 'hero' in style_name:
                continue

            eligible_containers.append(container)

        rails = []

        for container in eligible_containers:
            if len(rails) >= C.MAX_RAILS_HOME:
                break

            set_id = container.get('id')
            if not set_id:
                continue

            try:
                set_data = core.api.set(
                    set_id,
                    page=1,
                    limit=C.HOME_ITEM_LIMIT,
                )
            except Exception:
                _log('build_collection.set.{}'.format(set_id))
                continue

            cards = []
            for raw_item in set_data.get('items', []) or []:
                card = self._card_from_raw(raw_item)
                if card:
                    cards.append(card)
                if len(cards) >= C.HOME_ITEM_LIMIT:
                    break

            if not cards:
                continue

            visuals = container.get('visuals') or {}
            rail_title = (
                visuals.get('name')
                or visuals.get('title')
                or ''
            )

            rails.append(Rail(
                title=rail_title,
                items=cards,
                style=C.STYLE_POSTER,
                rail_id=set_id,
            ))

        hero = None
        for rail in rails:
            if rail.items:
                hero = rail.items[0]
                break

        return Screen(
            screen_type=Screen.COLLECTION,
            title=title,
            hero=hero,
            rails=rails,
        )

    def _continue_signature(self, cards):
        """Firma estable de identidad y progreso de Continue Watching."""
        signature = []
        for card in cards or []:
            identity = (
                getattr(card, 'deeplink_id', '')
                or getattr(card, 'play_path', '')
                or getattr(card, 'open_path', '')
                or '{}|{}'.format(
                    getattr(card, 'kind', ''),
                    getattr(card, 'label', ''),
                )
            )
            source_item = getattr(card, 'source_item', None)
            info = getattr(card, 'info', {}) or {}
            # Priorizar progreso desde info (disponible aunque la Card no
            # tenga source_item); mantener compatibilidad con source_item.
            progress = (
                info.get('resume_from')
                or getattr(source_item, 'resume_from', None),
                info.get('playcount'),
            )
            signature.append((identity, progress))
        return tuple(signature)

    def refresh_continue_watching(self, screen):
        """Refresh the existing Continue Watching rail without rebuilding Home."""
        core = _get_core()

        if not screen or getattr(screen, 'screen_type', '') != Screen.HOME:
            return False

        target_index = -1
        target_rail = None

        for index, rail in enumerate(screen.rails):
            if rail.rail_id == core.CONTINUE_WATCHING_ID:
                target_index = index
                target_rail = rail
                break

        if target_rail is None:
            xbmc.log(
                '[CLEANUI] No hay rail Continue Watching en Home para refrescar',
                xbmc.LOGINFO,
            )
            return False

        sync_active = core.settings.SYNC_PLAYBACK.value

        if not sync_active:
            xbmc.log(
                '[CLEANUI] Disney Sync esta desactivado; Continue Watching '
                'se consultara de nuevo, pero Disney puede no haber '
                'recibido el progreso',
                xbmc.LOGINFO,
            )

        control_id = C.CONTROL_RAIL_FIRST + target_index
        state = getattr(screen, '_cleanui_window_state', None) or {}
        positions = state.get('positions') or {}

        old_items = list(target_rail.items or [])
        old_count = len(old_items)
        old_position = positions.get(
            control_id,
            getattr(target_rail, '_selected_position', 0),
        )

        try:
            old_position = int(old_position)
        except (TypeError, ValueError):
            old_position = 0

        if old_position < 0:
            old_position = 0

        if old_items and old_position >= old_count:
            old_position = old_count - 1

        old_signature = self._continue_signature(old_items)

        def card_identity(card):
            if not card:
                return None
            if getattr(card, 'deeplink_id', ''):
                return (
                    'deeplink',
                    getattr(card, 'deeplink_id', ''),
                )
            show_id = getattr(card, 'show_id', '')
            season_id = getattr(card, 'season_id', '')
            if show_id or season_id:
                return (
                    'show-season',
                    show_id,
                    season_id,
                    getattr(card, 'kind', ''),
                )
            if getattr(card, 'play_path', ''):
                return (
                    'play',
                    getattr(card, 'play_path', ''),
                )
            if getattr(card, 'open_path', ''):
                return (
                    'open',
                    getattr(card, 'open_path', ''),
                )
            return (
                'fallback',
                getattr(card, 'kind', ''),
                getattr(card, 'label', ''),
            )

        old_identity = None
        if old_items and 0 <= old_position < old_count:
            old_identity = card_identity(old_items[old_position])

        max_attempts = 3
        delays = [0, 2, 3]

        for attempt in range(max_attempts):
            try:
                data = core.api.set(
                    core.CONTINUE_WATCHING_ID,
                    limit=C.HOME_ITEM_LIMIT,
                    page=1,
                    _skip_cache=True,
                )
            except Exception:
                _log('refresh_continue_watching.api')
                return False

            cards = []
            for raw_item in data.get('items', []) or []:
                card = self._card_from_raw(raw_item)
                if card:
                    cards.append(card)
                if len(cards) >= C.HOME_ITEM_LIMIT:
                    break

            new_signature = self._continue_signature(cards)

            changed = new_signature != old_signature

            xbmc.log(
                '[CLEANUI] Continue Watching intento {}/{}: '
                'anteriores={} nuevos={} cambiado={}'.format(
                    attempt + 1,
                    max_attempts,
                    old_count,
                    len(cards),
                    changed,
                ),
                xbmc.LOGINFO,
            )

            if changed:
                break

            # Sin Disney Sync no tiene sentido esperar consistencia: un solo
            # intento sin reintentos ni sleeps.
            if not sync_active:
                break

            if attempt < max_attempts - 1:
                wait_seconds = delays[attempt + 1]
                xbmc.log(
                    '[CLEANUI] Continue Watching esperando '
                    'consistencia de Disney: {} segundos'.format(
                        wait_seconds
                    ),
                    xbmc.LOGINFO,
                )
                xbmc.sleep(wait_seconds * 1000)

        new_position = 0
        if cards and old_identity is not None:
            matched_position = None
            for index, card in enumerate(cards):
                if card_identity(card) == old_identity:
                    matched_position = index
                    break
            if matched_position is not None:
                new_position = matched_position
            else:
                new_position = min(old_position, len(cards) - 1)

        target_rail.items = cards
        target_rail.style = C.STYLE_LANDSCAPE
        target_rail._selected_position = new_position

        if state:
            state_positions = state.setdefault('positions', {})
            state_positions[control_id] = new_position

        xbmc.log(
            '[CLEANUI] Rail Continue Watching refrescado: '
            'indice={} anteriores={} nuevos={} posicion={}'.format(
                target_index,
                old_count,
                len(cards),
                new_position,
            ),
            xbmc.LOGINFO,
        )
        return True

    def _cards_from_raw_items(self, raw_items):
        cards = []
        for raw_item in raw_items or []:
            card = self._card_from_raw(raw_item)
            if card:
                cards.append(card)
            if len(cards) >= C.HOME_ITEM_LIMIT:
                break
        return cards

    def build_continue_watching_screen(self):
        """Build Continue Watching as a Clean UI HomeWindow screen."""
        core = _get_core()
        try:
            folder, _has_more = core.continue_watching(page=1)
        except Exception:
            _log('build_continue_watching_screen.core')
            raise
        cards = []
        for item in getattr(folder, 'items', []) or []:
            card = self.card_from_item(item)
            if card:
                cards.append(card)
            if len(cards) >= C.HOME_ITEM_LIMIT:
                break
        rails = []
        if cards:
            rails.append(Rail(
                title='Continuar viendo',
                items=cards,
                style=C.STYLE_LANDSCAPE,
                rail_id=core.CONTINUE_WATCHING_ID,
            ))
        xbmc.log(
            '[CLEANUI] Pantalla Continuar viendo preparada: tarjetas={}'.format(
                len(cards)
            ),
            xbmc.LOGINFO,
        )
        return Screen(
            screen_type=Screen.COLLECTION,
            title='Continuar viendo',
            hero=cards[0] if cards else None,
            rails=rails,
        )

    def build_watchlist_screen(self):
        """Build Disney+ Watchlist as a Clean UI HomeWindow screen."""
        core = _get_core()
        try:
            # The routed watchlist uses redirect()/Exit for a single set.
            # Resolve its data here so that navigation stays in this window.
            link = core.api.deeplink(ref_id='watchlist')
            page_id = core._get_actions(link)[core.BROWSE]['pageId']
            data = core.api.page(page_id, limit=1, enhanced_limit=20, _skip_cache=True)
            raw_items = []
            for row in data.get('containers') or data.get('items') or []:
                if row.get('type') == 'set':
                    contents = core.api.set(row['id'], page=1, _skip_cache=True)
                    raw_items.extend(contents.get('items') or [])
                elif row.get('actions'):
                    raw_items.append(row)
        except Exception:
            _log('build_watchlist_screen.core')
            raise
        cards = []
        seen = set()
        for item in raw_items:
            card = self._card_from_raw(item)
            if not card:
                continue
            identity = (
                card.deeplink_id
                or card.show_id
                or card.play_path
                or card.open_path
                or '{}|{}'.format(card.kind, card.label)
            )
            if identity in seen:
                continue
            seen.add(identity)
            cards.append(card)
            if len(cards) >= C.HOME_ITEM_LIMIT:
                break
        rails = []
        if cards:
            rails.append(Rail(
                title='Mi lista',
                items=cards,
                style=C.STYLE_POSTER,
                rail_id='watchlist',
            ))
        xbmc.log(
            '[CLEANUI] Pantalla Mi lista preparada: tarjetas={}'.format(
                len(cards)
            ),
            xbmc.LOGINFO,
        )
        return Screen(
            screen_type=Screen.COLLECTION,
            title='Mi lista',
            hero=cards[0] if cards else None,
            rails=rails,
        )

    def add_detail_to_watchlist(self, hero):
        payload = getattr(hero, 'watchlist_data', None)
        if not payload:
            raise RuntimeError('Este título no permite guardarse en Mi lista.')
        if not getattr(hero, 'watchlist_added', False):
            _get_core().api.edit_watchlist('add', **payload)
            hero.watchlist_added = True

    def _set_detail_watchlist(self, hero, data, info):
        core = _get_core()
        action = self._actions(info).get(core.MODIFYSAVES) or {}
        page_info, action_info = data.get('infoBlock'), action.get('infoBlock')
        hero.watchlist_data = (
            dict(page_info=page_info, action_info=action_info)
            if core.settings.SYNC_WATCHLIST.value and page_info and action_info else None
        )

    def build_movie_detail(self, deeplink_id):
        core = _get_core()
        clean_id = (deeplink_id or '').replace('entity-', '')

        if not clean_id:
            raise RuntimeError('La película no tiene deeplinkId')

        entity_id = 'entity-{}'.format(clean_id)

        try:
            data = core.api.page(
                entity_id,
                limit=1,
                enhanced_limit=ENTITY_ENHANCED_LIMIT,
            )
            info = core.get_info(data)
        except Exception:
            _log('build_movie_detail.api')
            raise

        try:
            parsed = core.parse_row(data)
            hero = self.card_from_item(parsed, row=data)
        except Exception:
            _log('build_movie_detail.parse_row')

            hero = Card(
                label=info.get('title', ''),
                kind=Card.MOVIE,
                art=self._normalize_art(info.get('art', {})),
                info={
                    'plot': info.get('plot', ''),
                    'mediatype': 'movie',
                },
                deeplink_id=clean_id,
            )

        hero.kind = Card.MOVIE
        self._set_detail_watchlist(hero, data, info)
        hero.deeplink_id = clean_id
        hero.open_path = ''
        hero.play_path = info.get('playpath') or ''

        if not hero.info.get('plot'):
            hero.info['plot'] = info.get('plot') or ''

        if not hero.art:
            hero.art = self._normalize_art(info.get('art', {}))
        else:
            hero.art = self._normalize_art(hero.art)

        actions = self._actions(info)
        trailer_action = actions.get(core.TRAILER) or {}

        if trailer_action:
            hero.trailer_path = core.plugin.url_for(
                core.play_trailer,
                deeplink_id=clean_id,
            )

        if core.settings.SYNC_WATCHLIST.value:
            modify_action = actions.get(core.MODIFYSAVES) or {}

            if modify_action:
                hero.context.append((
                    'Mi lista',
                    'RunPlugin({})'.format(
                        core.plugin.url_for(
                            core.add_watchlist,
                            deeplink_id=clean_id,
                        )
                    ),
                ))

        containers = self._containers(info)
        rails = []

        suggested = containers.get(core.SUGGESTED) or {}
        suggested_items = (
            suggested.get('items', [])
            if isinstance(suggested, dict)
            else []
        )

        suggested_rail = self._rail_from_items(
            suggested_items,
            'También te puede gustar',
            C.STYLE_POSTER,
            'suggested',
        )

        if suggested_rail.items:
            rails.append(suggested_rail)

        extras = containers.get(core.EXTRAS) or {}
        extra_items = (
            extras.get('items', [])
            if isinstance(extras, dict)
            else []
        )

        extras_rail = self._rail_from_items(
            extra_items,
            'Extras',
            C.STYLE_LANDSCAPE,
            'extras',
        )

        if extras_rail.items:
            rails.append(extras_rail)

        return Screen(
            screen_type=Screen.MOVIE,
            title=info.get('title', ''),
            hero=hero,
            rails=rails,
        )

    def build_show_detail(self, show_id):
        core = _get_core()

        if not show_id:
            raise RuntimeError('La serie no tiene showId')

        try:
            data = core.api.page(
                show_id,
                limit=1,
                enhanced_limit=ENTITY_ENHANCED_LIMIT,
            )
            info = core.get_info(data)
        except Exception:
            _log('build_show_detail.api')
            raise

        try:
            parsed = core.parse_row(data)
            hero = self.card_from_item(parsed, row=data)
        except Exception:
            _log('build_show_detail.parse_row')

            hero = Card(
                label=info.get('title', ''),
                kind=Card.SHOW,
                art=self._normalize_art(info.get('art', {})),
                info={
                    'plot': info.get('plot', ''),
                    'mediatype': 'tvshow',
                },
                show_id=show_id,
            )

        hero.kind = Card.SHOW
        self._set_detail_watchlist(hero, data, info)
        hero.show_id = show_id
        hero.open_path = ''
        hero.play_path = ''
        hero.art = self._normalize_art(
            hero.art or info.get('art', {})
        )

        if not hero.info.get('plot'):
            hero.info['plot'] = info.get('plot') or ''

        actions = self._actions(info)
        trailer_action = actions.get(core.TRAILER) or {}

        if trailer_action:
            deeplink_id = (
                trailer_action.get('deeplinkId')
                or data.get('id')
                or ''
            )

            if deeplink_id:
                hero.trailer_path = core.plugin.url_for(
                    core.play_trailer,
                    deeplink_id=deeplink_id,
                )

        playback = actions.get(core.PLAYBACK) or {}
        watchlist_id = playback.get('deeplinkId', '')

        if core.settings.SYNC_WATCHLIST.value and watchlist_id:
            hero.context.append((
                'Mi lista',
                'RunPlugin({})'.format(
                    core.plugin.url_for(
                        core.add_watchlist,
                        deeplink_id=watchlist_id,
                    )
                ),
            ))

        containers = self._containers(info)
        rails = []

        episodes = containers.get(core.EPISODES) or {}
        seasons = (
            episodes.get('seasons', [])
            if isinstance(episodes, dict)
            else []
        )

        season_cards = []

        for season_data in seasons:
            try:
                season_id = season_data.get('id', '')
                if not season_id:
                    continue

                visuals = season_data.get('visuals') or {}

                season_cards.append(Card(
                    label=visuals.get('name') or 'Temporada',
                    kind=Card.SEASON,
                    art=self._season_art(
                        season_data,
                        hero.art or info.get('art', {}),
                    ),
                    info={
                        'plot': visuals.get(
                            'episodeCountDisplayText',
                            '',
                        ),
                        'mediatype': 'season',
                        'tvshowtitle': info.get('title', ''),
                    },
                    open_path=core.plugin.url_for(
                        core.clean_ui_season,
                        showid=show_id,
                        seasonid=season_id,
                    ),
                    show_id=show_id,
                    season_id=season_id,
                ))
            except Exception:
                _log('build_show_detail.season')
                continue

        if season_cards:
            rails.append(self.build_episode_rail(
                season_cards[0].season_id, season_cards[0].label))

        suggested = containers.get(core.SUGGESTED) or {}
        suggested_items = (
            suggested.get('items', [])
            if isinstance(suggested, dict)
            else []
        )

        suggested_rail = self._rail_from_items(
            suggested_items,
            'Sugeridos',
            C.STYLE_POSTER,
            'suggested',
        )

        if suggested_rail.items:
            rails.append(suggested_rail)

        extras = containers.get(core.EXTRAS) or {}
        extra_items = (
            extras.get('items', [])
            if isinstance(extras, dict)
            else []
        )

        extras_rail = self._rail_from_items(
            extra_items,
            'Extras',
            C.STYLE_LANDSCAPE,
            'extras',
        )

        if extras_rail.items:
            rails.append(extras_rail)

        screen = Screen(
            screen_type=Screen.SHOW,
            title=info.get('title', ''),
            hero=hero,
            rails=rails,
        )
        screen.seasons = season_cards
        screen.selected_season = 0
        return screen

    def build_episode_rail(self, season_id, title):
        data = _get_core().api.season(season_id, limit=100, page=1)
        cards = []
        for row in data.get('items', []) or []:
            card = self._card_from_raw(row)
            if card and card.play_path:
                card.kind = Card.EPISODE
                card.open_path = ''
                cards.append(card)
        return Rail(title=title, items=cards, style=C.STYLE_EPISODE,
                    rail_id='episodes')

    def build_season_detail(self, show_id, season_id):
        core = _get_core()

        if not show_id or not season_id:
            raise RuntimeError(
                'Falta showId o seasonId para abrir la temporada'
            )

        try:
            show_data = core.api.page(
                show_id,
                limit=1,
                enhanced_limit=ENTITY_ENHANCED_LIMIT,
            )
            season_data = core.api.season(
                season_id,
                limit=100,
                page=1,
            )
        except Exception:
            _log('build_season_detail.api')
            raise

        cards = []

        for raw_item in season_data.get('items', []) or []:
            card = self._card_from_raw(raw_item)

            if not card:
                continue

            card.kind = Card.EPISODE
            card.open_path = ''

            if card.play_path:
                cards.append(card)

        show_visuals = show_data.get('visuals') or {}
        season_visuals = season_data.get('visuals') or {}

        show_title = (
            show_visuals.get('title')
            or show_visuals.get('name')
            or ''
        )

        season_name = (
            season_visuals.get('name')
            or season_visuals.get('title')
            or 'Episodios'
        )

        show_info = core.get_info(show_data)

        hero = Card(
            label=show_title,
            kind=Card.SEASON,
            art=self._normalize_art(core.get_art(show_data)),
            info={
                'mediatype': 'season',
                'tvshowtitle': show_title,
                'plot': show_info.get('plot') or season_name,
            },
            show_id=show_id,
            season_id=season_id,
        )

        rails = []

        if cards:
            rails.append(Rail(
                title=season_name,
                items=cards,
                style=C.STYLE_EPISODE,
                rail_id=season_id,
            ))

        return Screen(
            screen_type=Screen.SEASON,
            title=show_title,
            hero=hero,
            rails=rails,
        )

    def _season_art(self, season_data, show_art):
        """Fallback: if Disney doesn't provide season art, use the show's poster."""
        season_art = self._normalize_art(
            _get_core().get_art(season_data)
        )
        fallback_art = self._normalize_art(show_art)
        for key in ('poster', 'thumb', 'fanart', 'banner', 'clearlogo'):
            if not season_art.get(key):
                season_art[key] = fallback_art.get(key, '')
        return season_art

    def build_search(self, query):
        core = _get_core()

        try:
            data = core.api.search(query)
        except Exception:
            _log('build_search.api')
            raise

        items = []

        containers = data.get('containers', []) or []
        for container in containers:
            if isinstance(container, dict):
                items.extend(container.get('items', []) or [])

        if not items:
            items = data.get('items', []) or []

        cards = []

        for raw_item in items:
            card = self._card_from_raw(raw_item)
            if card:
                cards.append(card)

        rails = []

        if cards:
            rails.append(Rail(
                title='Resultados para "{}"'.format(query),
                items=cards,
                style=C.STYLE_POSTER,
                rail_id='search',
            ))

        return Screen(
            screen_type=Screen.SEARCH,
            title=query,
            hero=cards[0] if cards else None,
            rails=rails,
        )
