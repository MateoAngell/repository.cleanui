"""Translate the service's Home sub-navigation without inventing hub pages."""


def _target(action):
    if not isinstance(action, dict):
        return None
    if action.get('type') == 'browse':
        if action.get('pageId'):
            return {'kind': 'page', 'id': action['pageId']}
        if action.get('deeplinkId'):
            return {'kind': 'deeplink', 'id': action['deeplinkId']}
    if action.get('type') == 'systemBrowse':
        slug = action.get('slug')
        if slug in ('home', 'movies', 'series', 'espn'):
            return {'kind': 'deeplink', 'id': slug}
    return None


def home_hubs(nav, home_page_id=None):
    """Return supported tabs from the Home-linked SubNav, in service order."""
    if not isinstance(nav, dict):
        return []
    children = nav.get('children')
    children = children if isinstance(children, list) else []
    if nav.get('type') == 'subNav':
        linked = any(
            isinstance(child, dict) and (
                child.get('id') == 'home' or (
                    bool(home_page_id) and isinstance(child.get('action'), dict)
                    and child['action'].get('pageId') == home_page_id
                )
            ) for child in children
        )
        if linked:
            tabs = []
            for child in children:
                if not isinstance(child, dict):
                    continue
                visuals = child.get('visuals')
                label = visuals.get('name') if isinstance(visuals, dict) else None
                target = _target(child.get('action'))
                if isinstance(label, str) and label.strip() and target:
                    tabs.append({'label': label.strip(), 'navigation': target})
            return tabs
    for child in children:
        tabs = home_hubs(child, home_page_id)
        if tabs:
            return tabs
    return []
