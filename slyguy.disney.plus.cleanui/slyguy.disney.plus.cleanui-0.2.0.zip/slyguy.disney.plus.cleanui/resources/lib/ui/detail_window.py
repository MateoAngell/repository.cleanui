"""Entity presentation with inline episodes and explicit action routing."""
import textwrap
import traceback
import xbmc
import xbmcgui
from . import constants as C, effects
from .adapter import UIAdapter

class DetailWindow(xbmcgui.WindowXMLDialog):
    PLATFORM = 'disney'

    def __init__(self,*args,**kwargs):
        self.controller=kwargs.pop('controller')
        self.screen=kwargs.pop('screen')
        super(DetailWindow,self).__init__(*args,**kwargs)
        self._activating=False
        self._last_activation=None

    def _log_error(self,context):
        xbmc.log('[CLEANUI] detail.{}: {}'.format(context,traceback.format_exc()),xbmc.LOGERROR)

    def onInit(self):
        try:
            effects.prepare(self)
            self._actions=[]
            self._set_hero()
            self._populate_rails()
            self._populate_seasons()
            self._select_tab(self._tabs[0]-6000)
            if not self._restore_state():
                self._focus_best()
        except Exception:
            self._log_error('onInit')
            self.controller.end_transition()
            self.close()

    def _seasons(self):
        return getattr(self.screen,'seasons',getattr(self.screen,'season_choices',[]))

    def _season_index(self):
        selected=getattr(self.screen,'selected_season',0)
        if isinstance(selected,int):
            return min(max(0,selected),max(0,len(self._seasons())-1))
        return next((i for i,s in enumerate(self._seasons()) if s.season_id==selected.season_id),0)

    def _set_hero(self):
        hero=self.screen.hero
        if not hero:
            return
        info,art=hero.info,hero.art
        action=''
        if self.PLATFORM=='disney':
            action='add' if getattr(hero,'watchlist_data',None) else ''
        else:
            action=next((a for _,a in hero.context if 'watchlist' in a), '')
        metadata=[str(info[k]) for k in ('year','mpaa') if info.get(k)]
        try:
            minutes=int(info.get('duration') or 0)//60
        except (TypeError,ValueError):
            minutes=0
        if minutes:
            metadata.append('{} min'.format(minutes))
        genre=info.get('genre') or ''
        if isinstance(genre,(list,tuple)):
            genre=', '.join(str(g) for g in genre)
        values=dict(title=hero.label,fanart=art.get('fanart') or art.get('banner') or '',
                    logo=art.get('clearlogo') or '',plot=info.get('plot') or '',
                    summary=textwrap.shorten(info.get('plot') or '',width=220,placeholder='…'),
                    meta=' • '.join(metadata),genre=str(genre),play_path=hero.play_path or '',
                    trailer_path=hero.trailer_path or '',watchlist_action=action,
                    play_label=getattr(self.screen,'play_label','REPRODUCIR'))
        for key,value in values.items():
            self.setProperty('cleanui.detail.'+key,value)
        actions=[cid for cid,key in ((1000,'play_path'),(1001,'trailer_path'),(1002,'watchlist_action'))
                 if values[key]]
        self._actions=actions
        x=72 if self.PLATFORM=='disney' else 60
        for i,cid in enumerate(actions):
            control=self.getControl(cid)
            control.setPosition(x,414 if self.PLATFORM=='disney' else 586)
            width=240 if cid==1000 else 140 if cid==1001 else 64
            control.setWidth(width)
            control.controlLeft(self.getControl(actions[i-1] if i else 1003))
            control.controlRight(self.getControl(actions[i+1] if i+1<len(actions) else cid))
            control.controlUp(self.getControl(1003))
            x+=width+20

    def _populate_rails(self):
        tabs=[]
        for i in range(4):
            control=self.getControl(4000+i)
            control.reset()
            rail=self.screen.rails[i] if i<len(self.screen.rails) else None
            self.setProperty('cleanui.detail.rail{}.style'.format(i),rail.style if rail else '')
            cards=rail.items if rail else []
            self.setProperty('cleanui.detail.rail{}.visible'.format(i),'true' if cards else 'false')
            self.setProperty('cleanui.detail.rail{}.title'.format(i),
                {'episodes':'EPISODIOS','seasons':'TEMPORADAS','extras':'EXTRAS',
                 'suggested':'SUGERENCIAS' if self.PLATFORM=='disney' else 'QUIZÁ TAMBIÉN TE GUSTE'
                 }.get(rail.rail_id,rail.title).upper() if rail else '')
            if cards:
                target=self.getControl(self._panel_id(i))
                target.reset()
                style=(C.STYLE_POSTER if self.PLATFORM=='max' and rail.style==C.STYLE_POSTER else
                       C.STYLE_EPISODE if rail.style==C.STYLE_EPISODE else C.STYLE_LANDSCAPE)
                target.addItems([UIAdapter.to_list_item(card,style) for card in cards])
                tabs.append(6000+i)
        tabs.append(6004)
        self._tabs=tabs
        x=72 if self.PLATFORM=='disney' else 60
        for i,cid in enumerate(tabs):
            control=self.getControl(cid)
            control.setPosition(x,0)
            width=180 if cid==6004 else min(400,max(180,len(self.getProperty(
                'cleanui.detail.rail{}.title'.format(cid-6000)))*16))
            control.setWidth(width)
            self.getControl(6500+cid-6000).setPosition(x,52)
            self.getControl(6500+cid-6000).setWidth(width)
            control.controlLeft(self.getControl(tabs[max(0,i-1)]))
            control.controlRight(self.getControl(tabs[min(len(tabs)-1,i+1)]))
            control.controlUp(self.getControl(self._actions[-1] if self._actions else 1003))
            if cid!=6004:
                control.controlDown(self.getControl(
                7000 if cid==6000 and self._seasons() else self._panel_id(cid-6000)))
            x+=width+24
        for cid in self._actions+[1003]:
            self.getControl(cid).controlDown(self.getControl(tabs[0]))

    def _populate_seasons(self):
        seasons=self._seasons()
        self.setProperty('cleanui.detail.has_seasons','true' if seasons else 'false')
        self._set_season_picker(False)
        if seasons:
            index=self._season_index()
            self.getControl(7000).setLabel(seasons[index].label)
            self.getControl(7001).reset()
            self.getControl(7001).addItems([xbmcgui.ListItem(label=s.label) for s in seasons])
            self.getControl(7001).selectItem(index)
        for i in range(4):
            panel=self.getControl(self._panel_id(i))
            panel.controlUp(self.getControl(7000 if i==0 and seasons else 6000+i))
            panel.controlDown(panel)

    def _panel_id(self,index):
        rail=self.screen.rails[index] if index<len(self.screen.rails) else None
        return (4300 if self.PLATFORM=='max' and rail and rail.style==C.STYLE_POSTER else 4000)+index

    def _select_tab(self,index):
        if index<4 and self.getProperty('cleanui.detail.rail{}.visible'.format(index))!='true':
            return
        self.setProperty('cleanui.detail.tab',str(index))

    def _change_season(self):
        index=self.getControl(7001).getSelectedPosition()
        seasons=self._seasons()
        self._set_season_picker(False)
        self.setFocusId(7000)
        if not 0<=index<len(seasons):
            self.setFocusId(7000)
            return
        if index!=self._season_index():
            season=seasons[index]
            builder=(lambda:self.controller.repository.build_episode_rail(season.season_id,season.label)
                     if self.PLATFORM=='disney' else
                     self.controller.repository.build_show_episodes(season.show_id,season.season_id))
            self.controller.load_navigation(self,builder,
                lambda result:self._apply_season(result,index))
            return
        self._select_tab(0)
        self.setFocusId(4000 if self.getControl(4000).size() else 7000)

    def _apply_season(self,result,index):
        if self.PLATFORM=='disney':
            self.screen.rails[0]=result
            self.screen.selected_season=index
            first=next((card for card in result.items if card.kind==C.KIND_EPISODE),None)
            self.screen.hero.play_path=first.play_path if first else ''
        else:
            self.screen=result
        self._set_hero()
        self._populate_rails()
        self._populate_seasons()
        self._select_tab(0)
        self.setFocusId(4000 if self.getControl(4000).size() else 7000)

    def _focus_best(self):
        self.setFocusId(self._actions[0] if self._actions else self._tabs[0])

    def _set_season_picker(self,opened):
        value='true' if opened else 'false'
        self.setProperty('cleanui.detail.season_picker',value)
        # Literal visibility is applied before Kodi handles SETFOCUS.
        # A property condition alone is not evaluated until the next frame.
        self.getControl(7001).setVisibleCondition(value)

    def onFocus(self,cid):
        xbmc.log('[CLEANUI][FOCUS] detail={} picker={}'.format(cid,
            self.getProperty('cleanui.detail.season_picker')),xbmc.LOGINFO)
        if 6000<=cid<=6004:
            self._select_tab(cid-6000)
        if cid not in (7000,7001) and self.getFocusId()==cid:
            self._set_season_picker(False)
        self.controller.notify_window_focused(self)

    def capture_state(self):
        self.screen._cleanui_window_state=dict(focus_id=self.getFocusId(),
            tab=self.getProperty('cleanui.detail.tab'),
            positions={self._panel_id(i):self.getControl(self._panel_id(i)).getSelectedPosition()
                       for i in range(4) if self.getControl(self._panel_id(i)).size()})

    def _restore_state(self):
        state=getattr(self.screen,'_cleanui_window_state',None)
        if not state:
            return False
        self._select_tab(int(state.get('tab') or 0))
        for cid,pos in state.get('positions',{}).items():
            control=self.getControl(cid)
            if control.size():
                control.selectItem(min(max(0,pos),control.size()-1))
        cid=state.get('focus_id',self._tabs[0])
        if cid==7001:
            cid=7000
        allowed=set(self._actions+self._tabs+[1003,6101])
        if self._seasons():
            allowed.add(7000)
        allowed.update(self._panel_id(i) for i in range(min(4,len(self.screen.rails)))
                       if self.getControl(self._panel_id(i)).size())
        if cid not in allowed:
            return False
        self.setFocusId(cid)
        return True

    def _close_current_window(self):
        if getattr(self,'_page_history',None):
            self.screen=self._page_history.pop()
            self.onInit()
        else:
            self.controller.close_child_window(self)

    def onAction(self,action):
        xbmc.log('[CLEANUI][INPUT] detail action={} focus={}'.format(
            action.getId(),self.getFocusId()),xbmc.LOGINFO)
        if action.getId() in C.ACTION_BACK:
            if getattr(self,'_loading_request',None) or self.getProperty('cleanui.load_error')=='true':
                self.controller.cancel_navigation(self)
                self._focus_best()
                return
            if self.getProperty('cleanui.detail.season_picker')=='true':
                self._set_season_picker(False)
                self.setFocusId(7000)
            else:
                self._close_current_window()

    def onClick(self,cid):
        xbmc.log('[CLEANUI][CLICK] detail={}'.format(cid),xbmc.LOGINFO)
        if cid==4999:
            self.controller.complete_navigation(self)
            return
        if cid==4980:
            self.controller.retry_navigation(self)
            return
        if cid==4981:
            self.controller.cancel_navigation(self)
            self._focus_best()
            return
        if getattr(self,'_loading_request',None):
            return
        if self._activating:
            return
        self._activating=True
        try:
            self._activate_click(cid)
        except Exception:
            self._log_error('activation')
            xbmcgui.Dialog().ok('Clean UI','No se pudo abrir este contenido. Puedes volver e intentarlo de nuevo.')
        finally:
            self._activating=False

    def _activate_click(self,cid):
        if cid==1003:
            self._close_current_window()
        elif cid==7000:
            self._set_season_picker(True)
            self.setFocusId(7001)
        elif cid==7001:
            self._change_season()
        elif 6000<=cid<=6004:
            index=cid-6000
            self._select_tab(index)
            self.setFocusId(6101 if index==4 else 7000 if index==0 and self._seasons() else self._panel_id(index))
        elif cid in (1000,1001):
            self._play(self.getProperty('cleanui.detail.'+('play_path' if cid==1000 else 'trailer_path')))
        elif cid==1002:
            if self.PLATFORM=='disney':
                self.controller.repository.add_detail_to_watchlist(self.screen.hero)
                xbmcgui.Dialog().notification('Disney+','Añadido a Mi lista')
            else:
                action=self.getProperty('cleanui.detail.watchlist_action')
                if action:
                    xbmc.executebuiltin(action)
        elif 4000<=cid<4004 or 4300<=cid<4304:
            self._open_selected(cid)

    def _open_selected(self,cid):
        index=self.getControl(cid).getSelectedPosition()
        cards=self.screen.rails[cid-(4300 if cid>=4300 else 4000)].items
        if not 0<=index<len(cards):
            return
        card=cards[index]
        if card.navigation:
            target=card.navigation
            if target.get('kind')=='season':
                self.controller.load_navigation(self,
                    lambda:self.controller.repository.build_episode_rail(target['id'],target['title'],target.get('page',1)),
                    self._apply_episode_page)
                return
            self.controller._open_home_like(lambda:self.controller.repository.build_navigation(target),
                                           'content',target.get('screen_kind','episodes'))
        elif card.kind=='page':
            self.controller.open_next_page(card,self)
        elif card.action_role=='play' or card.kind in (C.KIND_EPISODE,C.KIND_VIDEO):
            self._play(card.play_path)
        elif card.kind==C.KIND_MOVIE and card.deeplink_id:
            self.controller.open_movie(card.deeplink_id)
        elif card.kind==C.KIND_SHOW and card.show_id:
            self.controller.open_show(card.show_id)
        elif card.kind==C.KIND_SEASON:
            self.controller.open_season(card.show_id,card.season_id)
        elif card.browse_id:
            self.controller.open_collection(card.browse_id,card.label)
        else:
            raise ValueError('Contenido sin acción disponible')

    def _play(self,path):
        if not path:
            raise ValueError('El servicio no entregó una reproducción')
        self.controller.play(path)

    def _apply_episode_page(self,rail):
        from copy import copy
        self.capture_state()
        previous=self.screen
        self._page_history=getattr(self,'_page_history',[])+[previous]
        self.screen=copy(previous)
        self.screen.rails=[rail]+previous.rails[1:]
        self.screen._cleanui_window_state=None
        self.onInit()
        self.setFocusId(4000)

    def release_resources(self):
        self.controller.cancel_navigation(self)
        self._last_load=None
        for cid in (4000,4001,4002,4003,7001)+((4300,4301,4302,4303) if self.PLATFORM=='max' else ()):
            self.getControl(cid).reset()
        for key in ('fanart','logo','plot','summary','play_path','trailer_path'):
            self.setProperty('cleanui.detail.'+key,'')
