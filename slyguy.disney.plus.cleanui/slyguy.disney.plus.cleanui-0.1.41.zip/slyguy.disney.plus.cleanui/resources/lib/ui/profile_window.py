import traceback

import xbmc
import xbmcaddon
import xbmcgui


class ProfileWindow(xbmcgui.WindowXMLDialog):
    """Disney-style profile picker backed by the existing SlyGuy profile API."""

    LIST_ID = 6000
    CANCEL_ACTIONS = (9, 10, 92)

    def __init__(self, *args, **kwargs):
        self.profiles = list(kwargs.pop('profiles', []) or [])
        self.default = int(kwargs.pop('default', 0) or 0)
        self.selected = None
        super(ProfileWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            control = self.getControl(self.LIST_ID)
            width = min(1820, max(260, len(self.profiles) * 260))
            control.setWidth(width)
            control.setPosition((1920 - width) // 2, 350)
            control.reset()
            for profile in self.profiles:
                item = xbmcgui.ListItem(label=profile.get('name') or '')
                avatar = profile.get('_avatar') or ''
                item.setArt({'thumb': avatar, 'icon': avatar})
                item.setProperty(
                    'cleanui.profile.pin',
                    'true' if profile.get('_cleanui_has_pin') else 'false',
                )
                control.addItem(item)
            if self.profiles:
                control.selectItem(max(0, min(self.default, len(self.profiles) - 1)))
                self.setFocus(control)
        except Exception:
            xbmcgui.Dialog().ok('Disney+', 'No se pudieron mostrar los perfiles.')
            self.close()

    def onClick(self, control_id):
        if control_id != self.LIST_ID:
            return
        try:
            index = self.getControl(self.LIST_ID).getSelectedPosition()
            if 0 <= index < len(self.profiles):
                self.selected = self.profiles[index]
        except Exception:
            xbmc.log('[CLEANUI] ProfileWindow.onClick:\n{}'.format(traceback.format_exc()), xbmc.LOGERROR)
        self.close()

    def onAction(self, action):
        if action.getId() in self.CANCEL_ACTIONS:
            self.close()


def select_profile(profiles, default):
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    window = ProfileWindow(
        'uiprofiles.xml', addon_path, 'Default', '1080i',
        profiles=profiles, default=default,
    )
    window.doModal()
    selected = window.selected
    del window
    return selected
