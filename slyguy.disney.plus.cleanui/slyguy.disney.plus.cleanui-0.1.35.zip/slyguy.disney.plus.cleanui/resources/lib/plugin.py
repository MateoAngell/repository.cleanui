import json
import time
from base64 import b64decode

from slyguy import plugin, gui, userdata, signals, inputstream, monitor
from slyguy.exceptions import PluginError
from slyguy.constants import KODI_VERSION, NO_RESUME_TAG, ROUTE_RESUME_TAG
from slyguy.drm import is_wv_secure

from .api import API
from .constants import *
from .language import _
from .settings import settings, Ratio


import xbmc
import threading
import time

api = API()


class _LatamAudioPlayer(xbmc.Player):
    _MAX_ATTEMPTS = 5
    _RETRY_DELAY_MS = 250
    _ARM_TIMEOUT_SECONDS = 30.0

    def __init__(self):
        xbmc.Player.__init__(self)
        self._lock = threading.RLock()
        self._state = 'done'
        self._generation = 0
        self._armed_at = 0.0

    @staticmethod
    def _language_priority(stream):
        if not isinstance(stream, str):
            return None

        language = stream.strip().lower().replace('_', '-')

        if language == 'es-419':
            return 0

        if language.startswith('es-') and language != 'es-es':
            return 1

        if language == 'es':
            return 2

        if language == 'es-es':
            return 3

        if language == 'spa':
            return 4

        return None

    def _find_latam_audio_index(self, streams):
        selected_index = None
        selected_priority = None

        for index, stream in enumerate(streams):
            priority = self._language_priority(stream)
            if priority is None:
                continue

            if selected_priority is None or priority < selected_priority:
                selected_index = index
                selected_priority = priority

            if priority == 0:
                break

        return selected_index

    def arm(self):
        with self._lock:
            self._generation += 1
            self._state = 'armed'
            self._armed_at = time.monotonic()

    def onAVStarted(self):
        with self._lock:
            if self._state != 'armed':
                return

            if time.monotonic() - self._armed_at > self._ARM_TIMEOUT_SECONDS:
                self._state = 'done'
                return

            generation = self._generation
            self._state = 'selecting'

        for attempt in range(self._MAX_ATTEMPTS):
            try:
                streams = self.getAvailableAudioStreams()
            except Exception:
                streams = []

            selected_index = self._find_latam_audio_index(streams)
            if selected_index is not None:
                with self._lock:
                    if generation != self._generation or self._state != 'selecting':
                        return

                    try:
                        self.setAudioStream(selected_index)
                    except Exception:
                        pass

                    self._state = 'done'
                return

            if attempt < self._MAX_ATTEMPTS - 1:
                xbmc.sleep(self._RETRY_DELAY_MS)

        with self._lock:
            if generation == self._generation and self._state == 'selecting':
                self._state = 'done'


_latam_audio_player = _LatamAudioPlayer()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


_CLEANUI_RUNNING_PROPERTY = 'DisneyPlusCleanUI.Running'


def _cleanui_is_running():
    """
    Indica si ya existe una sesión visual de Clean UI activa.
    Se usa una propiedad temporal de Kodi, no userdata. De esa manera:
    - se conserva mientras se reproduce y restauran las ventanas;
    - se elimina al salir de Clean UI;
    - no impide seleccionar perfil en una apertura futura.
    """
    import xbmcgui

    return (
        xbmcgui.Window(10000).getProperty(
            _CLEANUI_RUNNING_PROPERTY
        ) == 'true'
    )


def _cleanui_set_running(value):
    import xbmcgui

    window = xbmcgui.Window(10000)
    if value:
        window.setProperty(_CLEANUI_RUNNING_PROPERTY, 'true')
    else:
        window.clearProperty(_CLEANUI_RUNNING_PROPERTY)


def _cleanui_empty_folder():
    """
    Resuelve la ruta sin disparar el aviso de carpeta vacía de Kodi.
    No añade un elemento centinela: ese elemento podía aparecer como un
    segundo botón «Abrir el add-on» después de cerrar o reabrir la interfaz.
    """
    folder = plugin.Folder(cacheToDisc=False)
    return folder


def _cleanui_exit_folder(controller=None):
    """
    Resuelve la ruta y regresa al Home de Kodi.
    Esta función debe utilizarse únicamente después de una salida explícita,
    una cancelación del selector o un error fatal. Nunca al terminar una
    reproducción ni durante una restauración.
    """
    import xbmc

    folder = _cleanui_empty_folder()

    # La salida del controlador ya usa ReplaceWindow(Home) cuando termina
    # doModal(). No crear otro hilo con ActivateWindow tardío: podía devolver
    # Kodi a Home durante una restauración o una reapertura posterior.
    if controller is None:
        xbmc.executebuiltin('ReplaceWindow(Home)')
    return folder


def _open_cleanui_entry():
    """
    Abre una sesión nueva de Clean UI.
    Si Kodi intenta ejecutar de nuevo la ruta raíz mientras la sesión actual
    sigue activa —por ejemplo durante PlayMedia o la restauración posterior—,
    la ejecución duplicada se ignora. Esto evita un segundo selector y un
    segundo UIController.
    """
    import traceback
    import xbmc
    import xbmcgui

    # Reentrada automática/duplicada de Kodi.
    #
    # No abrir otra interfaz, no preguntar perfil y, especialmente,
    # no ejecutar ActivateWindow(Home).
    if _cleanui_is_running():
        xbmc.log(
            '[CLEANUI] Entrada duplicada ignorada: ya existe una sesión activa',
            xbmc.LOGWARNING,
        )
        return _cleanui_empty_folder()

    controller = None
    go_home = False

    # Marcar la sesión antes de abrir el selector. Así tampoco puede aparecer
    # un segundo selector si Kodi vuelve a invocar la ruta mientras el primero
    # todavía está visible.
    _cleanui_set_running(True)
    try:
        xbmc.log(
            '[CLEANUI] Apertura nueva: mostrando selector de perfil',
            xbmc.LOGINFO,
        )
        # En una apertura real se pregunta siempre el perfil.
        if not _select_profile():
            xbmc.log(
                '[CLEANUI] Selector de perfil cancelado',
                xbmc.LOGINFO,
            )
            go_home = True
            return _cleanui_exit_folder(controller=controller)

        from .ui.controller import UIController

        controller = UIController()
        if not controller.open_home():
            xbmc.log(
                '[CLEANUI] No se pudo iniciar la pantalla Home',
                xbmc.LOGERROR,
            )
            go_home = True
            return _cleanui_exit_folder(controller=controller)

        # open_home() solo debería finalizar normalmente cuando el usuario
        # sale desde el Home de Clean UI.
        if controller.exit_requested:
            xbmc.log(
                '[CLEANUI] Salida explícita confirmada por UIController',
                xbmc.LOGINFO,
            )
            go_home = True
            return _cleanui_exit_folder(controller=controller)

        # Si termina sin una petición de salida, no ejecutar Home
        # automáticamente. Puede tratarse de un cierre anómalo o de Kodi
        # resolviendo ventanas.
        xbmc.log(
            '[CLEANUI] UIController terminó sin petición explícita de salida',
            xbmc.LOGWARNING,
        )
        return _cleanui_empty_folder()
    except Exception:
        xbmc.log(
            '[CLEANUI] Error fatal abriendo la interfaz:\n{}'.format(
                traceback.format_exc()
            ),
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().ok(
            'Disney+ Clean UI - Error',
            'No se pudo abrir la interfaz.\n\n'
            'Revisa kodi.log y busca [CLEANUI].',
        )
        go_home = True
        return _cleanui_exit_folder(controller=controller)
    finally:
        # La ejecución duplicada sale antes de llegar a este bloque.
        # Por tanto, aquí solo se limpia la sesión propietaria original.
        _cleanui_set_running(False)
        xbmc.log(
            '[CLEANUI] Sesión visual finalizada; go_home={}'.format(
                go_home
            ),
            xbmc.LOGINFO,
        )


@plugin.route('')
def index(**kwargs):
    if not api.logged_in:
        folder = plugin.Folder(cacheToDisc=False)
        folder.add_item(
            label=_(_.LOGIN, _bold=True),
            path=plugin.url_for(login),
            bookmark=False,
        )
        return folder

    return _open_cleanui_entry()


@plugin.route()
def home(**kwargs):
    return _deeplink_page('home')


@plugin.route()
def movies(**kwargs):
    return _deeplink_page('movies')


@plugin.route()
def series(**kwargs):
    return _deeplink_page('series')


@plugin.route()
def originals(**kwargs):
    return _deeplink_page('originals')


def _deeplink_page(ref_id):
    data = api.deeplink(ref_id=ref_id)
    page_id = _get_actions(data)[BROWSE]['pageId']
    data = api.page(page_id, limit=1, enhanced_limit=99)
    return _process_rows(data)


@plugin.route()
@plugin.pagination()
def brands(page=1, **kwargs):
    data = api.set(BRANDS_ID, page=page)
    folder = _process_rows(data)
    return folder, data['pagination']['hasMore']


@plugin.route()
@plugin.pagination()
def continue_watching(page=1, **kwargs):
    data = api.set(CONTINUE_WATCHING_ID, page=page, _skip_cache=True)
    folder = _process_rows(data, title=_.CONTINUE_WATCHING, continue_watching=True)
    return folder, data['pagination']['hasMore']


@plugin.route()
def watchlist(**kwargs):
    data = api.deeplink(ref_id='watchlist')
    page_id = _get_actions(data)[BROWSE]['pageId']
    data = api.page(page_id, limit=1, enhanced_limit=15, _skip_cache=True)
    return _process_rows(data, title=_.WATCHLIST, watchlist=True, flatten=True)


@plugin.route()
def add_watchlist(deeplink_id, **kwargs):
    with gui.busy():
        data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')))
        info = _get_info(data)
        api.edit_watchlist('add', page_info=data['infoBlock'], action_info=info[ACTIONS][MODIFYSAVES]['infoBlock'])
    gui.notification(_.ADDED_WATCHLIST, heading=info['title'], icon=info['art'].get('poster') or info['art'].get('thumb'))


@plugin.route()
def delete_watchlist(deeplink_id, **kwargs):
    # TODO: remove list item and dont refresh
    with gui.busy():
        data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')))
        info = _get_info(data)
        api.edit_watchlist('remove', page_info=data['infoBlock'], action_info=info[ACTIONS][MODIFYSAVES]['infoBlock'])
        # above is async so wait a bit to make sure its removed from list refresh
        time.sleep(1.5)
    gui.refresh()


@plugin.route()
def remove_continue_watching(deeplink_id, **kwargs):
    # TODO: remove list item and dont refresh
    with gui.busy():
        data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')))
        info = _get_info(data)
        api.remove_continue_watching(action_info=info[ACTIONS][REMOVECONTINUEWATCHING]['infoBlock'])
        # above is async so wait a bit to make sure its removed from list refresh
        time.sleep(1.5)
    gui.refresh()


@plugin.route()
@plugin.search()
def search(query, page, **kwargs):
    data = api.search(query)
    return _process_rows(data['containers'][0]).items if data['containers'] else [], False


@plugin.route()
@plugin.no_error_gui()
def callback(media_id, fguid, _time, **kwargs):
    api.update_resume(media_id, fguid, int(_time))


@plugin.route()
def page(page_id, **kwargs):
    data = api.page(page_id, limit=1, enhanced_limit=99)
    return _process_rows(data, flatten=True)


@plugin.route()
@plugin.pagination()
def set(set_id, watchlist=0, page=1, **kwargs):
    data = api.set(set_id, page=page, _skip_cache=bool(int(watchlist)))
    folder = _process_rows(data, watchlist=bool(int(watchlist)))
    return folder, data['pagination']['hasMore']


@plugin.route()
@plugin.pagination()
def season(show_id, season_id, page=1, **kwargs):
    show_data = api.page(show_id)
    data = api.season(season_id, page=page)
    folder = _process_rows(data, title=show_data['visuals']['title'])
    show_art = _get_art(show_data)
    for key in show_art:
        if key != 'poster' and not folder.art.get(key):
            folder.art[key] = show_art[key]
    return folder, data['pagination']['hasMore']


def _get_actions(data):
    actions = {
        BROWSE: {},
        PLAYBACK: {},
        TRAILER: {},
        MODIFYSAVES: {},
        REMOVECONTINUEWATCHING: {},
        MODAL: {},
        UPSELL: False,
    }
    for row in data.get('actions', []):
        if row['type'] == 'upsell':
            actions = _get_actions(row)
            actions[UPSELL] = True
        elif row['type'] == 'browse':
            actions[BROWSE] = row
        elif row['type'] == 'playback':
            actions[PLAYBACK] = row
        elif row['type'] == 'trailer':
            actions[TRAILER] = row
        elif row['type'] == 'modifySaves':
            actions[MODIFYSAVES] = row
        elif row['type'] == 'contextMenu':
            for sub_row in row.get('actions', []):
                if sub_row['type'] == 'removeFromContinueWatching':
                    actions[REMOVECONTINUEWATCHING] = sub_row
        elif row['type'] == 'modal':
            actions[MODAL] = row
    actions[PLAYBACK] = actions[PLAYBACK] or actions[BROWSE]
    return actions


def _get_play_path(**kwargs):
    if not kwargs:
        return None

    profile_id = userdata.get('profile_id')
    if profile_id:
        kwargs['profile_id'] = profile_id

    return plugin.url_for(play, **kwargs)


def _get_info(data):
    actions = _get_actions(data)
    containers = {
        EPISODES: {'seasons': []},
        SUGGESTED: {},
        EXTRAS: {},
        DETAILS: {'visuals': {}},
    }
    for row in data.get('containers', []):
        if row['type'] == 'episodes':
            containers[EPISODES] = row
        elif row['type'] == 'details':
            containers[DETAILS] = row
        elif row.get('id') == SUGGESTED_ID:
            containers[SUGGESTED] = row
        elif row.get('id') == EXTRAS_ID:
            containers[EXTRAS] = row

    description = containers[DETAILS]['visuals'].get('description') or data['visuals'].get('description', {})
    plot = description.get('medium') or description.get('brief') or description.get('full')
    title = containers[DETAILS]['visuals'].get('title') or data['visuals'].get('title')
    if actions[UPSELL]:
        title = u'{} {}'.format(title, _(_.LOCKED, _bold=True, _color="red"))

    # only works for episodes as movies in list views dont give us the legacy id
    legacy_id = actions[PLAYBACK].get('legacyPartnerFeed', {}).get('dmcContentId') or actions[PLAYBACK].get('partnerFeed',{}).get('dmcContentId')
    if legacy_id:
        # try keep old paths for kodi db watch status
        playpath = _get_play_path(content_id=legacy_id)
    elif 'deeplinkId' in actions[PLAYBACK]:
        # new content has no legacy ids, so needs to use deeplink
        playpath = _get_play_path(deeplink_id=actions[PLAYBACK]['deeplinkId'])
    else:
        playpath = None

    return {'title': title, 'plot': plot, CONTAINERS: containers, ACTIONS: actions, 'art': _get_art(data), 'playpath': playpath}


@plugin.route()
def show(show_id, **kwargs):
    data = api.page(show_id, limit=1, enhanced_limit=15)
    info = _get_info(data)

    folder = plugin.Folder(info['title'], art=info['art'])
    for row in info[CONTAINERS][EPISODES]['seasons']:
        folder.items.append(plugin.Item(
            label = row['visuals']['name'],
            info = {
                'plot': u'{}\n\n{}'.format(info['plot'], _(row['visuals']['episodeCountDisplayText'], _bold=True)),
                'tvshowtitle': info['title'],
                'mediatype': 'season',
            },
            art = _get_art(row),
            path = plugin.url_for(season, show_id=data['id'], season_id=row['id']),
        ))

    if info[ACTIONS][TRAILER]:
        folder.items.append(plugin.Item(
            label = _.TRAILER,
            info = {
                'plot': info['plot'],
                'mediatype': 'video',
            },
            path = plugin.url_for(play_trailer, deeplink_id=data['id']),
            playable = True,
            specialsort = 'bottom',
        ))

    if info[CONTAINERS][SUGGESTED]:
        folder.items.append(plugin.Item(
            label = _.SUGGESTED,
            info = {
                'plot': info['plot'],
            },
            path = plugin.url_for(suggested, deeplink_id=data['id']),
            specialsort = 'bottom',
        ))

    if info[CONTAINERS][EXTRAS]:
        folder.items.append(plugin.Item(
            label = _.EXTRAS,
            info = {
                'plot': info['plot'],
            },
            path = plugin.url_for(extras, deeplink_id=data['id']),
            specialsort = 'bottom',
        ))

    return folder


def _process_rows(data, title=None, watchlist=False, flatten=False, continue_watching=False):
    if not data or 'visuals' not in data:
        return plugin.Folder(title)

    title = title or data['visuals'].get('title') or data['visuals'].get('name')
    folder = plugin.Folder(title, art=_get_art(data))
    rows = data.get('containers') or data.get('items') or []

    user_states = {}
    if settings.SYNC_PLAYBACK.value:
        pids = [row.get('personalization',{}).get('pid') for row in rows if row['visuals'].get('durationMs')]
        pids = [x for x in pids if x]
        if pids:
            user_states = api.userstates(pids)

    items = []
    for row in rows:
        # flatten inline single heros
        if row['type'] == 'set' and row['style']['name'] == 'hero_inline_single' and len(row['items']) == 1:
            row = row['items'][0]

        if row['type'] == 'set':
            if 'hero' in row['style']['name'].lower() or 'brand' in row['style']['name'].lower() or 'continue_watching' in row['style']['name'].lower():
                continue

            kwargs = {'set_id': row['id']}
            if watchlist:
                kwargs['watchlist'] = 1

            item = plugin.Item(
                label = row['visuals']['name'],
                art = _get_art(row),
                path = plugin.url_for(set, **kwargs),
            )
            items.append(item)

        elif row.get('actions', []):
            # MOVIE / TV SHOW / EPISODE / REPLAY / LIVE
            item = _parse_row(row)
            _add_progress(user_states.get(row['personalization']['pid']), item)
            if settings.SYNC_WATCHLIST.value and watchlist:
                item.context = [x for x in item.context if x[0] != _.ADD_WATCHLIST]
                item.context.insert(0, (_.DELETE_WATCHLIST, 'RunPlugin({})'.format(plugin.url_for(delete_watchlist, deeplink_id=row['actions'][0]['deeplinkId']))))
            if settings.SYNC_PLAYBACK.value and continue_watching:
                item.context = [x for x in item.context if x[0] != _.ADD_WATCHLIST]
                item.context.insert(0, (_.REMOVE_CONTINUE_WATCHING, 'RunPlugin({})'.format(plugin.url_for(remove_continue_watching, deeplink_id=row['actions'][0]['deeplinkId']))))
            items.append(item)

    if flatten and len(items) == 1:
        return plugin.redirect(items[0].path)

    folder.add_items(items)
    return folder


def _parse_episode(data):
    info = _get_info(data)

    item = plugin.Item(
        label = data['visuals']['episodeTitle'],
        art = info['art'],
        info = {
            'plot': info['plot'],
            'season': data['visuals'].get('seasonNumber'),
            'episode': data['visuals'].get('episodeNumber'),
            'tvshowtitle': info['title'],
            'duration': int(data['visuals'].get('durationMs', 0) / 1000),
            'mediatype': 'episode',
        },
        playable = True,
        path = info['playpath'],
    )
    return item


def _parse_page(data):
    info = _get_info(data)

    item = plugin.Item(
        label = info['title'],
        art = info['art'],
        info = {
            'plot': info['plot'],
        },
        path = plugin.url_for(page, page_id=info[ACTIONS][BROWSE]['pageId']),
    )
    return item


def _parse_event(data):
    import arrow
    info = _get_info(data)
    meta = data['visuals'].get('metastringParts', {})
    is_live = data['visuals']['badging']['airingEventState']['state'] == 'live'
    actions = info[ACTIONS]
    if actions[MODAL]:
        actions = _get_actions(info[ACTIONS][MODAL])
        info['art'] = _get_art(info[ACTIONS][MODAL])

    if actions[PLAYBACK].get('contentType') == 'linear':
        start_time = arrow.get(data['visuals']['badging']['airingEventState']['timeline']['startTime']).to('local')
        end_time = arrow.get(data['visuals']['badging']['airingEventState']['timeline']['endTime']).to('local')
        plot = u'[B]{} - {}[/B]\n{}'.format(start_time.format('h:mmA').lower(), end_time.format('hh:mmA').lower(), info['title'])

        if data['visuals'].get('episodeTitle') and data['visuals']['episodeTitle'] != info['title']:
            try:
                plot += u'\n\nS{}:E{}\n{}'.format(data['visuals']['seasonNumber'], data['visuals']['episodeNumber'], data['visuals']['episodeTitle'])
            except KeyError:
                plot += u'\n\n{}'.format(data['visuals']['episodeTitle'])

        if info['plot']:
            plot += u'\n\n{}'.format(info['plot'])

        try:
            info['art']['clearlogo'] = 'https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/disney/{}/scale?width=800&aspectRatio=1.78'.format(
                data['visuals']['networkAttribution']['artwork']['brand']['logo']['2.00']['imageId'])
        except KeyError:
            pass

        resource_data = json.loads(b64decode(actions[PLAYBACK]['resourceId']).decode("utf-8"))
        item = plugin.Item(
            label = data['visuals']['networkAttribution']['ttsText'],
            info = {
                'plot': plot,
                'mediatype': 'video',
            },
            art = info['art'],
            playable = True,
            path = _get_play_path(channel_id=resource_data['channelId'], _is_live=True),
        )
        # if data['visuals'].get('episodeNumber'):
        #     item.context.append(("Play VOD", 'RunPlugin({})'.format(_get_play_path(deeplink_id=actions[PLAYBACK]['deeplinkId']))))
    else:
        item = plugin.Item(
            label = info['title'],
            art = info['art'],
            info = {
                'plot': info['plot'],
                'mediatype': 'video',
            },
            playable = True,
            path = _get_play_path(deeplink_id=actions[PLAYBACK]['deeplinkId'], _is_live=is_live),
        )
        if settings.SYNC_WATCHLIST.value:
            item.context.append((_.ADD_WATCHLIST, 'RunPlugin({})'.format(plugin.url_for(add_watchlist, deeplink_id=actions[PLAYBACK]['deeplinkId']))))
        # TODO: Watch from live / start

    if 'sportsLeague' in meta:
        league = meta['sportsLeague']['name']
        if 'releaseYearRange' in meta:
            league = u'{} - {}'.format(league, meta['releaseYearRange']['startYear'])
        item.info['plot'] = u'[B]{}[/B]\n\n{}'.format(league, item.info['plot'])

    if data['visuals']['badging']['airingEventState']['state'] not in ('replay',):
        item.label = u'[B][{}][/B] {}'.format(data['visuals']['badging']['airingEventState']['badgeLabel'], item.label)

    if 'prompt' in data['visuals'] and not info[ACTIONS][MODAL]:
        item.info['plot'] = u'[B]{}[/B]\n{}'.format(data['visuals']['prompt'], item.info['plot'])

    return item


def _parse_movie(data):
    info = _get_info(data)
    meta = data['visuals'].get('metastringParts', {})

    item = plugin.Item(
        label = info['title'],
        art = info['art'],
        info = {
            'plot': info['plot'],
            'duration': int(meta['runtime']['runtimeMs'] / 1000),
            'trailer': plugin.url_for(play_trailer, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']),
            'mediatype': 'movie',
        },
        playable = True,
        path = info['playpath'],
    )

    if 'releaseYearRange' in meta:
        item.info['year'] = meta['releaseYearRange']['startYear']

    if settings.SYNC_WATCHLIST.value:
        item.context.append((_.ADD_WATCHLIST, 'RunPlugin({})'.format(plugin.url_for(add_watchlist, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    item.context.append((_.EXTRAS, "Container.Update({})".format(plugin.url_for(extras, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    item.context.append((_.SUGGESTED, "Container.Update({})".format(plugin.url_for(suggested, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    return item


def _parse_show(data):
    info = _get_info(data)
    meta = data['visuals'].get('metastringParts', {})

    item = plugin.Item(
        label = info['title'],
        art = info['art'],
        info = {
            'plot': info['plot'],
            'trailer': plugin.url_for(play_trailer, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']),
            'mediatype': 'tvshow',
        },
    )

    # this not available when quering the show entity directly
    if info[ACTIONS][BROWSE]:
        item.path = plugin.url_for(show, show_id=info[ACTIONS][BROWSE]['pageId'])

    if 'releaseYearRange' in meta:
        item.info['year'] = meta['releaseYearRange']['startYear']

    if settings.SYNC_WATCHLIST.value:
        item.context.append((_.ADD_WATCHLIST, 'RunPlugin({})'.format(plugin.url_for(add_watchlist, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    item.context.append((_.EXTRAS, "Container.Update({})".format(plugin.url_for(extras, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    item.context.append((_.SUGGESTED, "Container.Update({})".format(plugin.url_for(suggested, deeplink_id=info[ACTIONS][PLAYBACK]['deeplinkId']))))
    return item


def _parse_row(data):
    meta = data['visuals'].get('metastringParts', {})

    if 'airingEventState' in data['visuals'].get('badging', {}):
        item = _parse_event(data)

    elif 'episodeTitle' in data['visuals']:
        item = _parse_episode(data)

    elif 'runtime' in meta:
        item = _parse_movie(data)

    elif meta:
        item = _parse_show(data)

    else:
        item = _parse_page(data)

    if 'genres' in meta:
        item.info['genre'] = meta['genres']['values']

    if 'ratingInfo' in meta:
        item.info['rating'] = meta['ratingInfo']['rating']['text']

    return item


@plugin.route()
def play_trailer(deeplink_id, **kwargs):
    with gui.busy():
        data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')))
        info = _get_info(data)
        item = _parse_row(data)

        item = plugin.get_trailer_item(item, check=not info[ACTIONS][TRAILER])
        if info[ACTIONS][TRAILER]:
            item.inputstream = inputstream.Widevine(
                license_key = api.get_config()['services']['drm']['client']['endpoints']['widevineLicense']['href'],
                manifest_type = 'hls',
                mimetype = 'application/vnd.apple.mpegurl',
                wv_secure = is_wv_secure(),
                license_headers = _license_headers(),
            )
            playback_data = api.playback(info[ACTIONS][TRAILER]['resourceId'], item.inputstream.wv_secure)
            item.path = playback_data['stream']['sources'][0]['complete']['url']
            item.headers = _manifest_headers()

        return item


@plugin.route()
def extras(deeplink_id, **kwargs):
    data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')), enhanced_limit=15)
    info = _get_info(data)
    return _process_rows(info[CONTAINERS][EXTRAS], title=u"{} ({})".format(info['title'], _.EXTRAS))


@plugin.route()
def suggested(deeplink_id, **kwargs):
    data = api.page('entity-{}'.format(deeplink_id.replace('entity-', '')), enhanced_limit=15)
    info = _get_info(data)
    return _process_rows(info[CONTAINERS][SUGGESTED], title=u"{} ({})".format(info['title'], _.SUGGESTED))


def _add_progress(user_state, item):
    if (
        not user_state
        or not item
        or not settings.SYNC_PLAYBACK.value
    ):
        return

    progress = user_state.get('progress') or {}
    try:
        percentage = float(
            progress.get('progressPercentage') or 0
        )
    except (TypeError, ValueError):
        percentage = 0

    if percentage >= 100:
        item.info['playcount'] = 1
        return

    if percentage <= 0:
        return

    item.info['playcount'] = 0

    try:
        duration = int(item.info.get('duration') or 0)
    except (TypeError, ValueError):
        duration = 0

    if duration <= 0:
        return

    if progress.get('secondsRemaining') is not None:
        try:
            seconds_remaining = int(
                progress.get('secondsRemaining') or 0
            )
            resume_from = duration - seconds_remaining
        except (TypeError, ValueError):
            resume_from = 0
    else:
        resume_from = int(
            percentage / 100.0 * duration
        )

    item.resume_from = max(
        0,
        min(resume_from, duration),
    )


def _set_if_missing(target, key, value):
    """Escribe value en target[key] solo si la clave aún no tiene valor."""
    if value and not target.get(key):
        target[key] = value


def _get_art(row):
    if not isinstance(row, dict):
        return {}

    visuals = row.get('visuals') or {}
    artwork = visuals.get('artwork') or {}
    standard = artwork.get('standard') or {}
    if not isinstance(standard, dict):
        return {}

    is_episode = 'episodeTitle' in visuals
    # Copiar el diccionario. No modificar la respuesta original de la API.
    images = dict(standard)

    tile = artwork.get('tile') or {}
    if isinstance(tile, dict) and tile.get('background'):
        images['hero_tile'] = tile['background']

    network = artwork.get('network') or {}
    if isinstance(network, dict) and network.get('tile'):
        images['thumbnail'] = network['tile']

    # Prioridad explícita de fondo: hero > brand > up_next. No sobrescribe
    # según el orden del JSON.
    for key in ('hero', 'brand', 'up_next'):
        source = artwork.get(key) or {}
        if isinstance(source, dict) and source.get('background'):
            images['background'] = source['background']
            break

    def _first_image_url(image_data):
        image_id = (image_data or {}).get('imageId')
        if not image_id:
            return ''
        return (
            'https://disney.images.edge.bamgrid.com/'
            'ripcut-delivery/v2/variant/disney/{}'
        ).format(image_id)

    art = {}
    # don't ask for jpeg thumb; might be transparent png instead
    # Tamaños ajustados para una interfaz 1080p y dispositivos con poca RAM.
    # Los posters y miniaturas nunca se muestran a 800 px reales en los rails.
    # Tamaños ajustados para una interfaz 1080p y dispositivos con poca RAM.
    # Los posters y miniaturas nunca se muestran a 800 px reales en los rails.
    thumbsize = '/scale?width=600&aspectRatio=1.78'
    bannersize = '/scale?width=1080&aspectRatio=1.78&format=jpeg'
    fullsize = '/scale?width=1280&aspectRatio=1.78&format=jpeg'
    # Perfil JPEG para miniaturas/posters fotográficos: menos peso y
    # decodificación más rápida que PNG. No se usa en watermark/logos
    # (que pueden ser PNG transparentes, véase thumbsize original).
    thumb_jpeg = '/scale?width=600&aspectRatio=1.78&format=jpeg'
    poster_jpeg = '/scale?width=600&aspectRatio=0.71&format=jpeg'

    thumb_ratios = ['1.78', '1.33', '1.00']
    poster_ratios = ['0.71', '0.75', '0.80']
    clear_ratios = ['2.00', '1.78', '3.32']
    banner_ratios = ['3.91', '3.00', '1.78']
    watermark_used = False

    if is_episode:
        thumbs = ('thumbnail',)
    else:
        thumbs = ('thumbnail', 'tile', 'watermark')

    fanart_count = 0
    for name, art_type in images.items():
        if not isinstance(art_type, dict):
            continue

        tr = next(
            (ratio for ratio in thumb_ratios if ratio in art_type),
            '',
        )
        br = next(
            (ratio for ratio in banner_ratios if ratio in art_type),
            '',
        )
        pr = next(
            (ratio for ratio in poster_ratios if ratio in art_type),
            '',
        )
        cr = next(
            (ratio for ratio in clear_ratios if ratio in art_type),
            '',
        )

        if name in thumbs:
            if tr:
                url = _first_image_url(art_type.get(tr))
                if url:
                    size = thumbsize if name == 'watermark' else thumb_jpeg
                    if name == 'watermark':
                        had_thumb = bool(art.get('thumb'))
                        _set_if_missing(art, 'thumb', url + size)
                        if not had_thumb and art.get('thumb') == url + size:
                            watermark_used = True
                    else:
                        _set_if_missing(art, 'thumb', url + size)
            if pr:
                url = _first_image_url(art_type.get(pr))
                if url:
                    _set_if_missing(art, 'poster', url + poster_jpeg)

        elif name == 'hero_tile':
            if br:
                url = _first_image_url(art_type.get(br))
                if url:
                    art['banner'] = url + bannersize

        elif name in ('hero_collection', 'background_details', 'background'):
            if tr:
                url = _first_image_url(art_type.get(tr))
                if url:
                    key = (
                        'fanart{}'.format(fanart_count)
                        if fanart_count
                        else 'fanart'
                    )
                    art[key] = url + fullsize
                    fanart_count += 1
            if pr:
                url = _first_image_url(art_type.get(pr))
                if url:
                    art['keyart'] = url + bannersize

        elif name in ('title_treatment', 'logo'):
            if cr:
                url = _first_image_url(art_type.get(cr))
                if url:
                    art['clearlogo'] = url + thumbsize

    if is_episode or watermark_used:
        art.pop('poster', None)

    return art


def _get_milestone(milestones, name, default=0):
    for row in milestones or []:
        if not isinstance(row, dict):
            continue
        if row.get('label') != name:
            continue
        try:
            return max(
                0,
                int(row.get('offsetMillis') or 0) // 1000,
            )
        except (TypeError, ValueError):
            return default
    return default


@plugin.route()
@plugin.login_required()
def play(**kwargs):
    return _play(**kwargs)


def _license_headers():
    return api.session.headers


def _manifest_headers():
    return {'User-Agent': api.session.headers['User-Agent']}


def _play(family_id=None, content_id=None, deeplink_id=None, channel_id=None, **kwargs):
    if KODI_VERSION > 18:
        ver_required = '2.6.0'
    else:
        ver_required = '2.4.5'

    ia = inputstream.Widevine(
        manifest_type = 'hls',
        mimetype = 'application/vnd.apple.mpegurl',
        wv_secure = is_wv_secure(),
        license_headers = _license_headers(),
    )
    if (
        not ia.check()
        or not inputstream.require_version(ver_required)
    ):
        gui.ok(
            _(
                _.IA_VER_ERROR,
                kodi_ver=KODI_VERSION,
                ver_required=ver_required,
            )
        )
        return None

    if channel_id:
        data = api.deeplink(channel_id, ref_type='channelId', action='playback')
    elif content_id:
        data = api.deeplink(content_id, ref_type='dmcContentId', action='playback')
    elif family_id:
        data = api.deeplink(family_id, ref_type='encodedFamilyId', action='playback')
    else:
        data = api.deeplink(deeplink_id.replace('entity-', ''), action='playback')

    deeplink_id = data['actions'][0]['deeplinkId'].replace('entity-', '')
    resource_id = data['actions'][0]['resourceId']
    available_id = data['actions'][0]['availId']
    upnext_id = data['actions'][0].get('upNextId')
    is_linear = data['actions'][0].get('contentType') == 'linear'

    player_experience = api.player_experience(available_id)
    program_type = player_experience['analytics']['programType']

    flags = []
    item = plugin.Item()

    #TODO: dont need to do this if clicking from existing listitem with all info
    # skip this if we already have good info
    if is_linear:
        # TODO channel list item data
        pass
    elif program_type == 'movie':
        data = api.page('entity-{}'.format(deeplink_id))
        flags = [x['value'] for x in data['visuals']['metastringParts']['audioVisual']['flags']]
        item = _parse_row(data)
    elif program_type == 'episode':
        # TODO: this is a few requests and needs ugly season name matching. Ideally an api endpoint for episode details exist
        season_name = player_experience['subtitle'].split(':')[0].lower().strip().lstrip('s')
        show = api.page(data['actions'][1]['pageId'], limit=0, enhanced_limit=0)
        for row in show['containers'][0]['seasons']:
            # TODO: this probably doesnt work for non-english
            if row['visuals']['name'].lower().endswith(season_name):
                data = api.season(row['id'])
                for row in data['items']:
                    if row['actions'][0]['deeplinkId'].replace('entity-', '') == deeplink_id:
                        item = _parse_row(row)
                        break
                break

    if 'imax_enhanced' in flags:
        default_ratio = settings.DEFAULT_RATIO.value

        if default_ratio == Ratio.ASK:
            index = gui.context_menu([_.IMAX, _.WIDESCREEN])
            if index == -1:
                return
            imax = index == 0
        else:
            imax = default_ratio == Ratio.IMAX

        profile = api.profile()[0]
        if imax != profile['attributes']['playbackSettings']['preferImaxEnhancedVersion']:
            api.set_imax(imax)

    playback_data = api.playback(resource_id, ia.wv_secure)

    # LEGACY RESUME (Remove once legacy browsing removed)
    if not kwargs.get(ROUTE_RESUME_TAG):
        if content_id and settings.SYNC_PLAYBACK.value and NO_RESUME_TAG in kwargs and playback_data['playhead']['status'] == 'PlayheadFound':
            item.resume_from = plugin.resume_from(playback_data['playhead']['position'])
            if item.resume_from == -1:
                return

    if is_linear:
        url = playback_data['stream']['sources'][0]['slide']['url']
        ia.license_key = api.get_config()['services']['drm']['client']['endpoints']['widevineLinearLicense']['href']
    else:
        url = playback_data['stream']['sources'][0]['complete']['url']
        ia.license_key = api.get_config()['services']['drm']['client']['endpoints']['widevineLicense']['href']

    item.update(
        playable = True,
        path = url,
        inputstream = ia,
        headers = _manifest_headers(),
        proxy_data = {
            'original_language': player_experience.get('originalLanguage') or '',
        },
    )
    # On disney+ , when subs are disabled - it uses FORCED subs for whatever audio language you are in
    # eg. En Audio -> en--forced. Es audio -> es-forced.

    item.play_skips = []
    milestones = playback_data['stream'].get('editorial', [])
    if milestones and settings.getBool('skip_recaps', False):
        recap_start = _get_milestone(milestones, 'recap_start')
        recap_end = _get_milestone(milestones, 'recap_end')
        if recap_end > recap_start:
            item.play_skips.append({'from': recap_start, 'to': recap_end})

    if milestones and settings.getBool('skip_intros', False):
        intro_start = _get_milestone(milestones, 'intro_start')
        intro_end = _get_milestone(milestones, 'intro_end')
        if intro_end > intro_start:
            item.play_skips.append({'from': intro_start, 'to': intro_end})

    if milestones and settings.getBool('skip_credits', False):
        credits_start = _get_milestone(
            milestones,
            'up_next',
        )
        tag_start = _get_milestone(
            milestones,
            'tag_start',
        )
        tag_end = _get_milestone(
            milestones,
            'tag_end',
        )
        if credits_start > 0:
            if tag_start > credits_start:
                item.play_skips.append({
                    'from': credits_start,
                    'to': tag_start,
                })
            elif not tag_start:
                item.play_skips.append({
                    'from': credits_start,
                    'to': 0,
                })
        if tag_end > 0:
            item.play_skips.append({
                'from': tag_end,
                'to': 0,
            })

    upnext = None
    if upnext_id and program_type == 'episode' and settings.getBool('play_next_episode', True):
        data = api.upnext(upnext_id)
        for row in data.get('items', []):
            if row.get('type') != 'upNext' or not row.get('sequentialEpisode'):
                continue
            upnext = row['item']

    elif upnext_id and program_type == 'movie' and settings.getBool('play_next_movie', False):
        data = api.upnext(upnext_id)
        for row in data.get('items', []):
            if row.get('type') != 'upNext' or row.get('sequentialEpisode'):
                continue
            upnext = row['item']

    if upnext:
        info = _get_info(upnext)
        item.play_next = {'next_file': info['playpath']}

    if settings.SYNC_PLAYBACK.value:
        telemetry = playback_data['tracking']['telemetry']
        item.callback = {
            'type':'interval',
            'interval': 30,
            'callback': plugin.url_for(callback, media_id=telemetry['mediaId'], fguid=telemetry['fguid']),
        }

    _latam_audio_player.arm()

    return item


@plugin.route()
def login(**kwargs):
    options = [
       [_.EMAIL_PASSWORD, _email_password],
    ]
    if KODI_VERSION >= 19: # Python3 only due to aes lib
        options.insert(0, [_.DEVICE_CODE, _device_code])

    index = 0 if len(options) == 1 else gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    _select_profile()
    gui.refresh()


def _device_code():
    timeout = 600
    with api.device_login() as (code, ws):
        with gui.progress_qr(DEVICE_CODE_URL, _(_.DEVICE_LINK_STEPS, code=code, url=DEVICE_CODE_URL), heading=_.DEVICE_CODE) as progress:
            for i in range(timeout):
                if progress.iscanceled() or not ws.is_alive() or monitor.waitForAbort(1):
                    break

                progress.update(int((i / float(timeout)) * 100))

            ws.stop()
            return ws.result


def _email_password():
    email = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not email:
        return

    userdata.set('username', email)

    token = api.register_device()[0]['token']['accessToken']
    next_step = api.check_email(email, token)

    if next_step.lower() == 'register':
        raise PluginError(_.EMAIL_NOT_FOUND)

    elif next_step.lower() == 'otp':
        api.request_otp(email, token)

        while True:
            otp = gui.input(_(_.OTP_INPUT, email=email)).strip()
            if not otp:
                return

            error = api.login_otp(email, otp, token)
            if not error:
                return True

            gui.error(error)
    else:
        password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
        if not password:
            return

        api.login(email, password, token)
        return True


@plugin.route()
def select_profile(**kwargs):
    if userdata.get('kid_lockdown', False):
        return

    _select_profile()
    gui.refresh()


def _avatars(ids):
    ids = [str(value) for value in (ids or []) if value]
    if not ids:
        return {}

    avatar_key = ','.join(sorted(dict.fromkeys(ids)))
    avatars = {}
    data = api.avatar_by_id(avatar_key) or {}
    for row in data.get('avatars', []) or []:
        try:
            avatar_id = row['avatarId']
            url = (
                row['image']['tile']['1.00']['avatar']['default']['url']
            )
        except (KeyError, TypeError):
            continue
        if avatar_id and url:
            avatars[avatar_id] = (
                url + '/scale?width=300'
            )
    return avatars


def _select_profile():
    account_data = api.account(_skip_cache=True)
    account = (account_data or {}).get('account') or {}
    profiles = list(account.get('profiles') or [])
    if not profiles:
        raise PluginError('No se encontraron perfiles de Disney+')

    avatar_ids = []
    for profile in profiles:
        try:
            avatar_id = profile['attributes']['avatar']['id']
        except (KeyError, TypeError):
            avatar_id = ''
        if avatar_id:
            avatar_ids.append(avatar_id)

    avatars = _avatars(avatar_ids) if avatar_ids else {}

    options = []
    values = []
    default = -1
    active_profile = account.get('activeProfile') or {}
    active_profile_id = active_profile.get('id') or ''

    for profile_index, profile in enumerate(profiles):
        attributes = profile.get('attributes') or {}
        parental_controls = (
            attributes.get('parentalControls') or {}
        )
        avatar_data = attributes.get('avatar') or {}
        avatar_id = avatar_data.get('id') or ''
        profile['_avatar'] = avatars.get(avatar_id) or ''
        profile_name = profile.get('name') or ''
        profile_id = profile.get('id') or ''
        profile['_cleanui_is_active'] = bool(
            profile_id
            and profile_id == active_profile_id
        )

        if parental_controls.get('isPinProtected'):
            label = _(
                _.PROFILE_WITH_PIN,
                name=profile_name,
            )
        else:
            label = profile_name

        options.append(
            plugin.Item(
                label=label,
                art={'thumb': profile['_avatar']},
            )
        )
        values.append(profile)

        if profile_id and profile_id == active_profile_id:
            default = profile_index

    selected_index = gui.select(
        _.SELECT_PROFILE,
        options=options,
        preselect=default,
        useDetails=True,
    )
    if selected_index < 0:
        return False
    if selected_index >= len(values):
        return False

    return _switch_profile(
        values[selected_index],
        account_data=account_data,
    )


def _switch_profile(profile, account_data=None):
    if not profile or not profile.get('id'):
        return False
    attributes = profile.get('attributes') or {}
    parental_controls = (
        attributes.get('parentalControls') or {}
    )
    pin_protected = bool(
        parental_controls.get('isPinProtected')
    )
    pin = None
    if pin_protected:
        pin = gui.input(
            _.ENTER_PIN,
            hide_input=True,
        ).strip()
        # Cancelar el cuadro de PIN no debe intentar cambiar el perfil.
        if not pin:
            return False
    already_active = bool(
        profile.get('_cleanui_is_active')
    )
    # Los perfiles protegidos siguen pasando siempre por switchProfile para
    # que Disney+ valide el PIN. Solo se omite la petición para un perfil ya
    # activo y no protegido.
    if not already_active or pin_protected:
        api.switch_profile(
            profile['id'],
            pin=pin,
        )
    elif account_data:
        # La consulta del selector ya contiene la cuenta y sesión activas.
        api.prime_account_cache(account_data)
    if (
        settings.getBool('kid_lockdown', False)
        and attributes.get('kidsModeEnabled')
    ):
        userdata.set('kid_lockdown', True)
    else:
        # Evita conservar el bloqueo infantil después de cambiar
        # deliberadamente a un perfil normal.
        userdata.delete('kid_lockdown')

    avatar = profile.get('_avatar') or ''
    profile_name = profile.get('name') or ''
    userdata.set('avatar', avatar)
    userdata.set('profile', profile_name)
    userdata.set('profile_id', profile['id'])
    if not already_active or pin_protected:
        gui.notification(
            _.PROFILE_ACTIVATED,
            heading=profile_name,
            icon=avatar,
        )
    return True


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    userdata.delete('kid_lockdown')
    userdata.delete('avatar')
    userdata.delete('profile')
    userdata.delete('profile_id')
    gui.refresh()


# ============================================================
# Clean UI Routes
# ============================================================

@plugin.route()
def clean_ui_home(**kwargs):
    if not api.logged_in:
        return plugin.redirect(plugin.url_for(index))

    return _open_cleanui_entry()


@plugin.route()
def clean_ui_movie(deeplinkid, **kwargs):
    from slyguy import gui
    try:
        from .ui.controller import UIController
        UIController().open_movie(deeplinkid)
    except Exception as exc:
        gui.ok('Disney Clean UI - Error', 'No se pudo abrir la película.\n\n{}'.format(exc))
    return plugin.Folder(cacheToDisc=False)


@plugin.route()
def clean_ui_show(showid, **kwargs):
    from slyguy import gui
    try:
        from .ui.controller import UIController
        UIController().open_show(showid)
    except Exception as exc:
        gui.ok('Disney Clean UI - Error', 'No se pudo abrir la serie.\n\n{}'.format(exc))
    return plugin.Folder(cacheToDisc=False)


@plugin.route()
def clean_ui_season(showid, seasonid, **kwargs):
    from slyguy import gui
    try:
        from .ui.controller import UIController
        UIController().open_season(showid, seasonid)
    except Exception as exc:
        gui.ok('Disney Clean UI - Error', 'No se pudo abrir la temporada.\n\n{}'.format(exc))
    return plugin.Folder(cacheToDisc=False)


@plugin.route()
def clean_ui_search(**kwargs):
    from slyguy import gui
    try:
        from .ui.controller import UIController
        UIController().open_search()
    except Exception as exc:
        gui.ok('Disney Clean UI - Error', 'No se pudo abrir la búsqueda.\n\n{}'.format(exc))
    return plugin.Folder(cacheToDisc=False)


# ============================================================
# ALIAS CRITICO - sin esto repository.py falla en TODAS las rails
# ------------------------------------------------------------
# repository.py llama a core.parse_row / core.get_info / core.get_art,
# pero esas funciones solo existen con guion bajo (_parse_row, _get_info,
# _get_art) mas arriba en este mismo archivo. Sin este alias, cada
# llamada tira AttributeError, atrapado en silencio por los
# "except Exception: continue" de repository.py -> todas las rails
# quedan vacias y en pantalla solo se ven los botones estaticos del XML.
# ============================================================
parse_row = _parse_row
get_info = _get_info
get_art = _get_art
