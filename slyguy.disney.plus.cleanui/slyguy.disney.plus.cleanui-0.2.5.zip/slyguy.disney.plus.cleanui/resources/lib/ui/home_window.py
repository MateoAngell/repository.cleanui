"""Catalogue windows; session and playback remain owned by the existing controller."""
import traceback
import xbmc
import xbmcgui
from slyguy import userdata
from . import constants as C, effects
from .adapter import UIAdapter
from .models import Card, Screen

class HomeWindow(xbmcgui.WindowXMLDialog):
    PLATFORM = 'disney'
    TV_NAV_IDS = (3003, 3005, 3000, 3004, 3001, 3002, 3006, 3007)

    def __init__(self, *args, **kwargs):
        self.controller = kwargs.pop('controller', None)
        self.screen = kwargs.pop('screen', None)
        self.screen_kind = kwargs.pop('screen_kind', 'home')
        self._initial_loader = kwargs.pop('initial_loader', None)
        super(HomeWindow, self).__init__(*args, **kwargs)
        self._cards, self._body = {}, []
        self._activating = False
        self._last_focus_key = self._last_activation = None
        self._content_focus = None
        self._tv_offsets = {}
        self._tv_scroll = 0
        self._gallery_alarm = 'cleanui_disney_gallery'
        self._hub_screens={}
        self._history=list(getattr(self.screen,'_cleanui_history',[]))
        if self.screen is not None and hasattr(self.screen,'_cleanui_history'):
            del self.screen._cleanui_history
        if not self.controller._windows:
            self.controller._home_stack=self._history

    def onInit(self):
        try:
            effects.prepare(self)
            initial = self.screen is None and self._initial_loader
            if initial:
                self.screen = Screen(Screen.HOME,title='', rails=[])
            self._populate()
            if not self._restore_state():
                self._focus_first()
            if initial:
                self.controller.load_navigation(self, self._initial_loader,
                    lambda screen: self.replace_screen(screen, 'home'))
        except Exception:
            self._log_error('onInit')
            self.controller.end_transition()
            self.close()

    def _log_error(self, context):
        xbmc.log('[CLEANUI] {}: {}'.format(context, traceback.format_exc()), xbmc.LOGERROR)

    def _control_ids(self):
        return [3100, 4500, 4600] + [base+i for base in (4000,4200,4400) for i in range(8)]

    def _rail_control_id(self, index):
        style = UIAdapter._effective_rail_style(self.screen.rails[index], self.screen_kind)
        return (4400 if style == C.STYLE_BRAND else 4200 if style in
                (C.STYLE_LANDSCAPE,C.STYLE_EPISODE) else 4000) + index

    def _items(self, cid, cards, style):
        control = self.getControl(cid)
        control.reset()
        items, accepted = [], []
        for card in cards:
            try:
                items.append(UIAdapter.to_list_item(card, style))
                accepted.append(card)
            except Exception:
                self._log_error('card')
        control.addItems(items)
        self._cards[cid] = accepted

    def _populate(self):
        self._cards.clear()
        for cid in self._control_ids():
            self.getControl(cid).reset()
        profile = userdata.get('profile') or {}
        avatar = userdata.get('avatar','') if self.PLATFORM == 'disney' else profile.get('avatar','')
        name = profile if self.PLATFORM == 'disney' else profile.get('name','')
        values = {'screen.kind':self.screen_kind,'screen.title':self.screen.title,
                  'profile.avatar':avatar or '', 'profile.name':str(name or '')}
        if self.PLATFORM=='disney':
            values['nav.active']=str({'home':3000,'search':3005,'watchlist':3004,
                'movies':3001,'series':3002,'originals':3006}.get(self.screen_kind,3000))
            values['page.presentation']=getattr(self.screen,'page_style','')
            page_art=getattr(self.screen,'page_art',{})
            values['page.background']=page_art.get('background','')
            values['page.logo']=page_art.get('logo','')
            values['page.collapsed']='false'
        layout = getattr(self.screen,'layout','rails')
        if self.screen_kind in ('watchlist','search','episodes'):
            layout = 'grid'
        featured, filters = self.screen.featured, self.screen.filters
        if self.PLATFORM=='disney':
            hubs=getattr(self.screen,'hubs',[])
            self.setProperty('cleanui.hubs.count',str(len(hubs)))
            self.setProperty('cleanui.hubs.selected',str(getattr(self.screen,'_cleanui_selected_hub',0)))
            # Native top bar is centred; hide absent service tabs, never invent them.
            self.getControl(5110).setPosition(int((1920-172*len(hubs))/2),64)
            self.getControl(5113).setWidth(172*len(hubs))
            self.getControl(5113).setVisibleCondition('true' if hubs else 'false')
            for i in range(12):
                self.setProperty('cleanui.hub.{}.title'.format(i),hubs[i].label if i<len(hubs) else '')
                self.setProperty('cleanui.hub.{}.color'.format(i),
                    'FF333338' if i==getattr(self.screen,'_cleanui_selected_hub',0) else '00FFFFFF')
        self.setProperty('cleanui.featured.count',str(len(featured)))
        for i in range(20):
            x=(960-(len(featured)-1)*17-7+i*34 if self.PLATFORM=='disney' else
               960-len(featured)*10+i*20)
            self.getControl(4800+i).setPosition(x,600 if self.PLATFORM=='disney' else 788)
            self.getControl(4850+i).setPosition(x if self.PLATFORM=='disney' else x+6,
                                               600 if self.PLATFORM=='disney' else 794)
        values.update({'catalogue.layout':layout,'featured.visible':'true' if featured else 'false',
                       'filters.visible':'true' if filters else 'false',
                       'page.more':'true' if self.screen.continuation else 'false',
                       'catalogue.empty':'true' if not self.screen.rails and not featured else 'false'})
        for key,value in values.items():
            self.setProperty('cleanui.'+key,value)
        self._items(4600,featured,C.STYLE_LANDSCAPE)
        if self.PLATFORM=='disney':
            # A one-item wraplist otherwise repeats the same banner at the edge.
            self.getControl(4600).setWidth(1810 if len(featured)==1 else 1920)
        self._items(3100,filters,C.STYLE_BUTTON)
        if self.PLATFORM=='disney':
            self.setProperty('cleanui.filters.count',str(len(filters)))
            self.setProperty('cleanui.filters.selected',str(getattr(self.screen,'_cleanui_selected_filter',0)))
            for i in range(60):
                self.setProperty('cleanui.filter.{}.title'.format(i),filters[i].label if i<len(filters) else '')
                self.setProperty('cleanui.filter.{}.color'.format(i),
                    'FF494951' if i==getattr(self.screen,'_cleanui_selected_filter',0) else 'FF242427')
            self._filter_focus=3200+min(getattr(self.screen,'_cleanui_selected_filter',0),max(0,len(filters)-1))
        for i in range(8):
            for key,value in (('visible','false'),('style',''),('title','')):
                self.setProperty('cleanui.home.rail{}.{}'.format(i,key),value)
        if layout == 'grid':
            self._items(4500,[c for r in self.screen.rails for c in r.items],
                        C.STYLE_EPISODE if self.screen_kind == 'episodes' else
                        C.STYLE_POSTER if self.PLATFORM=='max' else C.STYLE_LANDSCAPE)
        else:
            for i,rail in enumerate(self.screen.rails[:8]):
                cards = list(rail.items)
                cid = self._rail_control_id(i)
                self._items(cid,cards,UIAdapter._effective_rail_style(rail,self.screen_kind))
                self.setProperty('cleanui.home.rail{}.visible'.format(i),'true' if cards else 'false')
                self.setProperty('cleanui.home.rail{}.style'.format(i),
                                 'brand' if cid>=4400 else 'landscape' if cid>=4200 else 'poster')
                self.setProperty('cleanui.home.rail{}.title'.format(i),rail.title)
                self.setProperty('cleanui.home.rail{}.native_style'.format(i),getattr(rail,'native_style',''))
                self.setProperty('cleanui.home.rail{}.brand_columns'.format(i),
                    next((str(n) for n in (5,6,7) if getattr(rail,'native_style','')=='brand_'+str(n)),'5'))
        self._configure_navigation()
        if self.PLATFORM=='disney':
            self._layout_tv_content()

    def _layout_tv_content(self):
        """Place finite native groups; TV anchors a focused row at y=185."""
        self._tv_offsets={}
        y=0
        presentation=getattr(self.screen,'page_style','')
        if presentation in ('high_emphasis','medium_emphasis'):
            y=636 if presentation=='high_emphasis' else 312
        elif self.screen_kind=='home':
            self.getControl(5101).setPosition(0,y)
            y+=180
        elif presentation!='immersive':
            self.getControl(5102).setPosition(0,y)
            y+=237
        if self.screen.featured:
            self.getControl(5100).setPosition(0,y)
            self._tv_offsets.update({4600:0,4800:0,4700:0,4701:0})
            y+=620
        self._tv_offsets.update({3600+i:0 for i in range(len(getattr(self.screen,'hubs',[])))})
        if self.screen.filters:
            self.getControl(5103).setPosition(0,y)
            self._tv_offsets[3100]=0
            self._tv_offsets.update({3200+i:0 for i in range(len(self.screen.filters))})
            y+=90
        if self.getProperty('cleanui.catalogue.layout')=='grid':
            self.getControl(4500).setPosition(140,y+22)
            self.getControl(4500).setHeight(max(200,1080-y-22))
            self._tv_offsets[4500]=0
            y+=802
        else:
            for i,rail in enumerate(self.screen.rails[:8]):
                cid=self._rail_control_id(i)
                if not self._cards.get(cid):
                    continue
                parent,height=((5400+i,191) if cid>=4400 else
                               (5300+i,214) if cid>=4200 else (5200+i,567))
                if cid>=4400:
                    count=int(self.getProperty('cleanui.home.rail{}.brand_columns'.format(i)) or '5')
                    height={5:172,6:140,7:119}[count]+22
                elif cid>=4200 and getattr(rail,'native_style','')=='standard_art_dense':
                    height=172
                self.getControl(parent).setPosition(0,y)
                self._tv_offsets[cid]=max(0,y-185)
                if presentation in ('high_emphasis','medium_emphasis'):
                    self._tv_offsets[cid]=0 if i==0 else y
                y+=height+127
        self.getControl(5104).setPosition(0,y)
        self.getControl(5105).setPosition(0,y)
        if self.screen.continuation:
            self._tv_offsets[4900]=max(0,y-185)
        self._tv_scroll=0
        self.getControl(5000).setPosition(0,0)

    def _scroll_tv_focus(self,cid):
        target=self._tv_offsets.get(cid)
        if target is None or target==self._tv_scroll:
            return
        previous=self._tv_scroll
        self._tv_scroll=target
        self.setProperty('cleanui.page.collapsed','true' if target else 'false')
        body=self.getControl(5000)
        body.setPosition(0,-target)
        # One native animation per row transition, never a Python animation loop.
        duration=300 if getattr(getattr(self,'screen',None),'page_style','') in ('high_emphasis','medium_emphasis') else 180
        body.setAnimations([('Conditional','effect=slide start=0,{} end=0,0 time={} '
            'tween=cubic easing=out condition=true'.format(target-previous,duration))]
            if self.getProperty('cleanui.motion')=='true' else [])

    def _configure_navigation(self):
        header = (list(self.TV_NAV_IDS) if self.PLATFORM == 'disney'
                  else [3000,3010,3011,3012,3003])
        body = [cid for cid in (4600,3100) if self._cards.get(cid)]
        if self.PLATFORM=='disney' and 3100 in body:
            body[body.index(3100)]=self._filter_focus
        if self.getProperty('cleanui.catalogue.layout') == 'grid':
            body += [4500] if self._cards.get(4500) else []
        else:
            body += [self._rail_control_id(i) for i in range(min(len(self.screen.rails),8))
                     if self._cards.get(self._rail_control_id(i))]
        if self.screen.continuation and self.PLATFORM!='disney':
            body.append(4900)
        if self.PLATFORM!='disney' and 4600 in body and len(self.screen.featured)>1:
            body.insert(body.index(4600)+1,4800)
            for i in range(len(self.screen.featured)):
                dot=self.getControl(4800+i)
                dot.controlLeft(self.getControl(4800+i-1 if i else 4700))
                dot.controlRight(self.getControl(4800+i+1 if i+1<len(self.screen.featured) else 4701))
            for cid in (4700,4701):
                self.getControl(cid).controlUp(self.getControl(header[1]))
                self.getControl(cid).controlDown(self.getControl(4800))
        for i,cid in enumerate(header):
            control = self.getControl(cid)
            if self.PLATFORM == 'disney':
                control.controlLeft(control)
                control.controlUp(self.getControl(header[max(0,i-1)]))
                control.controlDown(self.getControl(header[min(len(header)-1,i+1)]))
                hub_focus=3600<=int(self._content_focus or 0)<3600+len(getattr(self.screen,'hubs',[]))
                destination = self._content_focus if self._content_focus in body or hub_focus else body[0] if body else cid
                control.controlRight(self.getControl(destination))
            else:
                control.controlLeft(self.getControl(header[max(0,i-1)]))
                control.controlRight(self.getControl(header[min(len(header)-1,i+1)]))
                control.controlUp(control)
                control.controlDown(self.getControl(body[0] if body else cid))
        for i,cid in enumerate(body):
            control = self.getControl(cid)
            control.controlUp(self.getControl(body[i-1] if i else cid if self.PLATFORM == 'disney' else header[1]))
            control.controlDown(self.getControl(body[i+1] if i+1<len(body) else cid))
            if self.PLATFORM == 'disney':
                control.controlLeft(self.getControl(3000))
                if cid>=4000 and cid<4500:
                    index=next(i for i in range(len(self.screen.rails[:8]))
                               if self._rail_control_id(i)==cid)
                    # A self-linked Kodi fixedlist wraps; Disney TV clamps.
                    control.controlRight(self.getControl(4970+index))
        if self.PLATFORM=='disney' and body:
            start=getattr(self.screen,'_cleanui_rows_start',0)
            cached=len(getattr(self.screen,'_cleanui_all_rails',self.screen.rails))
            if (self.getProperty('cleanui.catalogue.layout')=='grid'
                    or self.screen.continuation or start+len(self.screen.rails)<cached):
                self.getControl(body[-1]).controlDown(self.getControl(4979))
            rows=[cid for cid in body if 4000<=cid<4500]
            if rows and start>0:
                self.getControl(rows[0]).controlUp(self.getControl(4969))
        self._body = body
        if self.PLATFORM=='disney' and getattr(self.screen,'hubs',[]):
            count=min(12,len(self.screen.hubs))
            for i in range(count):
                control=self.getControl(3600+i)
                control.controlLeft(self.getControl(3600+i-1 if i else 3000))
                control.controlRight(self.getControl(3600+min(i+1,count-1)))
                control.controlUp(control)
                control.controlDown(self.getControl(body[0] if body else 3600+i))
            if body:
                self.getControl(body[0]).controlUp(self.getControl(3600+getattr(self.screen,'_cleanui_selected_hub',0)))
        if self.PLATFORM=='disney' and self.screen.filters:
            index=body.index(self._filter_focus)
            for i in range(min(60,len(self.screen.filters))):
                control=self.getControl(3200+i)
                control.controlLeft(self.getControl(3200+i-1 if i else 3000))
                control.controlRight(self.getControl(3200+min(i+1,len(self.screen.filters)-1)))
                control.controlUp(self.getControl(body[index-1] if index else 3200+i))
                control.controlDown(self.getControl(body[index+1] if index+1<len(body) else 3200+i))

    def _focus_first(self):
        self.setFocusId(self._body[0] if self._body else 3000)

    def capture_state(self):
        self.screen._cleanui_window_state = dict(focus_id=self.getFocusId(),
            positions={cid:self.getControl(cid).getSelectedPosition() for cid,cards in self._cards.items() if cards})

    def _restore_state(self):
        state = getattr(self.screen,'_cleanui_window_state',None)
        if not state:
            return False
        for cid,position in state.get('positions',{}).items():
            if self._cards.get(cid):
                self.getControl(cid).selectItem(min(max(0,position),len(self._cards[cid])-1))
        cid = state.get('focus_id',3000)
        if cid in self._control_ids() and not self._cards.get(cid):
            return False
        self.setFocusId(cid)
        return True

    def reset_navigation(self):
        if self.screen_kind == 'home':
            self.screen._cleanui_window_state = None
            for cid,cards in self._cards.items():
                if cards:
                    self.getControl(cid).selectItem(0)
            self._focus_first()

    def replace_screen(self,screen,screen_kind=None):
        if not screen:
            return False
        self._gallery_clock(False)
        self.screen,self.screen_kind = screen,screen_kind or screen.screen_kind
        if self.controller._windows and self.controller._windows[0] is self:
            self.controller._home_stack=self._history
        self._populate()
        if not self._restore_state():
            self._focus_first()
        effects.animate(self,(4500,4600))
        return True

    def _selected_card(self,control_id=None,position=None):
        cid = self.getFocusId() if control_id is None else control_id
        cards = self._cards.get(cid) or []
        index = self.getControl(cid).getSelectedPosition() if position is None else position
        return cards[index] if 0 <= index < len(cards) else None

    def _refresh_hero_from_focus(self):
        # Featured content never follows focus in lower rows.
        return

    def onFocus(self,cid):
        if getattr(self, 'PLATFORM', '') == 'disney':
            if cid==4969 or 4970<=cid<=4979:
                self._continue_at_edge(cid)
                return
            start=getattr(self.screen,'_cleanui_rows_start',0)
            if start and self.screen.rails and cid==self._rail_control_id(0):
                # Re-anchor before the overlap becomes the top row: its real
                # predecessor, not the page hero, must remain above it.
                self._show_row_range(max(0,start-7),start)
                return
            self._scroll_tv_focus(cid)
            if 3200<=cid<3260 and cid-3200<len(self.screen.filters):
                old=self._filter_focus
                self._filter_focus=cid
                self._body=[cid if item==old else item for item in self._body]
                self._configure_navigation()
            self.setProperty('cleanui.nav.open', 'true' if cid in self.TV_NAV_IDS else 'false')
            if cid in self._body or 3600<=cid<3600+len(getattr(self.screen,'hubs',[])):
                self._content_focus = cid
                for nav_id in self.TV_NAV_IDS:
                    self.getControl(nav_id).controlRight(self.getControl(cid))
        self._gallery_clock(cid == 4600)
        self.controller.notify_window_focused(self)

    def _continue_at_edge(self,edge):
        """Continue in-place through the existing cancellable metadata worker."""
        if edge in range(4970,4978):
            index=edge-4970
            if index>=len(self.screen.rails):
                return
            rail=self.screen.rails[index]
            cid=self._rail_control_id(index)
            target=rail.continuation
        else:
            rail=None
            rows=[cid for cid in self._body if 4000<=cid<4500]
            cid=(rows[0] if edge==4969 and rows else self._body[-1])
            target=self.screen.continuation
        self.setFocusId(cid)
        if getattr(self,'_loading_request',None):
            return
        if edge==4969:
            start=self.screen._cleanui_rows_start
            self._show_row_range(max(0,start-7),start-1)
            return
        if edge==4979 and self.getProperty('cleanui.catalogue.layout')!='grid':
            next_row=getattr(self.screen,'_cleanui_rows_start',0)+len(self.screen.rails)
            if next_row<len(getattr(self.screen,'_cleanui_all_rails',[])):
                self._show_row_range(next_row-1,next_row)
                return
        if not target:
            return
        owner=self.screen
        position=self.getControl(cid).getSelectedPosition()
        self._paging_focus=(cid,position)
        self.controller.load_navigation(self,
            lambda:self.controller.repository.build_navigation(target),
            lambda result:self._apply_continuation(owner,cid,position,rail,result))

    def _apply_continuation(self,owner,cid,position,rail,result):
        self._paging_focus=None
        if self.screen is not owner:
            return False
        if rail is not None or self.getProperty('cleanui.catalogue.layout')=='grid':
            cards=[card for row in result.rails for card in row.items]
            style=(UIAdapter._effective_rail_style(rail,self.screen_kind) if rail is not None
                   else C.STYLE_EPISODE if self.screen_kind=='episodes' else C.STYLE_LANDSCAPE)
            # Prepare controls before committing the continuation token/model.
            items=[UIAdapter.to_list_item(card,style) for card in cards]
            self.getControl(cid).addItems(items)
            if rail is not None:
                rail.items.extend(cards)
                rail.continuation=result.continuation
            else:
                self.screen.rails.extend(result.rails)
                self.screen.continuation=result.continuation
            self._cards[cid].extend(cards)
            self._configure_navigation()
            if self.getFocusId()==cid:
                # The measured TV grid has five columns; Down preserves column.
                step=1 if rail is not None else 5
                self.getControl(cid).selectItem(min(position+step,len(self._cards[cid])-1))
            return True
        all_rows=getattr(self.screen,'_cleanui_all_rails',None)
        if all_rows is None:
            all_rows=self.screen._cleanui_all_rails=list(self.screen.rails)
            self.screen._cleanui_rows_start=0
        next_row=self.screen._cleanui_rows_start+len(self.screen.rails)
        all_rows.extend(result.rails)
        self.screen.continuation=result.continuation
        if self.getFocusId()!=cid or next_row>=len(all_rows):
            self._configure_navigation()
            return True
        self._show_row_range(next_row-1,next_row)
        return True

    def _show_row_range(self,start,focus_row):
        """Recycle eight row controls with overlap: no hero jump at a boundary."""
        screen=self.screen
        previous_start=getattr(screen,'_cleanui_rows_start',0)
        for i,rail in enumerate(screen.rails):
            rail._cleanui_selected_position=self.getControl(self._rail_control_id(i)).getSelectedPosition()
        screen._cleanui_rows_start=start
        screen.rails=screen._cleanui_all_rails[start:start+8]
        screen._cleanui_window_state=None
        self._populate()
        for i,rail in enumerate(screen.rails):
            cid=self._rail_control_id(i)
            self.getControl(cid).selectItem(min(getattr(rail,'_cleanui_selected_position',0),
                                               max(0,len(self._cards[cid])-1)))
        focus_index=focus_row-start
        cid=self._rail_control_id(focus_index)
        offsets=getattr(self,'_tv_offsets',{})
        target=offsets.get(cid,0)
        if start>previous_start and focus_index:
            self._tv_scroll=offsets.get(self._rail_control_id(focus_index-1),target)
        else:
            self._tv_scroll=target+(191 if cid>=4400 else 214 if cid>=4200 else 567)+127
        self.setFocusId(cid)

    def _gallery_clock(self, enabled=False):
        xbmc.executebuiltin('CancelAlarm({},true)'.format(self._gallery_alarm))
        if enabled and self.screen and len(self.screen.featured) > 1 and not effects.reduced():
            xbmc.executebuiltin('AlarmClock({},Control.Move(4600,1),00:08,true,loop)'.format(self._gallery_alarm))

    def _cancel_loading(self):
        previous=getattr(self,'_paging_focus',None)
        self.controller.cancel_navigation(self)
        self._paging_focus=None
        if previous:
            cid,position=previous
            self.setFocusId(cid)
            self.getControl(cid).selectItem(position)
        else:
            self._focus_first()

    def onAction(self,action):
        aid = action.getId()
        if aid in (1,2) and self.getFocusId() == 4600:
            self._gallery_clock(True)
        if aid in C.ACTION_BACK:
            self._gallery_clock(False)
            if self.PLATFORM == 'disney' and self.getFocusId() in self.TV_NAV_IDS and self._body:
                hub_focus=3600<=int(self._content_focus or 0)<3600+len(getattr(self.screen,'hubs',[]))
                self.setFocusId(self._content_focus if self._content_focus in self._body or hub_focus else self._body[0])
                return
            if getattr(self,'_loading_request',None) or self.getProperty('cleanui.load_error')=='true':
                self._cancel_loading()
                return
            if self._history:
                screen,kind = self._history.pop()
                self.replace_screen(screen,kind)
            elif self.screen_kind == 'home':
                self.controller.exit_clean_ui()
            else:
                self.controller.close_child_window(self)
        elif aid in C.ACTION_MENU:
            self._gallery_clock(False)
            self._open_menu()
        # Confirmation belongs only to onClick, never to directional actions.

    def onClick(self,cid):
        if cid==4999:
            self.controller.complete_navigation(self)
            return
        if cid==4980:
            self.controller.retry_navigation(self)
            return
        if cid==4981:
            self._cancel_loading()
            return
        if getattr(self,'_loading_request',None):
            return
        if self._activating:
            return
        self._activating = True
        self._gallery_clock(False)
        try:
            self._activate_control(cid)
        except Exception:
            self._log_error('activate')
            xbmcgui.Dialog().ok('Clean UI','No se pudo abrir. Puedes volver e intentarlo de nuevo.')
        finally:
            self._activating = False

    def _activate_control(self,cid,card=None):
        if self.PLATFORM=='disney' and 3600<=cid<3612:
            index=cid-3600
            hubs=getattr(self.screen,'hubs',[])
            if index<len(hubs) and index!=getattr(self.screen,'_cleanui_selected_hub',0):
                self.capture_state()
                self._hub_screens[getattr(self.screen,'_cleanui_selected_hub',0)]=self.screen
                cached=self._hub_screens.get(index)
                if cached is not None:
                    self._apply_hub(cached,hubs,index)
                    return
                self.controller.load_navigation(self,
                    lambda:self.controller.repository.build_navigation(hubs[index].navigation),
                    lambda screen:self._apply_hub(screen,hubs,index))
            return
        if self.PLATFORM=='disney' and 3200<=cid<3260:
            index=cid-3200
            if index<len(self.screen.filters):
                self.getControl(3100).selectItem(index)
                self._filter(self.screen.filters[index])
            return
        if 4800 <= cid < 4820:
            position = cid - 4800
            if position < len(self.screen.featured):
                self.getControl(4600).selectItem(position)
                self.setFocusId(4600)
            return
        if cid in (4700,4701):
            xbmc.executebuiltin('Control.Move(4600,{})'.format(-1 if cid == 4700 else 1))
            self.setFocusId(4600)
            return
        if cid == 3003:
            self.controller.select_profile(self) if self.PLATFORM == 'disney' else self._open_profile_menu()
        elif cid == 3007 and self.PLATFORM == 'disney':
            self._open_settings()
        elif cid == 3000 and self.PLATFORM == 'max':
            self._open_menu()
        elif cid in (3000,3010):
            self.controller._open_home_like(self.controller.repository.build_home,'home','home',self)
        elif cid in (3005,3011):
            self.controller.open_search(self)
        elif cid in (3004,3012):
            self.controller.open_watchlist(self)
        elif cid == 3001:
            self.controller.open_movies(self)
        elif cid == 3002:
            self.controller.open_series(self)
        elif cid == 3006 and self.PLATFORM == 'disney':
            self.controller._open_home_like(
                lambda:self.controller.repository._build_browse_home('originals','Originales','collection'),
                'originals','originals',self)
        elif cid == 4900:
            self._navigate(self.screen.continuation)
        else:
            card = card or self._selected_card(cid)
            if card:
                if cid == 3100:
                    self._filter(card)
                else:
                    self._open_card(card)

    def _filter(self,card):
        filters = self.screen.filters
        self.controller.load_navigation(self,
            lambda:self.controller.repository.build_navigation(card.navigation),
            lambda screen:self._apply_filter(screen,filters,card))

    def _apply_hub(self,screen,hubs,index):
        screen.hubs=hubs
        screen._cleanui_selected_hub=index
        self._hub_screens[index]=screen
        self.replace_screen(screen,'home')
        self.setFocusId(3600+index)
        return True

    def _apply_filter(self,screen,filters,card):
        screen.filters,screen.title = filters,self.screen.title
        screen._cleanui_selected_filter=filters.index(card)
        self.replace_screen(screen,self.screen_kind)
        self.setFocusId(3200+filters.index(card) if self.PLATFORM=='disney' else 3100)
        self.getControl(3100).selectItem(filters.index(card))

    def _navigate(self,target,root=False):
        return self.controller._open_home_like(lambda:self.controller.repository.build_navigation(target),
                    'home' if root and target.get('screen_kind')=='home' else 'catalogue',
                    target.get('screen_kind','collection'),self)

    def _open_card(self,card):
        if card.navigation:
            self._navigate(card.navigation)
        elif card.kind == 'page':
            self.controller.open_next_page(card,self)
        elif card.action_role == 'play' or card.kind in (C.KIND_EPISODE,C.KIND_VIDEO):
            if card.show_id and not card.season_id and card.kind == C.KIND_VIDEO and not card.action_role:
                self.controller.open_show(card.show_id)
            elif card.play_path:
                self.controller.play(card.play_path)
        elif card.kind == C.KIND_MOVIE and card.deeplink_id:
            if self.PLATFORM == 'max':
                self.controller.open_movie(card.deeplink_id,card)
            else:
                self.controller.open_movie(card.deeplink_id)
        elif card.kind == C.KIND_SHOW and card.show_id:
            self.controller.open_show(card.show_id)
        elif card.kind == C.KIND_SEASON and card.show_id and card.season_id:
            self.controller.open_season(card.show_id,card.season_id)
        elif card.browse_id:
            self.controller.open_collection(card.browse_id,card.label,self)
        else:
            raise ValueError('El servicio no entregó una acción compatible')

    def _play(self,path):
        if path:
            self.controller.play(path)

    def release_resources(self):
        self.controller.cancel_navigation(self)
        self._last_load=None
        self._gallery_clock(False)
        for cid in self._control_ids():
            try:
                self.getControl(cid).reset()
            except RuntimeError:
                pass
        self._cards.clear()
        self._hub_screens.clear()
        self.setProperty('cleanui.profile.avatar','')


    def _open_settings(self):
        """Use SlyGuy's existing categories/actions over the current window."""
        from slyguy.settings.types import Category
        history = [Category.get(0)]
        while history:
            category = history[-1]
            children = list(category.categories)
            options = children + list(category.settings)
            choice = xbmcgui.Dialog().select(category.label, [item.label for item in options])
            if choice < 0:
                history.pop()
            elif choice < len(children):
                history.append(children[choice])
            elif choice < len(options):
                options[choice].on_select()


    def _open_profile_menu(self):
        loader=getattr(self.controller,'_navigation_loader',None)
        if loader and loader.active:
            return
        choice = xbmcgui.Dialog().select('Perfil',['Cambiar perfil','Ajustes','Cerrar sesión'])
        if choice == 0:
            self.controller.select_profile(self)
        elif choice == 1:
            self._open_settings()
        elif choice == 2:
            import resources.lib.plugin as core
            self.controller.run_plugin_after_close(core.plugin.url_for(core.logout))

    def _open_menu(self):
        self._open_profile_menu()
