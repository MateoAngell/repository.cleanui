"""Presentation artwork without changing SlyGuy's playback/art interfaces."""
from urllib.parse import quote


def _url(entry, ratio, width, jpeg=False):
    if not isinstance(entry, dict):
        return ''
    # Already supplied URLs can contain signed queries. Never rewrite them.
    supplied = entry.get('url') or entry.get('imageUrl')
    if isinstance(supplied, str) and supplied.startswith(('https://', 'http://')):
        return supplied
    image_id = entry.get('imageId')
    if not isinstance(image_id, str) or not image_id:
        return ''
    # Same delivery endpoint as plugin._get_art, but preserve the actual
    # artwork bucket rather than converting a 3:1 composition into 16:9.
    return (
        'https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/'
        'disney/{}/scale?width={}&aspectRatio={}{}'
    ).format(quote(image_id, safe=''), width, ratio, '&format=jpeg' if jpeg else '')


def _select(sources, ratios, width, jpeg=False):
    for ratio in ratios:
        for source in sources:
            if isinstance(source, dict):
                url = _url(source.get(ratio), ratio, width, jpeg)
                if url:
                    return url, ratio
    return '', ''


def featured_art(raw):
    """Return independent gallery art, native ratio and title treatment.

    Kodi must fit non-3:1 fallbacks; cropping 16:9 fanart into this gallery
    loses characters. Missing data remains empty for the caller's neutral art.
    """
    visuals = raw.get('visuals') if isinstance(raw, dict) else None
    artwork = visuals.get('artwork') if isinstance(visuals, dict) else None
    artwork = artwork if isinstance(artwork, dict) else {}
    standard = artwork.get('standard') or {}
    tile = artwork.get('tile') or {}
    hero = artwork.get('hero') or {}
    standard = standard if isinstance(standard, dict) else {}
    tile = tile if isinstance(tile, dict) else {}
    hero = hero if isinstance(hero, dict) else {}
    url, ratio = _select((tile.get('background'), hero.get('background'),
                          standard.get('hero_collection'), standard.get('background'),
                          standard.get('background_details')),
                         ('3.00', '3.91', '1.78'), 1640, True)
    logo, logo_ratio = _select((standard.get('title_treatment'), standard.get('logo'),
                               hero.get('title_treatment')),
                              ('2.00', '1.78', '3.32'), 600)
    return {'url': url, 'ratio': ratio, 'fit': ratio != '3.00',
            'clearlogo': logo, 'clearlogo_ratio': logo_ratio}


def landing_art(raw, page_style):
    """Select the background composition required by the native landing style."""
    visuals = raw.get('visuals') if isinstance(raw, dict) else None
    art = visuals.get('artwork') if isinstance(visuals, dict) else None
    art = art if isinstance(art, dict) else {}
    role, ratios = {
        'high_emphasis': ('brand', ('1.78',)),
        'medium_emphasis': ('collection', ('3.00',)),
        'immersive': ('tile', ('1.78',)),
    }.get(page_style, ('', ()))
    source = art.get(role)
    brand = art.get('brand')
    source = source if isinstance(source, dict) else {}
    brand = brand if isinstance(brand, dict) else {}
    background, _ = _select((source.get('background'),), ratios, 1920, True)
    logo, _ = _select((brand.get('logo'),), ('2.00', '2.0'), 600)
    return {'background': background, 'logo': logo}


def content_metadata(raw):
    """Read native year/genre metadata, including a detail container fallback.

    premiereDate is intentionally not guessed: its exported native interface
    does not expose a verified JSON date field. No manufactured current year.
    """
    raw = raw if isinstance(raw, dict) else {}
    sources = [raw.get('visuals')]
    containers = raw.get('containers')
    if isinstance(containers, list):
        sources.extend(row.get('visuals') for row in containers
                       if isinstance(row, dict) and row.get('type') == 'details')
    year, genres, league = '', [], ''
    for visuals in sources:
        meta = visuals.get('metastringParts') if isinstance(visuals, dict) else None
        if not isinstance(meta, dict):
            continue
        years = meta.get('releaseYearRange')
        if not year and isinstance(years, dict):
            start, end = years.get('startYear'), years.get('endYear')
            start = str(start).strip() if isinstance(start, (str, int)) and not isinstance(start, bool) else ''
            end = str(end).strip() if isinstance(end, (str, int)) and not isinstance(end, bool) else ''
            year = '{}–{}'.format(start, end) if start and end and start != end else start or end
        genre = meta.get('genres')
        values = genre.get('values') if isinstance(genre, dict) else None
        if not genres and isinstance(values, list):
            genres = [value.strip() for value in values if isinstance(value, str) and value.strip()]
        sports = meta.get('sportsLeague')
        if not league and isinstance(sports, dict) and isinstance(sports.get('name'), str):
            league = sports['name'].strip()
    genre = ' / '.join(genres)
    parts = []
    # Native single-line banner metadata: preserve complete genres separately,
    # but do not overflow the title treatment with a five-genre taxonomy.
    for part in (year, league, ' / '.join(genres[:2])):
        if part and part not in parts:
            parts.append(part)
    return {'year': year, 'genre': genre, 'text': ' • '.join(parts)}
