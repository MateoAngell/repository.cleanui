from resources.lib.ui.entry import intercept_root
if not intercept_root():
    from resources.lib.plugin import plugin
    plugin.dispatch()
