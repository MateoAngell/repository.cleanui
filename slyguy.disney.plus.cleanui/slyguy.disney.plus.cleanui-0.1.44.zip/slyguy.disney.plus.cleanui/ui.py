"""Internal visual entry; original plugin routes still resolve media."""
import sys
from resources.lib.ui.entry import launch_root

if __name__ == '__main__':
    launch_root(sys.argv[1])
