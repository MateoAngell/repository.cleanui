import uuid
from time import time
from contextlib import contextmanager

from slyguy import userdata, mem_cache, log, keep_alive
from slyguy.session import Session
from slyguy.exceptions import Error

import arrow

from . import queries
from .constants import *
from .language import _
from .settings import settings


class APIError(Error):
    pass


ERROR_MAP = {
    'not-entitled': _.NOT_ENTITLED,
    'idp.error.identity.bad-credentials': _.BAD_CREDENTIALS,
    'account.profile.pin.invalid': _.BAD_PIN,
}


class API(object):
    def new_session(self):
        self._session = Session(HEADERS, timeout=30)
        self.logged_in = bool(userdata.get('refresh_token'))
        self._cache = {}
        self._applied_access_token = None
        keep_alive.register(self._set_token, hours=12, enable=self.logged_in)

    @mem_cache.cached(60*10)
    def get_config(self):
        """
        Conserva también la configuración dentro de la sesión API actual.
        mem_cache.empty() se ejecuta al cambiar de perfil, pero la
        configuración del SDK no depende del perfil y no debe descargarse
        otra vez inmediatamente.
        """
        if 'config' in self._cache:
            return self._cache['config']
        config = self._session.get(CONFIG_URL).json()
        if (
            not isinstance(config, dict)
            or not isinstance(config.get('services'), dict)
        ):
            raise APIError('Disney+ devolvió una configuración SDK inválida')
        self._cache['config'] = config
        return config

    def _transaction_id(self):
        return str(uuid.uuid4())

    @property
    def session(self):
        return self._session

    def _set_authentication(self, token):
        if not token:
            return

        if token != self._applied_access_token:
            self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
            self._applied_access_token = token
        self._session.headers.update({'x-bamsdk-transaction-id': self._transaction_id()})

    def _set_token(self, force=False):
        access_token = userdata.get('access_token')
        refresh_token = userdata.get('refresh_token')

        if (
            not force
            and access_token
            and userdata.get('expires', 0) > time()
        ):
            self._set_authentication(access_token)
            return

        if not refresh_token:
            self.logged_in = False
            raise APIError('La sesión de Disney+ no está disponible')

        self._refresh_token(refresh_token)

    def _refresh_token(self, refresh_token):
        payload = {
            'operationName': 'refreshToken',
            'variables': {
                'input': {
                    'refreshToken': refresh_token,
                },
            },
            'query': queries.REFRESH_TOKEN,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['refreshToken']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': API_KEY}).json()
        self._check_errors(data)
        self._set_auth(data['extensions']['sdk'])

    def _set_auth(self, sdk):
        self._set_authentication(sdk['token']['accessToken'])
        userdata.set('feature_flags', sdk['featureFlags'])
        userdata.set('expires', int(time() + sdk['token']['expiresIn'] - 15))
        userdata.set('access_token', sdk['token']['accessToken'])
        userdata.set('refresh_token', sdk['token']['refreshToken'])

    def register_device(self):
        self.logout()

        payload = {
            #'operationName': 'registerDevice',
            'variables': {
                'registerDevice': {
                    'applicationRuntime': 'android',
                    'attributes': {
                        'osDeviceIds': [],
                        'manufacturer': 'NVIDIA',
                        'model': 'SHIELD Android TV',
                        'operatingSystem': 'Android',
                        'operatingSystemVersion': '11',
                        'brand': 'NVIDIA'
                    },
                    'deviceFamily': 'android',
                    'deviceLanguage': 'es-419',
                    'deviceProfile': 'tv',
                    'devicePlatformId': 'android-tv',
                }
            },
            'query': queries.REGISTER_DEVICE,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['registerDevice']['href']
        resp = self._session.post(endpoint, json=payload, headers={'authorization': API_KEY})
        data = resp.json()
        self._check_errors(data)
        return data['extensions']['sdk'], resp.headers.get('x-bamtech-region')

    def check_email(self, email, token):
        payload = {
            'operationName': 'Check',
            'variables': {
                'email': email,
            },
            'query': queries.CHECK_EMAIL,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': token}).json()
        self._check_errors(data)
        return data['data']['check']['operations'][0]

    def login(self, email, password, token):
        payload = {
            'operationName': 'loginTv',
            'variables': {
                'input': {
                    'email': email,
                    'password': password,
                },
            },
            'query': queries.LOGIN,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': token}).json()
        self._check_errors(data)
        self._set_auth(data['extensions']['sdk'])

    def request_otp(self, email, token):
        payload = {
            'operationName': 'requestOtp',
            'variables': {
                'input': {
                    'email': email,
                    'reason': 'Login',
                },
            },
            'query': queries.REQUESET_OTP,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': token}).json()
        self._check_errors(data)
        return data['data']['requestOtp']['accepted']

    def login_otp(self, email, passcode, token):
        payload = {
            'operationName': 'authenticateWithOtp',
            'variables': {
                'input': {
                    'email': email,
                    'passcode': passcode,
                },
            },
            'query': queries.LOGIN_OTP,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': token}).json()
        error = self._check_errors(data, raise_on_error=False)
        if error:
            return error

        self._login_action_grant(data['data']['authenticateWithOtp']['actionGrant'], token)

    def _login_action_grant(self, action_grant, token):
        payload = {
            'operationName': 'loginWithActionGrant',
            'variables': {
                'input': {
                    'actionGrant': action_grant,
                },
            },
            'query': queries.LOGIN_ACTION_GRANT,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': token}).json()
        self._check_errors(data)
        self._set_auth(data['extensions']['sdk'])

    @contextmanager
    def device_login(self):
        from .ws import DeviceLogin # python3 only

        sdk_data, region = self.register_device()

        payload = {
            'variables': {},
            'query': queries.REQUEST_DEVICE_CODE,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload, headers={'authorization': 'Bearer {}'.format(sdk_data['token']['accessToken'])}).json()
        self._check_errors(data)
        code = data['data']['requestLicensePlate']['licensePlate']

        payload = {
            'algorithm': 'Felix',
            'application': {
                'id': 'com.disney.disneyplus',
                'name': 'Disney+',
                'version': APP_VERSION,
            },
            'device': {
                'manufacturer': 'NVIDIA',
                'model': 'SHIELD Android TV',
                'operatingSystem': 'Android v11',
                'operatingSystemVersion': '11',
            }
        }

        config = self.get_config()['services']['connectionPairing']['client']
        endpoint_name = config['extras']['regionalEndpointMapping'][region]
        endpoint = config['endpoints'][endpoint_name]['href']
        ws_data = self._session.post(endpoint, json=payload, headers={'authorization': 'Bearer {}'.format(sdk_data['token']['accessToken'])}).json()
        self._check_errors(ws_data)

        config = self.get_config()['services']['socket']['client']
        endpoint_name = config['extras']['pairedConnectionEndpointMapping'][region]
        endpoint = config['endpoints'][endpoint_name]['href']

        ws = DeviceLogin(url=endpoint, ws_data=ws_data, session_id=sdk_data['session']['sessionId'])

        try:
            ws.connect()
            yield code, ws
        finally:
            ws.stop()

        if not ws.result:
            return

        token_data = ws.token_data()
        payload = {
            'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
            'subject_token': token_data['refreshToken'],
            'subject_token_type': 'urn:ietf:params:oauth:token-type:refresh_token',
            'actor_token': sdk_data['token']['refreshToken'],
            'actor_token_type': 'urn:ietf:params:oauth:token-type:refresh_token',
            'platform': 'android-tv',
        }
        endpoint = self.get_config()['services']['token']['client']['endpoints']['exchange']['href']
        token_data = self._session.post(endpoint, data=payload, headers={'authorization': API_KEY}).json()
        self._check_errors(token_data)
        self._refresh_token(token_data['refresh_token'])

    def _check_errors(self, data, error=_.API_ERROR, raise_on_error=True):
        if not type(data) is dict:
            return

        error_msg = None
        if data.get('errors'):
            if 'extensions' in data['errors'][0]:
                code = data['errors'][0]['extensions'].get('code')
            else:
                code = data['errors'][0].get('code')

            error_msg = ERROR_MAP.get(code) or data['errors'][0].get('message') or data['errors'][0].get('description') or code
            error_msg = _(error, msg=error_msg)

        elif data.get('error'):
            error_msg = ERROR_MAP.get(data.get('error_code')) or data.get('error_description') or data.get('error_code')
            error_msg = _(error, msg=error_msg)

        elif data.get('status') == 400:
            error_msg = _(error, msg=data.get('message'))

        if error_msg and raise_on_error:
            raise APIError(error_msg)

        return error_msg

    def _json_call(self, endpoint, **kwargs):
        self._set_token()
        data = self._session.get(endpoint, **kwargs).json()
        self._check_errors(data)
        return data

    @mem_cache.cached(60*5)
    def account(self):
        self._set_token()
        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']

        payload = {
            'operationName': 'EntitledGraphMeQuery',
            'variables': {},
            'query': queries.ENTITLEMENTS,
        }

        data = self._session.post(endpoint, json=payload).json()
        self._check_errors(data)
        me = data['data']['me']
        self.prime_account_cache(me)
        return me

    def switch_profile(self, profile_id, pin=None):
        self._set_token()
        payload = {
            'operationName': 'switchProfile',
            'variables': {
                'input': {
                    'profileId': profile_id,
                },
            },
            'query': queries.SWITCH_PROFILE,
        }
        if pin:
            payload['variables']['input']['entryPin'] = str(pin)
        # Guardar la configuración antes de vaciar mem_cache. No depende del
        # perfil y no tiene sentido volver a descargarla.
        config = self.get_config()
        endpoint = config[
            'services'
        ]['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(
            endpoint,
            json=payload,
        ).json()
        self._check_errors(data)
        self._set_auth(data['extensions']['sdk'])
        switched = (
            data.get('data', {}).get('switchProfile') or {}
        )
        # El contenido, cuenta y endpoints construidos sí pueden depender del
        # perfil. Vaciar la caché compartida evita mezclar perfiles.
        mem_cache.empty()
        # Limpiar expresamente la caché local, que mem_cache.empty() no toca.
        self._cache.clear()
        self._cache['config'] = config
        # La propia mutación ya devuelve account y activeSession. Utilizarlos
        # evita una nueva consulta EntitledGraphMeQuery.
        self.prime_account_cache(switched)

    def set_imax(self, value):
        self._set_token()

        payload = {
            'variables': {
                'input': {
                    'imaxEnhancedVersion': value,
                },
            },
            'query': queries.SET_IMAX,
        }

        endpoint = self.get_config()['services']['orchestration']['client']['endpoints']['query']['href']
        data = self._session.post(endpoint, json=payload).json()
        self._check_errors(data)
        if data['data']['updateProfileImaxEnhancedVersion']['accepted']:
            self._set_auth(data['extensions']['sdk'])
            return True
        else:
            return False

    def _rebuild_endpoint_context(self):
        """Construye y cachea el contexto inmutable del endpoint."""
        profile = self._cache.get('profile')
        session = self._cache.get('session')
        if not profile or not session:
            self._cache.pop('endpoint_context', None)
            return
        portability = session.get('portabilityLocation') or {}
        location = session.get('location') or {}
        preferred = session.get('preferredMaturityRating') or {}
        attributes = profile.get('attributes') or {}
        self._cache['endpoint_context'] = {
            'apiVersion': '5.1',
            'region': (
                portability.get('countryCode')
                or location.get('countryCode')
            ),
            'impliedMaturityRating': (
                preferred.get('impliedMaturityRating')
                or 1850
            ),
            'kidsModeEnabled': (
                'true'
                if attributes.get('kidsModeEnabled')
                else 'false'
            ),
            'appLanguage': 'es-419',
            'partner': BAM_PARTNER,
        }

    def _endpoint(self, href, **kwargs):
        profile, session = self.profile()

        self._cache['basic_tier'] = 'DISNEY_PLUS_NO_ADS' not in session['entitlements']
        context = self._cache.get('endpoint_context')
        if context:
            _args = dict(context)
        else:
            region = session['portabilityLocation']['countryCode'] if session['portabilityLocation'] else session['location']['countryCode']
            maturity = session['preferredMaturityRating']['impliedMaturityRating'] if session['preferredMaturityRating'] else 1850
            kids_mode = profile['attributes']['kidsModeEnabled'] if profile else False
            app_language = 'es-419'

            _args = {
                'apiVersion': '5.1',
                'region': region,
                'impliedMaturityRating': maturity,
                'kidsModeEnabled': 'true' if kids_mode else 'false',
                'appLanguage': app_language,
                'partner': BAM_PARTNER,
            }
        _args.update(**kwargs)
        return href.format(**_args)

    def is_subscribed(self):
        # this seems to return false positive (https://github.com/matthuisman/slyguy.addons/issues/1097)
        try:
            return self.profile()[1]['isSubscriber']
        except Exception as e:
            log.warning("Failed to check subscriber due to: {}".format(e))
            return True

    def _find_active_profile(self, account):
        """Devuelve el perfil activo de una respuesta account, o None."""
        account = account or {}
        active_id = (
            (account.get('activeProfile') or {}).get('id')
            or ''
        )
        if not active_id:
            return None
        for profile in account.get('profiles') or []:
            if profile.get('id') == active_id:
                return profile
        return None

    def prime_account_cache(self, data):
        """
        Actualiza la caché local con una respuesta que contenga account y
        activeSession. Se utiliza después de consultar la cuenta y después
        de cambiar de perfil para impedir que _endpoint() siga usando el
        perfil anterior.
        """
        if not isinstance(data, dict):
            return False
        account = data.get('account') or {}
        session = data.get('activeSession')
        if session:
            self._cache['session'] = session
        else:
            self._cache.pop('session', None)
        profile = self._find_active_profile(account)
        if profile:
            self._cache['profile'] = profile
        else:
            self._cache.pop('profile', None)
        self._rebuild_endpoint_context()
        return bool(session and profile)

    def profile(self):
        session = self._cache.get('session')
        profile = self._cache.get('profile')

        if session and profile:
            return profile, session

        data = self.account() or {}
        account = data.get('account') or {}
        session = data.get('activeSession')
        if not session:
            raise APIError('Disney+ no devolvió una sesión activa')

        self._cache['session'] = session
        profile = self._find_active_profile(account)

        if not profile:
            raise APIError('Disney+ no devolvió un perfil activo')

        self._cache['profile'] = profile
        self._rebuild_endpoint_context()
        return profile, session

    @mem_cache.cached(60*60*24)
    def avatar_by_id(self, avatar_key):
        endpoint = self._endpoint(
            self.get_config()['services']['content']['client']['endpoints']['getAvatars']['href'],
            avatarIds=avatar_key,
        )
        return self._json_call(endpoint)['data']['Avatars']

    def userstates(self, pids):
        self._set_token()
        payload = {
            'pids': pids,
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getUserState']['href'], version=EXPLORE_VERSION)
        data = self._session.post(endpoint, json=payload).json()
        self._check_errors(data)
        return data['data']['entityStates']

    @mem_cache.cached(60*5)
    def deeplink(self, ref_id, ref_type='deeplinkId', action='browse'):
        params = {
            'refId': ref_id,
            'refIdType': ref_type,
            'action': action,
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getDeeplink']['href'], version=EXPLORE_VERSION)
        return self._json_call(endpoint, params=params)['data']['deeplink']

    @mem_cache.cached(60*5)
    def page(self, page_id, limit=999, enhanced_limit=0):
        params = {
            'disableSmartFocus': 'true',
            'limit': limit,
            'enhancedContainersLimit': enhanced_limit,
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getPage']['href'], version=EXPLORE_VERSION, pageId=page_id)
        return self._json_call(endpoint, params=params)['data']['page']

    @mem_cache.cached(60*5)
    def set(self, set_id, limit=100, page=1):
        params = {
            'limit': limit,
            'offset': limit*(page-1),
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getSet']['href'], version=EXPLORE_VERSION, setId=set_id)
        return self._json_call(endpoint, params=params)['data']['set']

    @mem_cache.cached(60*5)
    def season(self, season_id, limit=100, page=1):
        params = {
            'limit': limit,
            'offset': limit*(page-1),
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getSeason']['href'], version=EXPLORE_VERSION, seasonId=season_id)
        return self._json_call(endpoint, params=params)['data']['season']

    @mem_cache.cached(60*5)
    def search(self, query):
        params = {
            'query': query,
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['search']['href'], version=EXPLORE_VERSION)
        return self._json_call(endpoint, params=params)['data']['page']

    def upnext(self, content_id):
        params = {
            'contentId': content_id,
        }
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getUpNext']['href'], version=EXPLORE_VERSION)
        return self._json_call(endpoint, params=params)['data']['upNext']

    def player_experience(self, available_id):
        endpoint = self._endpoint(self.get_config()['services']['explore']['client']['endpoints']['getPlayerExperience']['href'], version=EXPLORE_VERSION, availId=available_id)
        return self._json_call(endpoint)['data']['playerExperience']

    def edit_watchlist(self, event_type, page_info, action_info):
        self._set_token()
        profile, session = self.profile()
        event_time = arrow.utcnow().format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
        payload = [{
            'data': {
                'action_info_block': action_info,
                'page_info_block': page_info,
                'event_type': event_type,
                'event_occurred_timestamp': event_time,
            },
            'datacontenttype': 'application/json;charset=utf-8',
            'subject': 'sessionId={},profileId={}'.format(session['sessionId'], profile['id']),
            'source': 'urn:dss:source:sdk:android:google:tv',
            'type': 'urn:dss:event:cs:user-content-actions:preference:v1:watchlist',
            'schemaurl': 'https://github.bamtech.co/schema-registry/schema-registry-client-signals/blob/series/0.X.X/smithy/dss/cs/event/user-content-actions/preference/v1/watchlist.smithy',
            'id': str(uuid.uuid4()),
            'time': event_time,
        }]

        endpoint = self.get_config()['services']['telemetry']['client']['endpoints']['envelopeEvent']['href']
        data = self._session.post(endpoint, json=payload).json()
        self._check_errors(data)
        return not any([x['error'] is not None for x in data])

    def remove_continue_watching(self, action_info):
        self._set_token()
        profile, session = self.profile()
        event_time = arrow.utcnow().format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
        payload = [{
            'data': {
                'action_info_block': action_info,
            },
            'datacontenttype': 'application/json;charset=utf-8',
            'subject': 'sessionId={},profileId={}'.format(session['sessionId'], profile['id']),
            'source': 'urn:dss:source:sdk:android:google:tv',
            'type': 'urn:dss:event:cs:user-content-actions:preference:v1:watch-history-preference',
            'schemaurl': 'https://github.bamtech.co/schema-registry/schema-registry-client-signals/blob/series/1.X.X/smithy/dss/cs/event/user-content-actions/preference/v1/watch-history-preference.smithy',
            'id': str(uuid.uuid4()),
            'time': event_time,
        }]

        endpoint = self.get_config()['services']['telemetry']['client']['endpoints']['envelopeEvent']['href']
        data = self._session.post(endpoint, json=payload).json()
        self._check_errors(data)
        return not any([x['error'] is not None for x in data])

    def playback(self, resource_id, wv_secure=False):
        self._set_token()
        headers = {'accept': 'application/vnd.media-service+json', 'authorization': userdata.get('access_token'), 'x-dss-feature-filtering': 'true'}

        payload = {
            "playbackId": resource_id,
            "playback": {
                "attributes": {
                    "codecs": {
                        'supportsMultiCodecMaster': False, #if true outputs all codecs and resoultion in single playlist
                    },
                    "protocol": "HTTPS",
                   # "ads": "",
                    "frameRates": [60],
                    "assetInsertionStrategy": "SGAI",
                    "playbackInitializationContext": "ONLINE"
                },
            }
        }

        video_ranges = []
        audio_types = []

        # atmos not yet supported on basic tier. Add in-case support is added
        if settings.getBool('dolby_atmos', False):
            audio_types.append('ATMOS')

        # DTSX works on both tiers
        if settings.getBool('dtsx', False):
            audio_types.append('DTS_X')

        if wv_secure and settings.getBool('dolby_vision', False):
            video_ranges.append('DOLBY_VISION')

        if wv_secure and settings.getBool('hdr10', False):
            video_ranges.append('HDR10')

        if settings.getBool('h265', False):
            payload['playback']['attributes']['codecs'] = {'video': ['h264', 'h265']}

        if audio_types:
            payload['playback']['attributes']['audioTypes'] = audio_types

        if video_ranges:
            payload['playback']['attributes']['videoRanges'] = video_ranges

        if not wv_secure:
            payload['playback']['attributes']['resolution'] = {'max': ['1280x720']}

        # Forzar identidad web para recibir catálogo es-419 (Latino)
        headers['User-Agent'] = WEB_PLAYBACK_HEADERS['User-Agent']
        headers['x-bamsdk-platform'] = WEB_PLAYBACK_HEADERS['x-bamsdk-platform']
        headers['x-bamsdk-platform-id'] = WEB_PLAYBACK_HEADERS['x-bamsdk-platform-id']
        headers['accept-language'] = WEB_PLAYBACK_HEADERS['accept-language']

        scenario = 'ctr-high' if wv_secure else 'ctr-regular'
        endpoint = self._endpoint(self.get_config()['services']['media']['client']['endpoints']['mediaPayload']['href'].format(scenario=scenario))

        playback_data = self._session.post(endpoint, headers=headers, json=payload).json()

        self._check_errors(playback_data)
        return playback_data

    def update_resume(self, media_id, fguid, playback_time):
        self._set_token()

        payload = [{
            'server': {
                'fguid': fguid,
                'mediaId': media_id,
                # 'origin': '',
                # 'host': '',
                # 'cdn': '',
                # 'cdnPolicyId': '',
            },
            'client': {
                'event': 'urn:bamtech:api:stream-sample',
                'timestamp': str(int(time()*1000)),
                'play_head': playback_time,
                # 'playback_session_id': str(uuid.uuid4()),
                # 'interaction_id': str(uuid.uuid4()),
                # 'bitrate': 4206,
            },
        }]

        endpoint = self.get_config()['services']['telemetry']['client']['endpoints']['postEvent']['href']
        return self._session.post(endpoint, json=payload).status_code

    def logout(self):
        mem_cache.empty()
        userdata.delete('access_token')
        userdata.delete('expires')
        userdata.delete('refresh_token')
        userdata.delete('feature_flags')
        self.new_session()
