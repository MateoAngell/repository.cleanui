"""Catalogue windows; session and playback remain owned by the existing controller."""
import traceback
import xbmc
import xbmcgui
from slyguy import userdata
from . import constants as C, effects
from .adapter import UIAdapter
from .models import Card, Screen

class HomeWindow(xbmcgui.WindowXMLDialog):
    PLATFORM = 'max'

    def __init__(self, *args, **kwargs):
        self.controller = kwargs.pop('controller', None)
        self.screen = kwargs.pop('screen', None)
        self.screen_kind = kwargs.pop('screen_kind', 'home')
        self._initial_loader = kwargs.pop('initial_loader', None)
        super(HomeWindow, self).__init__(*args, **kwargs)
        self._cards, self._body = {}, []
        self._activating = False
        self._last_focus_key = self._last_activation = None
        self._gallery_alarm = 'cleanui_max_gallery'
        self._history=list(getattr(self.screen,'_cleanui_history',[]))
        if self.screen is not None and hasattr(self.screen,'_cleanui_history'):
            del self.screen._cleanui_history
        if not self.controller._windows:
            self.controller._home_stack=self._history

    def onInit(self):
        try:
            effects.prepare(self)
            initial = self.screen is None and self._initial_loader
            if initial:
                self.screen = Screen(Screen.HOME,title='', rails=[])
            self._populate()
            if not self._restore_state():
                self._focus_first()
            if initial:
                self.controller.load_navigation(self, self._initial_loader,
                    lambda screen: self.replace_screen(screen, 'home'))
        except Exception:
            self._log_error('onInit')
            self.controller.end_transition()
            self.close()

    def _log_error(self, context):
        xbmc.log('[CLEANUI] {}: {}'.format(context, traceback.format_exc()), xbmc.LOGERROR)

    def _control_ids(self):
        return [3100, 4500, 4600] + [base+i for base in (4000,4200,4400) for i in range(8)]

    def _rail_control_id(self, index):
        style = UIAdapter._effective_rail_style(self.screen.rails[index], self.screen_kind)
        return (4400 if style == C.STYLE_BRAND else 4200 if style in
                (C.STYLE_LANDSCAPE,C.STYLE_EPISODE) else 4000) + index

    def _items(self, cid, cards, style):
        control = self.getControl(cid)
        control.reset()
        items, accepted = [], []
        for card in cards:
            try:
                items.append(UIAdapter.to_list_item(card, style))
                accepted.append(card)
            except Exception:
                self._log_error('card')
        control.addItems(items)
        self._cards[cid] = accepted

    def _populate(self):
        self._cards.clear()
        for cid in self._control_ids():
            self.getControl(cid).reset()
        profile = userdata.get('profile') or {}
        avatar = userdata.get('avatar','') if self.PLATFORM == 'disney' else profile.get('avatar','')
        name = profile if self.PLATFORM == 'disney' else profile.get('name','')
        values = {'screen.kind':self.screen_kind,'screen.title':self.screen.title,
                  'profile.avatar':avatar or '', 'profile.name':str(name or '')}
        layout = getattr(self.screen,'layout','rails')
        if self.screen_kind in ('watchlist','search','episodes'):
            layout = 'grid'
        featured, filters = self.screen.featured, self.screen.filters
        self.setProperty('cleanui.featured.count',str(len(featured)))
        for i in range(20):
            x=960-len(featured)*10+i*20
            self.getControl(4800+i).setPosition(x,610 if self.PLATFORM=='disney' else 788)
            self.getControl(4850+i).setPosition(x+6,616 if self.PLATFORM=='disney' else 794)
        values.update({'catalogue.layout':layout,'featured.visible':'true' if featured else 'false',
                       'filters.visible':'true' if filters else 'false',
                       'page.more':'true' if self.screen.continuation else 'false',
                       'catalogue.empty':'true' if not self.screen.rails and not featured else 'false'})
        for key,value in values.items():
            self.setProperty('cleanui.'+key,value)
        self._items(4600,featured,C.STYLE_LANDSCAPE)
        self._items(3100,filters,C.STYLE_BUTTON)
        for i in range(8):
            for key,value in (('visible','false'),('style',''),('title','')):
                self.setProperty('cleanui.home.rail{}.{}'.format(i,key),value)
        if layout == 'grid':
            self._items(4500,[c for r in self.screen.rails for c in r.items],
                        C.STYLE_EPISODE if self.screen_kind == 'episodes' else
                        C.STYLE_POSTER if self.PLATFORM=='max' else C.STYLE_LANDSCAPE)
        else:
            for i,rail in enumerate(self.screen.rails[:8]):
                cards = list(rail.items)
                if rail.continuation:
                    cards.append(Card(label='Ver más',kind=Card.COLLECTION,navigation=rail.continuation))
                cid = self._rail_control_id(i)
                self._items(cid,cards,UIAdapter._effective_rail_style(rail,self.screen_kind))
                self.setProperty('cleanui.home.rail{}.visible'.format(i),'true' if cards else 'false')
                self.setProperty('cleanui.home.rail{}.style'.format(i),
                                 'brand' if cid>=4400 else 'landscape' if cid>=4200 else 'poster')
                self.setProperty('cleanui.home.rail{}.title'.format(i),rail.title)
        self._configure_navigation()

    def _configure_navigation(self):
        header = ([3003,3000,3004,3001,3002,3006,3005] if self.PLATFORM == 'disney'
                  else [3000,3010,3011,3012,3003])
        body = [cid for cid in (4600,3100) if self._cards.get(cid)]
        if self.getProperty('cleanui.catalogue.layout') == 'grid':
            body += [4500] if self._cards.get(4500) else []
        else:
            body += [self._rail_control_id(i) for i in range(min(len(self.screen.rails),8))
                     if self._cards.get(self._rail_control_id(i))]
        if self.screen.continuation:
            body.append(4900)
        if 4600 in body and len(self.screen.featured)>1:
            body.insert(body.index(4600)+1,4800)
            for i in range(len(self.screen.featured)):
                dot=self.getControl(4800+i)
                dot.controlLeft(self.getControl(4800+i-1 if i else 4700))
                dot.controlRight(self.getControl(4800+i+1 if i+1<len(self.screen.featured) else 4701))
            for cid in (4700,4701):
                self.getControl(cid).controlUp(self.getControl(header[1]))
                self.getControl(cid).controlDown(self.getControl(4800))
        for i,cid in enumerate(header):
            control = self.getControl(cid)
            control.controlLeft(self.getControl(header[max(0,i-1)]))
            control.controlRight(self.getControl(header[min(len(header)-1,i+1)]))
            control.controlUp(control)
            control.controlDown(self.getControl(body[0] if body else cid))
        for i,cid in enumerate(body):
            control = self.getControl(cid)
            control.controlUp(self.getControl(body[i-1] if i else header[1]))
            control.controlDown(self.getControl(body[i+1] if i+1<len(body) else cid))
        self._body = body

    def _focus_first(self):
        self.setFocusId(self._body[0] if self._body else 3000)

    def capture_state(self):
        self.screen._cleanui_window_state = dict(focus_id=self.getFocusId(),
            positions={cid:self.getControl(cid).getSelectedPosition() for cid,cards in self._cards.items() if cards})

    def _restore_state(self):
        state = getattr(self.screen,'_cleanui_window_state',None)
        if not state:
            return False
        for cid,position in state.get('positions',{}).items():
            if self._cards.get(cid):
                self.getControl(cid).selectItem(min(max(0,position),len(self._cards[cid])-1))
        cid = state.get('focus_id',3000)
        if cid in self._control_ids() and not self._cards.get(cid):
            return False
        self.setFocusId(cid)
        return True

    def reset_navigation(self):
        if self.screen_kind == 'home':
            self.screen._cleanui_window_state = None
            for cid,cards in self._cards.items():
                if cards:
                    self.getControl(cid).selectItem(0)
            self._focus_first()

    def replace_screen(self,screen,screen_kind=None):
        if not screen:
            return False
        self._gallery_clock(False)
        self.screen,self.screen_kind = screen,screen_kind or screen.screen_kind
        if self.controller._windows and self.controller._windows[0] is self:
            self.controller._home_stack=self._history
        self._populate()
        if not self._restore_state():
            self._focus_first()
        effects.animate(self,(4500,4600))
        return True

    def _selected_card(self,control_id=None,position=None):
        cid = self.getFocusId() if control_id is None else control_id
        cards = self._cards.get(cid) or []
        index = self.getControl(cid).getSelectedPosition() if position is None else position
        return cards[index] if 0 <= index < len(cards) else None

    def _refresh_hero_from_focus(self):
        # Featured content never follows focus in lower rows.
        return

    def onFocus(self,cid):
        self._gallery_clock(cid == 4600)
        self.controller.notify_window_focused(self)

    def _gallery_clock(self, enabled=False):
        xbmc.executebuiltin('CancelAlarm({},true)'.format(self._gallery_alarm))
        if enabled and self.screen and len(self.screen.featured) > 1 and not effects.reduced():
            xbmc.executebuiltin('AlarmClock({},Control.Move(4600,1),00:08,true,loop)'.format(self._gallery_alarm))

    def onAction(self,action):
        aid = action.getId()
        if aid in (1,2) and self.getFocusId() == 4600:
            self._gallery_clock(True)
        if aid in C.ACTION_BACK:
            self._gallery_clock(False)
            if getattr(self,'_loading_request',None) or self.getProperty('cleanui.load_error')=='true':
                self.controller.cancel_navigation(self)
                self._focus_first()
                return
            if self._history:
                screen,kind = self._history.pop()
                self.replace_screen(screen,kind)
            elif self.screen_kind == 'home':
                self.controller.exit_clean_ui()
            else:
                self.controller.close_child_window(self)
        elif aid in C.ACTION_MENU:
            self._gallery_clock(False)
            self._open_menu()
        # Confirmation belongs only to onClick, never to directional actions.

    def onClick(self,cid):
        if cid==4999:
            self.controller.complete_navigation(self)
            return
        if cid==4980:
            self.controller.retry_navigation(self)
            return
        if cid==4981:
            self.controller.cancel_navigation(self)
            self._focus_first()
            return
        if getattr(self,'_loading_request',None):
            return
        if self._activating:
            return
        self._activating = True
        self._gallery_clock(False)
        try:
            self._activate_control(cid)
        except Exception:
            self._log_error('activate')
            xbmcgui.Dialog().ok('Clean UI','No se pudo abrir. Puedes volver e intentarlo de nuevo.')
        finally:
            self._activating = False

    def _activate_control(self,cid,card=None):
        if 4800 <= cid < 4820:
            position = cid - 4800
            if position < len(self.screen.featured):
                self.getControl(4600).selectItem(position)
                self.setFocusId(4600)
            return
        if cid in (4700,4701):
            xbmc.executebuiltin('Control.Move(4600,{})'.format(-1 if cid == 4700 else 1))
            self.setFocusId(4600)
            return
        if cid == 3003:
            self._open_profile_menu()
        elif cid == 3000 and self.PLATFORM == 'max':
            self._open_menu()
        elif cid in (3000,3010):
            self.controller._open_home_like(self.controller.repository.build_home,'home','home',self)
        elif cid in (3005,3011):
            self.controller.open_search(self)
        elif cid in (3004,3012):
            self.controller.open_watchlist(self)
        elif cid == 3001:
            self.controller.open_movies(self)
        elif cid == 3002:
            self.controller.open_series(self)
        elif cid == 3006 and self.PLATFORM == 'disney':
            self.controller._open_home_like(
                lambda:self.controller.repository._build_browse_home('originals','Originales','collection'),
                'originals','originals',self)
        elif cid == 4900:
            self._navigate(self.screen.continuation)
        else:
            card = card or self._selected_card(cid)
            if card:
                if cid == 3100:
                    self._filter(card)
                else:
                    self._open_card(card)

    def _filter(self,card):
        filters = self.screen.filters
        self.controller.load_navigation(self,
            lambda:self.controller.repository.build_navigation(card.navigation),
            lambda screen:self._apply_filter(screen,filters,card))

    def _apply_filter(self,screen,filters,card):
        screen.filters,screen.title = filters,self.screen.title
        self.replace_screen(screen,self.screen_kind)
        self.setFocusId(3100)
        self.getControl(3100).selectItem(filters.index(card))

    def _navigate(self,target,root=False):
        return self.controller._open_home_like(lambda:self.controller.repository.build_navigation(target),
                    'home' if root and target.get('screen_kind')=='home' else 'catalogue',
                    target.get('screen_kind','collection'),self)

    def _open_card(self,card):
        if card.navigation:
            self._navigate(card.navigation)
        elif card.kind == 'page':
            self.controller.open_next_page(card,self)
        elif card.action_role == 'play' or card.kind in (C.KIND_EPISODE,C.KIND_VIDEO):
            if card.show_id and not card.season_id and card.kind == C.KIND_VIDEO and not card.action_role:
                self.controller.open_show(card.show_id)
            elif card.play_path:
                self.controller.play(card.play_path)
        elif card.kind == C.KIND_MOVIE and card.deeplink_id:
            if self.PLATFORM == 'max':
                self.controller.open_movie(card.deeplink_id,card)
            else:
                self.controller.open_movie(card.deeplink_id)
        elif card.kind == C.KIND_SHOW and card.show_id:
            self.controller.open_show(card.show_id)
        elif card.kind == C.KIND_SEASON and card.show_id and card.season_id:
            self.controller.open_season(card.show_id,card.season_id)
        elif card.browse_id:
            self.controller.open_collection(card.browse_id,card.label,self)
        else:
            raise ValueError('El servicio no entregó una acción compatible')

    def _play(self,path):
        if path:
            self.controller.play(path)

    def release_resources(self):
        self.controller.cancel_navigation(self)
        self._last_load=None
        self._gallery_clock(False)
        for cid in self._control_ids():
            try:
                self.getControl(cid).reset()
            except RuntimeError:
                pass
        self._cards.clear()
        self.setProperty('cleanui.profile.avatar','')


    def _open_settings(self):
        """Use SlyGuy's existing categories/actions over the current window."""
        from slyguy.settings.types import Category
        history = [Category.get(0)]
        while history:
            category = history[-1]
            children = list(category.categories)
            options = children + list(category.settings)
            choice = xbmcgui.Dialog().select(category.label, [item.label for item in options])
            if choice < 0:
                history.pop()
            elif choice < len(children):
                history.append(children[choice])
            elif choice < len(options):
                options[choice].on_select()


    def _open_profile_menu(self):
        """Mirror Max's avatar menu using only SlyGuy-backed actions."""
        if not self.controller:
            return
        loader=getattr(self.controller,'_navigation_loader',None)
        if loader and loader.active:
            return
        from .profile_window import available_profiles
        from .choice_window import choose
        profiles = available_profiles()
        if not profiles:
            return
        options = [profile.get('profileName') or '' for profile in profiles]
        options += ['Ajustes', 'Cerrar sesión', effects.label()]
        choice = choose(self.controller.addon_path, 'Perfil', options)
        if choice < 0:
            return
        if choice == len(profiles) + 2:
            effects.toggle(self)
            return
        if choice < len(profiles):
            self.controller.select_profile(self, profiles[choice])
            return
        if choice == len(profiles):
            self._open_settings()
            return
        import resources.lib.plugin as core
        self.controller.run_plugin_after_close(core.plugin.url_for(core.logout))

    def _open_menu(self):
        loader=getattr(self.controller,'_navigation_loader',None)
        if loader and loader.active:
            return
        from .choice_window import choose
        entries = self.controller.repository.menu_entries()
        choice = choose(self.controller.addon_path,'Explorar',[entry.label for entry in entries],sidebar=True)
        if 0 <= choice < len(entries):
            self._navigate(entries[choice].navigation,root=True)
