"""Finish Kodi directory requests independently of the visual script."""
import json
import time
import uuid
from urllib.parse import quote, unquote

import xbmc
import xbmcaddon
import xbmcgui
from slyguy import plugin

RUNNING = 'MaxCleanUI.Running'
RUNNING_SINCE = 'MaxCleanUI.RunningSince'
METHODS = {'open_home', 'open_movie', 'open_show', 'open_season', 'open_search'}


def run(method, *args):
    if method not in METHODS:
        raise ValueError('Unsupported Clean UI entry')
    owner = xbmcgui.Window(10000)
    # Complete the directory request silently; the UI opens automatically.
    folder = plugin.Folder(cacheToDisc=False, no_items_label=None, show_news=False)
    active = owner.getProperty(RUNNING)
    condition = getattr(xbmc, 'getCondVisibility', lambda unused: False)
    visible = any(condition('Window.IsVisible({})'.format(window))
                  for window in (13000, 13001, 13002))
    try:
        age = time.time() - float(owner.getProperty(RUNNING_SINCE) or 0)
    except (TypeError, ValueError):
        age = 0
    if active and not visible and age > 45:
        owner.clearProperty(RUNNING)
        owner.clearProperty(RUNNING_SINCE)
        active = ''
    if active:
        return folder
    token = uuid.uuid4().hex
    owner.setProperty(RUNNING, token)
    owner.setProperty(RUNNING_SINCE, str(time.time()))
    try:
        # Open the opaque shell in this dispatch. Launching a second script
        # first leaves Kodi's plugin directory visible while it starts.
        launch(quote(json.dumps([method, args, token]), safe=''))
    except Exception:
        if owner.getProperty(RUNNING) == token:
            owner.clearProperty(RUNNING)
            owner.clearProperty(RUNNING_SINCE)
        raise
    return folder


def launch(payload):
    method, args, token = json.loads(unquote(payload))
    if method not in METHODS:
        raise ValueError('Unsupported Clean UI entry')
    owner = xbmcgui.Window(10000)
    if owner.getProperty(RUNNING) != token:
        return
    controller = None
    try:
        from resources.lib import plugin as core
        # Use the original initializer, as the plugin dispatcher does.
        core.before_dispatch()
        from .controller import UIController
        controller = UIController()
        getattr(controller, method)(*args)
    finally:
        try:
            if controller:
                controller.end_transition()
        finally:
            if owner.getProperty(RUNNING) == token:
                owner.clearProperty(RUNNING)
                owner.clearProperty(RUNNING_SINCE)
