import re
from xml.dom.minidom import parseString
import xml.etree.ElementTree as ET

from kodi_six import xbmc
from slyguy import plugin, gui, userdata, signals, inputstream, log, mem_cache
from slyguy.constants import MIDDLEWARE_PLUGIN
from slyguy.drm import is_wv_secure
from slyguy.util import replace_kids

from .api import API
from .constants import L3_MAX_HEIGHT
from .settings import settings
from .language import _

api = API()


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def index(**kwargs):
    if api.logged_in:
        # Si nunca se seleccionó perfil, forzar la selección antes de abrir la UI
        if not userdata.get('profile', {}).get('id'):
            _select_profile()
            if not (userdata.get('profile') or {}).get('id'):
                return plugin.Folder(cacheToDisc=False)
        return clean_ui_home(**kwargs)

    folder = plugin.Folder(cacheToDisc=False)
    folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


# ============================================================
# Clean UI Routes (inician la interfaz visual)
# ============================================================

@plugin.route()
def clean_ui_home(**kwargs):
    from .ui.session import run
    return run('open_home')


@plugin.route()
def clean_ui_movie(id, **kwargs):
    from .ui.session import run
    return run('open_movie', id)


@plugin.route()
def clean_ui_show(id, **kwargs):
    from .ui.session import run
    return run('open_show', id)


@plugin.route()
def clean_ui_season(show_id, season_id, **kwargs):
    from .ui.session import run
    return run('open_season', show_id, season_id)


@plugin.route()
def clean_ui_search(**kwargs):
    from .ui.session import run
    return run('open_search')


# ============================================================
# Original HBO Max routes (login, browse, play, etc.)
# ============================================================

@plugin.route()
def login(**kwargs):
    options = [
        [_.DEVICE_CODE, _device_code],
        [_.PROVIDER_LOGIN, lambda: _device_code(provider=True)],
    ]

    index = 0 if len(options) == 1 else gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    _select_profile()
    gui.refresh()


def _device_code(provider=False):
    monitor = xbmc.Monitor()
    data = api.device_code(provider)
    timeout = 600

    with gui.progress_qr(data['targetQRUrl'], _(_.DEVICE_LINK_STEPS, code=data['linkingCode'], url=data['targetUrl']), heading=_.DEVICE_CODE) as progress:
        for i in range(timeout):
            if progress.iscanceled() or monitor.waitForAbort(1):
                return

            progress.update(int((i / float(timeout)) * 100))

            if i % 5 == 0 and api.device_login():
                return True


def _find_collection(data, target_name):
    if not data or 'items' not in data:
        return None

    for item in data.get('items', []):
        if 'collection' not in item:
            continue

        sub_collection = item['collection']
        if sub_collection.get('name') == target_name:
            return sub_collection

        result = _find_collection(sub_collection, target_name)
        if result:
            return result

    return None


@plugin.route()
def watchlist(**kwargs):
    data = api.route('my-stuff')
    collection = _find_collection(data, 'my-stuff-page-rail-my-list')
    folder = plugin.Folder(_.WATCHLIST)
    folder.add_items(_process_items(collection['items'], from_watchlist=True))
    return folder


def add_menu_items(folder):
    @mem_cache.cached(60*30, key='menu_items')
    def _get_data():
        return  api.collection('web-menu-bar')

    ignore = ['search-menu-item', 'my-stuff-menu-item']
    for row in _get_data()['items']:
        if row.get('hidden') or row['collection']['name'] in ignore:
            continue

        folder.add_item(
            label = _(row['collection']['title'], _bold=True),
            path = plugin.url_for(page, route=row['collection']['items'][0]['link']['linkedContentRoutes'][0]['url'].lstrip('/'))
        )


@plugin.route()
def page(route, **kwargs):
    data = api.route(route)
    folder = plugin.Folder(data['title'])
    for row in data.get('items', []):
        if 'collection' not in row:
            continue

        if 'component' in row['collection'] and row['collection']['component'].get('id') in ('hero','tab-group'):
            folder.add_items(_process_items(row['collection'].get('items', [])))
            continue

        folder.add_item(
            label = row['collection'].get('title'),
            path = plugin.url_for(collection, id=row['collection']['id']),
        )

    return folder


@plugin.route()
@plugin.pagination()
def collection(id, page=1, **kwargs):
    data = api.collection(id, page=page)
    folder = plugin.Folder(data['title'])
    if 'items' not in data:
        return folder, False

    folder.add_items(_process_items(data['items']))
    more_pages = data['meta'].get('itemsCurrentPage', 1) < data['meta'].get('itemsTotalPages', 1)
    return folder, more_pages


@plugin.route()
@plugin.search()
def search(query, page, **kwargs):
    data = api.search(query=query, page=page)
    if 'items' not in data:
        return [], False

    more_pages = data['meta'].get('itemsCurrentPage', 1) < data['meta'].get('itemsTotalPages', 1)
    return _process_items(data['items'], from_search=True), more_pages


def _art(images, only_keys=None):
    images = {x['kind']: x for x in images if x.get('src') and x.get('kind')}
    ART_MAP = {
        'clearlogo': {'kinds': ['logo-centered', 'content-logo-monochromatic', 'logo-left'], 'url_append': '?w=600', 'valid': lambda data: data['src'].lower().endswith('png')},
        'thumb': {'kinds': ['cover-artwork-square', 'poster-with-logo', 'default', 'cover-artwork'], 'url_append': '?w=600'},
        'poster': {'kinds': ['poster-with-logo'], 'url_append': '?w=600'},
        'fanart': {'kinds': ['default', 'default-wide']},
    }
    art = {}
    for key in only_keys or ART_MAP:
        art[key] = None
        for kind in ART_MAP[key]['kinds']:
            if kind in images:
                if ART_MAP[key].get('valid', lambda x: True)(images[kind]):
                    art[key] = images[kind]['src'] + ART_MAP[key].get('url_append','')
                    break
    return art


def _process_item(row, from_search=False, from_watchlist=False):
    data = row.get('show') or row.get('video') or row.get('taxonomyNode') or row.get('link') or row.get('collection')
    if not data:
        log.warning("Unexpected data: {}".format(data))
        return None

    data['name'] = data.get('title', data['name'])
    try:
        data['name'] = re.sub(r'\([0-9]{4}\)$', '', data['name']).strip()
        data['originaltitle'] = re.sub(r'\([0-9]{4}\)$', '', data['originaltitle']).strip()
    except:
        pass

    label = data['name']
    for badge in data.get('badges', []):
        if badge['id'] == 'release-state-coming-soon':
            data['premiereDate'] = data['firstAvailableDate']
      #  label += ' [B][{}][/B]'.format(badge['displayText'])

    item = plugin.Item(
        label = label,
        info = {
            'sorttitle': data['name'],
            'originaltitle': data.get('originalName'),
            'plot': data.get('longDescription'),
            'plotoutline': data.get('description'),
            'aired': data.get('premiereDate'),
            'genre': [x['name'] for x in data.get('txGenres', [])],
        },
        art = _art(data.get('images',{})),
    )

    if data.get('primaryChannel'):
        item.info['studio'] = data['primaryChannel']['name']

    for rating in data.get('ratings', []):
        if 'mpaa' in rating['contentRatingSystem']['system'].lower():
            item.info['mpaa'] = rating['code']
            break

    # bug in hbo sometimes returns missing the edit relationship for trailer
    if 'trailerVideo' in data and 'edit' in data['trailerVideo']:
        item.info['trailer'] = plugin.url_for(play, edit_id=data['trailerVideo']['edit']['id'])

    # bug in hbo sometimes returns missing the edit relationship for episode, so link to show instead (website does same)
    if data.get('videoType') == 'EPISODE' and 'edit' not in data:
        data['showType'] = 'SERIES'
        data['id'] = data['show']['id']

    if data.get('showType') in ('SERIES', 'TOPICAL', 'MINISERIES'):
        item.info['mediatype'] = 'tvshow'
        item.path = plugin.url_for(series, id=data['id'])

    elif data.get('showType') in ('MOVIE', 'STANDALONE'):
        item.info['mediatype'] = 'movie'
        item.playable = True
        item.path = plugin.url_for(play, id=data['id'])

    elif data.get('videoType') == 'EPISODE':
        item.art = _art(data['show']['images'])
        item.art.update(_art(data['images'], only_keys=('thumb','poster')))
        item.info.update({
            'mediatype': 'episode',
            'episode': data.get('episodeNumber'),
            'season': data.get('seasonNumber'),
            'tvshowtitle': data['show']['name'],
            'duration': data['edit']['duration'] / 1000,
        })

        if from_search or from_watchlist:
            item.context.append((_.GOTO_SERIES, 'Container.Update({})'.format(plugin.url_for(series, id=data['show']['id']))))

        item.playable = True
        item.path = plugin.url_for(play, edit_id=data['edit']['id'])

    elif data.get('videoType') in ('STANDALONE_EVENT', 'CLIP', 'LIVE'):
        item.info['mediatype'] = 'video'
        item.playable = True
        item.path = plugin.url_for(play, edit_id=data['edit']['id'], _is_live=data['videoType'] == 'LIVE')

    elif row.get('collection'):
        # ignore collections without title
        if not data.get('title'):
            return None
        item.path = plugin.url_for(collection, id=row['collection']['id'])

    # elif data.get('kind') in ('genre', 'Internal Link'):
    #     #TODO
    #     return None

    else:
        #log.warning("Unexpected data: {}".format(data))
        return None

    if settings.SYNC_WATCHLIST.value:
        if from_watchlist:
            label, func = _.DELETE_WATCHLIST, delete_watchlist
        else:
            label, func = _.ADD_WATCHLIST, add_watchlist

        if data.get('showType'):
            item.context.insert(0, (label, 'RunPlugin({})'.format(plugin.url_for(func, media='show', id=data['id'], title=item.label, icon=item.art.get('poster')))))
        elif data.get('videoType'):
            item.context.insert(0, (label, 'RunPlugin({})'.format(plugin.url_for(func, media='video', id=data['id'], title=item.label, icon=item.art.get('poster')))))

    return item


@plugin.route()
def delete_watchlist(media, id, **kwargs):
    with gui.busy():
        api.edit_watchlist('remove', media=media, id=id)
    gui.refresh()


@plugin.route()
def add_watchlist(media, id, title, icon, **kwargs):
    with gui.busy():
        api.edit_watchlist('add', media=media, id=id)
    gui.notification(_.ADDED_WATCHLIST, heading=title, icon=icon)


def _process_items(rows, from_search=False, from_watchlist=False):
    items = []
    for row in rows:
        item = _process_item(row, from_search=from_search, from_watchlist=from_watchlist)
        items.append(item)
    return items


@plugin.route()
@plugin.pagination()
def series(id, page=1, season=None, **kwargs):
    data = api.series(id)
    art = _art(data['images'])
    folder = plugin.Folder(data['name'])

    if season:
        data = api.season(id, season, page=page)
        items = _process_items(data.get('items',[]))
        folder.add_items(items)
        more_pages = data['meta'].get('itemsCurrentPage', 1) < data['meta'].get('itemsTotalPages', 1)
        return folder, more_pages

    for row in sorted(data.get('seasons', []), key=lambda x: x['seasonNumber']):
        # ignore empty seasons
        if not 'videoCountByType' in row or not row['videoCountByType'].get('EPISODE'):
            continue

        folder.add_item(
            label = _(_.SEASON, number=row['displayName']),
            info = {
                'plot': row.get('longDescription') or data.get('longDescription'),
                'plotoutline': row.get('description') or data.get('description'),
                'mediatype': 'season',
                'season': row['seasonNumber'],
                'tvshowtitle': data['name'],
            },
            art = art,
            path = plugin.url_for(series, id=id, season=row['seasonNumber']),
        )
    return folder, False


@plugin.route()
def select_profile(**kwargs):
    if userdata.get('kid_lockdown', False):
        return

    _select_profile()
    gui.refresh()


def _select_profile():
    profiles = api.profiles()

    options = []
    values  = []
    default = -1

    for index, profile in enumerate(profiles):
        values.append(profile)

        profile['_avatar'] = profile['avatar']['avatarImage']['src']+'?w=300&f=webp'

        if profile.get('pinRestricted'):
            label = _(_.PROFILE_WITH_PIN, name=profile['profileName'])
        elif profile.get('ageRestricted'):
            label = _(_.PROFILE_KIDS, name=profile['profileName'])
        else:
            label = profile['profileName']

        options.append(plugin.Item(label=label, art={'thumb': profile['_avatar']}))

        if profile['id'] == userdata.get('profile',{}).get('id'):
            default = index
            _set_profile(profile, switching=False)

    index = gui.select(_.SELECT_PROFILE, options=options, preselect=default, useDetails=True)
    if index < 0:
        return
    _set_profile(values[index])


def _set_profile(profile, switching=True):
    if switching:
        pin = None
        if profile.get('pinRestricted'):
            pin = gui.input(_.ENTER_PIN, hide_input=True).strip()
        api.switch_profile(profile, pin=pin)

    if settings.KID_LOCKDOWN.value and profile.get('ageRestricted'):
        userdata.set('kid_lockdown', True)

    profile = {'id': profile['id'], 'name': profile['profileName'], 'avatar': profile['_avatar']}
    userdata.set('profile', profile)

    if switching:
        gui.notification(_.PROFILE_ACTIVATED, heading=profile['name'], icon=profile['avatar'])


@plugin.route()
@plugin.plugin_request()
def mpd_request(_data, _path, **kwargs):
    data = _data.decode('utf8')
    _log_mpd_audio_tracks(data, 'ORIGINAL')
    root = parseString(data.encode('utf8'))
    wv_secure = is_wv_secure()

    # remove bumpers (content without encryption)
    periods = root.getElementsByTagName('Period')
    new_periods = []
    for period in periods:
        protections = [elem for elem in period.getElementsByTagName('ContentProtection') if elem.getAttribute('schemeIdUri') == 'urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed']
        if not protections:
            period.parentNode.removeChild(period)
        else:
            new_periods.append(period)

    # remove all except the first period
    if len(new_periods) > 1 and not settings.ENABLE_CHAPTERS.value:
        for period in new_periods[1:]:
            period.parentNode.removeChild(period)
        # duration will be wrong now so remove it
        try: new_periods[0].removeAttribute('duration')
        except: pass

    # in case of bumper removal or merge periods - remove incorrect start
    try: new_periods[0].setAttribute('start', periods[0].getAttribute('start'))
    except: pass

    for adap_set in root.getElementsByTagName('AdaptationSet'):
        if adap_set.getAttribute('contentType') != 'video':
            continue

        # Set HDR10 flag
        for property in adap_set.getElementsByTagName('EssentialProperty'):
            if (property.getAttribute('schemeIdUri'), property.getAttribute('value')) == ('urn:mpeg:mpegB:cicp:TransferCharacteristics', '16'):
                for repr in adap_set.getElementsByTagName('Representation'):
                    repr.setAttribute('hdr', 'true')

        max_height = int(adap_set.getAttribute('maxHeight') or max(int(elem.getAttribute('height') or 0) for elem in adap_set.getElementsByTagName('Representation')))
        if max_height < L3_MAX_HEIGHT:
            continue

        protections = [elem for elem in adap_set.getElementsByTagName('ContentProtection') if elem.getAttribute('schemeIdUri') == 'urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed']
        if not protections:
            continue

        if wv_secure:
            for elem in protections:
                elem.setAttribute('xmlns:widevine', 'urn:mpeg:widevine:2013')
                wv_robust = root.createElement('widevine:license')
                wv_robust.setAttribute('robustness_level', 'HW_SECURE_CODECS_REQUIRED')
                elem.appendChild(wv_robust)
        else:
            adap_set.parentNode.removeChild(adap_set)

    # Fix of cenc pssh to only contain kids still present
    kids = []
    for elem in root.getElementsByTagName('ContentProtection'):
        kids.append(elem.getAttribute('cenc:default_KID'))

    if kids:
        for elem in root.getElementsByTagName('ContentProtection'):
            if elem.getAttribute('schemeIdUri') == 'urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed':
                for elem2 in elem.getElementsByTagName('cenc:pssh'):
                    current_cenc = elem2.firstChild.nodeValue
                    new_cenc = replace_kids(current_cenc, kids, version0=True)
                    if current_cenc != new_cenc:
                        elem2.firstChild.nodeValue = new_cenc
                        log.info('Dash Fix: cenc:pssh {} -> {}'.format(current_cenc, new_cenc))

    _log_mpd_audio_tracks(root.toprettyxml(encoding='utf-8'), 'FINAL')

    with open(_path, 'wb') as f:
        f.write(root.toprettyxml(encoding='utf-8'))


def _local_name(tag):
    return tag.rsplit('}', 1)[-1]


def _log_mpd_audio_tracks(mpd_data, stage):
    if isinstance(mpd_data, bytes):
        mpd_data = mpd_data.decode('utf-8', 'replace')

    try:
        root = ET.fromstring(mpd_data)
    except Exception as exc:
        log.warning('[CLEANUI] MPD %s: XML inválido: %s', stage, exc)
        return

    for period_index, period in enumerate(
        node for node in root.iter() if _local_name(node.tag) == 'Period'
    ):
        for adaptation_index, adaptation in enumerate(
            node for node in period if _local_name(node.tag) == 'AdaptationSet'
        ):
            representations = [
                node for node in adaptation if _local_name(node.tag) == 'Representation'
            ]

            is_audio = (
                adaptation.get('contentType') == 'audio'
                or adaptation.get('mimeType', '').startswith('audio/')
                or any(rep.get('mimeType', '').startswith('audio/') for rep in representations)
            )

            if not is_audio:
                continue

            roles = [node.get('value') for node in adaptation if _local_name(node.tag) == 'Role']
            labels = [(node.text or '').strip() for node in adaptation if _local_name(node.tag) == 'Label']

            log.info(
                '[CLEANUI] MPD %s period=%d adaptation=%d '
                'id=%s lang=%s mimeType=%s codecs=%s roles=%s labels=%s',
                stage, period_index, adaptation_index,
                adaptation.get('id'), adaptation.get('lang'),
                adaptation.get('mimeType'), adaptation.get('codecs'),
                roles, labels,
            )

            for rep in representations:
                log.info(
                    '[CLEANUI] MPD %s representation id=%s lang=%s mimeType=%s codecs=%s bandwidth=%s',
                    stage,
                    rep.get('id'), rep.get('lang'),
                    rep.get('mimeType'), rep.get('codecs'),
                    rep.get('bandwidth'),
                )


@plugin.route()
def play(id=None, edit_id=None, **kwargs):
    if id:
        edit_id = api.get_edit_id(id)

    data = api.play(edit_id)
    item = plugin.Item(
        path = data['manifest']['url'],
    )

    # Audio en español latino por defecto
    # NOTA: slyguy utiliza fix_language() que convierte cualquier español
    # no-ES a 'es-AR'. Usamos 'es-AR' para que lang_allowed() coincida.
    item.proxy_data['default_language'] = 'es-AR'

    if data.get('drm'):
        item.inputstream = inputstream.Widevine(license_key = data['drm']['schemes']['widevine']['licenseUrl'])
        item.proxy_data['middleware'] = {data['manifest']['url']: {'type': MIDDLEWARE_PLUGIN, 'url': plugin.url_for(mpd_request)}}
    else:
        item.inputstream = inputstream.MPD()

    return item


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    userdata.delete('kid_lockdown')
    userdata.delete('profile')
    gui.refresh()


# ============================================================
# ALIAS CRITICOS - sin esto repository.py falla en TODAS las rails
# ------------------------------------------------------------
# repository.py llama a core.parse_row / core.get_art.
# Estas funciones existen con guion bajo (_process_item, _art)
# mas arriba en este mismo archivo.
# ============================================================
parse_row = _process_item
get_art = _art
