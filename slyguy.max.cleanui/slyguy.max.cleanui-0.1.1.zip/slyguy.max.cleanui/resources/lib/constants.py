BASE_URL = 'https://default.any-any.prd.api.discomax.com'
CLIENT_ID = 'b6746ddc-7bc7-471f-a16c-f6aaf0c34d26'
SITE_ID = 'beam'
BRAND_ID = 'beam'
REALM = 'bolt'
APP_VERSION_URL = 'https://i.mjh.nz/.apk/max.version'
APP_VERSION_FALLBACK = '5.12.0.71'
PAGE_SIZE = 50
L3_MAX_HEIGHT = 580  #TODO: confirm actual limit for L3 or find better way (cenc data / lowest quality set?)

# Constante requerida por ui.adapter.py (HBO Max no tiene continue watching)
CONTINUE_WATCHING_ID = ''
