"""Run the existing script-library entry, never open a plugin directory."""
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

TARGETS = {
    'disney': 'slyguy.disney.plus.cleanui',
    'max': 'slyguy.max.cleanui',
}


def launch(platform):
    addon_id = TARGETS.get(platform)
    if not addon_id:
        return False
    try:
        addon = xbmcaddon.Addon(addon_id)
        if not xbmcvfs.exists(addon.getAddonInfo('path').rstrip('/\\') + '/ui.py'):
            raise RuntimeError('Entry unavailable')
    except (RuntimeError, ValueError):
        xbmcgui.Dialog().ok('Clean UI', 'Instala o actualiza el add-on desde tu repositorio Clean UI.')
        return False
    # Kodi selects the existing xbmc.python.library entry ui.py. Its own
    # session owner prevents duplicate UI launches; do not introduce a timer.
    xbmc.executebuiltin('RunScript({})'.format(addon_id))
    return True


if __name__ == '__main__':
    launch(sys.argv[1] if len(sys.argv) == 2 else '')
