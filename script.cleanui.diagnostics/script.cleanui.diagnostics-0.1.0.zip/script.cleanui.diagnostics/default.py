"""Remote-friendly manual capture; the worker runs only after explicit start."""
import json
import time
import uuid
import xbmc
import xbmcaddon
import xbmcgui
from core import ACTIVE, STOP, BEAT, folder, snapshot, recording, report, export


def main():
    dialog = xbmcgui.Dialog()
    choice = dialog.select('Clean UI Diagnóstico', [
        'Estado actual', 'Iniciar registro (máximo 2 horas)',
        'Detener y generar informe', 'Exportar informe privado'])
    home = xbmcgui.Window(10000)
    if choice == 0:
        state = snapshot(True)
        (folder() / 'state.json').write_text(json.dumps(state), encoding='utf-8')
        dialog.textviewer('Estado actual (null = no disponible)', json.dumps(state, indent=2, ensure_ascii=False))
    elif choice == 1:
        if recording():
            dialog.ok('Diagnóstico', 'Ya hay un registro activo.')
            return
        if not dialog.yesno('Registro privado', 'Recogerá datos técnicos cada 5 segundos, sin enviarlos.\n'
                            'No cambia la configuración. Reproduce el fallo y vuelve aquí para detenerlo.\n¿Iniciar?'):
            return
        token = uuid.uuid4().hex
        home.setProperty(ACTIVE, token)
        home.setProperty(BEAT, str(time.time()))
        home.clearProperty(STOP)
        addon = xbmcaddon.Addon('script.cleanui.diagnostics')
        path = addon.getAddonInfo('path').rstrip('/\\') + '/worker.py'
        xbmc.executebuiltin('RunScript("{}",{})'.format(path, token), False)
        dialog.notification('Diagnóstico', 'Registro iniciado; vuelve para detener y exportar.')
    elif choice == 2:
        if recording():
            home.setProperty(STOP, home.getProperty(ACTIVE))
            monitor = xbmc.Monitor()
            for _ in range(14):
                if not recording() or monitor.waitForAbort(0.5):
                    break
            if recording():
                dialog.ok('Diagnóstico', 'Detención solicitada. Espera unos segundos antes de exportar.')
                return
        report()
        dialog.ok('Diagnóstico', 'Informe guardado en Kodi. Usa Exportar informe privado.')
    elif choice == 3:
        export()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        xbmcgui.Dialog().ok('Diagnóstico', 'No se pudo completar. No se cambió ninguna configuración.')
