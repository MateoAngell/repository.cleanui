# Clean UI Diagnóstico

Instalar desde el repositorio Clean UI, en Complementos de programas.

1. Abrir **Clean UI Diagnóstico → Iniciar registro** y confirmar. No cambia Kodi.
2. Abrir Disney o Max y reproducir hasta observar el problema. Anotar hora y título por separado.
3. Volver al diagnóstico → **Detener y generar informe → Exportar**.
4. Elegir una carpeta privada existente de la laptop (SMB/NFS) o un USB accesible desde Kodi.
   Si no aparece, añadir primero esa ubicación desde el administrador de archivos de Kodi.
   No crear una carpeta pública ni compartir el informe con desconocidos.
5. Adjuntar aquí `cleanui-diagnostico-fecha-hora.zip`. No publicarlo en GitHub.

Si Kodi se bloquea: después de reiniciarlo, abrir diagnóstico y generar/exportar.
Las muestras se guardan cada cinco segundos. Una sesión interrumpida conserva
`status: recording`: significa que no pudo registrar su cierre, no que siga activa.
No borrar caché ni reinstalar antes de exportar: se puede perder evidencia.

Repetir con un mismo título en SlyGuy original y Clean UI, manteniendo la configuración.
El complemento no hace pruebas de velocidad durante el vídeo y no mide temperaturas,
señal Wi-Fi o procesos Android. CPU y memoria pueden ser del sistema; `null` significa
que Kodi no expone ese dato. El informe no determina automáticamente la causa.

Los registros saneados incluyen únicamente componentes del reproductor y contadores
de Clean UI. Sin títulos, credenciales, URLs de reproducción, capturas ni carpetas
de cuenta. No hay envío automático a Internet. La carpeta de exportación queda
guardada solo localmente y nunca se incluye en el ZIP.

Si hace falta un registro más detallado, activar manualmente el registro de depuración
de Kodi antes de una prueba corta y desactivarlo después. La herramienta no lo activa.

Límites: una grabación activa, cinco segundos entre muestras, dos horas por sesión;
dos archivos circulares de cuatro MiB y extractos de log de hasta un MiB. No existe
servicio residente: al terminar, el trabajador sale.
