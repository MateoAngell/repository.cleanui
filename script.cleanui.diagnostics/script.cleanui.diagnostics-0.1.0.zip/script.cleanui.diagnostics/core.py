"""Private, read-only Kodi diagnostics. No outgoing HTTP or credential files."""
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = 'script.cleanui.diagnostics'
ACTIVE = 'cleanui.diagnostics.owner'
STOP = 'cleanui.diagnostics.stop'
BEAT = 'cleanui.diagnostics.heartbeat'
LIMIT = 4 * 1024 * 1024  # Two journal segments, plus <=1 MiB of log extracts.
SETTING_KEYS = (
    'audiooutput.channels', 'audiooutput.passthrough', 'audiooutput.ac3passthrough',
    'audiooutput.ac3transcode', 'audiooutput.eac3passthrough',
    'videoplayer.usedisplayasclock', 'videoplayer.adjustrefreshrate',
    'videoplayer.usemediacodec', 'videoplayer.usemediacodecsurface',
    'filecache.memorysize', 'filecache.readfactor', 'filecache.buffermode',
)
LABELS = (
    'System.CpuUsage', 'System.Memory(free)', 'System.Memory(used)',
    'System.Memory(total)', 'System.FPS', 'System.ScreenWidth', 'System.ScreenHeight',
    'Player.CacheLevel', 'Player.Progress', 'Player.Time', 'Player.Duration',
    'VideoPlayer.VideoCodec', 'VideoPlayer.VideoResolution', 'VideoPlayer.VideoAspect',
    'VideoPlayer.AudioCodec', 'VideoPlayer.AudioChannels', 'VideoPlayer.AudioLanguage',
    'VideoPlayer.VideoDecoder', 'VideoPlayer.DroppedFrames',
    'Network.LinkState', 'System.InternetState',
)
SENSITIVE = re.compile(r'authorization|cookie|password|passwd|secret|token|license|licence|pssh|\bdrm\b|profile|userdata|email', re.I)
SAFE_COMPONENT = re.compile(r'\[CLEANUI\]\[RESOURCES\]|CVideoPlayer|VideoPlayer::|CDVD|ffmpeg|CActiveAE|CMMAL|CCodec|CRender|mediacodec', re.I)


def folder():
    root = Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON).getAddonInfo('profile')))
    root.mkdir(parents=True, exist_ok=True)
    return root


def rpc(method, params=None):
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}})))
        return result.get('result')
    except (ValueError, TypeError, RuntimeError):
        return None


def sanitize_line(line):
    """Fail closed: only component diagnostics, never arbitrary addon output."""
    if SENSITIVE.search(line) or not SAFE_COMPONENT.search(line):
        return None
    if len(line) > 2000:
        return None
    line = re.sub(r'(?:https?|plugin|smb|special|file|image)://\S+', '<url>', line, flags=re.I)
    line = re.sub(r'[A-Za-z]:[\\/][^\r\n]*|/(?:storage|sdcard|data|home|Users)/[^\r\n]*', '<path>', line)
    line = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '<address>', line)
    line = re.sub(r'\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b', '<email>', line)
    line = re.sub(r'\b[A-Za-z0-9_+/=-]{32,}\b', '<identifier>', line)
    # Quoted free-form strings may contain titles, account/device names.
    line = re.sub(r'([\"\']).*?\1', '<text>', line)
    # Do not export the remaining free text either: it can contain an
    # unquoted account/device/title. Preserve diagnostic signals, not names.
    stamp = re.match(r'\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?', line)
    prefix = (stamp.group(0) + ' ') if stamp else ''
    if '[CLEANUI][RESOURCES]' in line:
        summary = re.search(r'(window_open|window_closed|before_playback|after_playback) windows=\d+ screens=\d+ cards=\d+ threads=\d+ cache=\d+', line)
        return prefix + '[CLEANUI][RESOURCES] ' + summary.group(0) + '\n' if summary else None
    component = SAFE_COMPONENT.search(line).group(0)
    signals = re.findall(r'\b(?:error|warning|buffer|buffering|underrun|timeout|timed out|failed|failure|decoder|dropped|stalled|stopped|paused|resumed|eac3|ac3|aac|h264|hevc|vp9|av1)\b', line, re.I)
    codes = re.findall(r'\b(?:errno|status|code)\s*[:=]\s*-?\d{1,6}\b', line, re.I)
    if not signals and not codes:
        return None
    return prefix + component + ' ' + ' '.join(dict.fromkeys(s.lower() for s in signals)) + ' ' + ' '.join(codes) + '\n'


def snapshot(configuration=False):
    start = time.monotonic()
    values = {}
    for label in LABELS:
        raw = xbmc.getInfoLabel(label)
        # Only numeric/codec labels are requested. Reject URLs/unexpected text.
        values[label] = raw if raw and len(raw) < 100 and re.fullmatch(r'[\w .,%:/+()-]+', raw) and '://' not in raw else None
    owner = xbmcgui.Window(10000)
    ui = {}
    for addon in ('slyguy.max.cleanui', 'slyguy.disney.plus.cleanui'):
        raw = owner.getProperty('cleanui.resources.' + addon)
        try:
            data = json.loads(raw)
            stage = data.get('stage')
            ui[addon] = {'stage': stage if stage in ('window_open', 'window_closed', 'before_playback', 'after_playback') else None}
            ui[addon].update({key: data.get(key) if isinstance(data.get(key), (int, float)) else None
                             for key in ('windows', 'screens', 'cards', 'threads', 'cache', 'time')})
        except (ValueError, TypeError):
            ui[addon] = None
    result = {'time': time.time(), 'labels': values, 'cleanui': ui,
              'playing': bool(xbmc.getCondVisibility('Player.HasVideo')),
              'paused': bool(xbmc.getCondVisibility('Player.Paused')),
              'caching': bool(xbmc.getCondVisibility('Player.Caching'))}
    players = rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if p.get('type') == 'video'), None)
    if video:
        result['player'] = rpc('Player.GetProperties', {'playerid': video['playerid'],
            'properties': ['speed', 'time', 'totaltime', 'percentage', 'cachepercentage']})
    if configuration:
        result['application'] = rpc('Application.GetProperties', {'properties': ['version']})
        result['system'] = {'android': xbmc.getCondVisibility('System.Platform.Android'),
                            'windows': xbmc.getCondVisibility('System.Platform.Windows')}
        result['components'] = {}
        for addon in ('slyguy.max.cleanui', 'slyguy.disney.plus.cleanui', 'script.module.slyguy', 'inputstream.adaptive', 'script.module.inputstreamhelper'):
            try:
                result['components'][addon] = xbmcaddon.Addon(addon).getAddonInfo('version')
            except RuntimeError:
                result['components'][addon] = None
        result['settings'] = {}
        for key in SETTING_KEYS:
            value = rpc('Settings.GetSettingValue', {'setting': key})
            result['settings'][key] = value.get('value') if isinstance(value, dict) else None
        result['advanced_cache'] = cache_settings()
        result['limitations'] = ['null significa no disponible',
            'CPU/memoria pueden ser del sistema, no del proceso Kodi',
            'sin medición de velocidad, señal Wi-Fi, temperatura ni procesos Android',
            'sin credenciales, títulos, direcciones de red ni archivos de cuenta']
    result['sample_ms'] = round((time.monotonic() - start) * 1000, 3)
    return result


def cache_settings():
    result = {}
    path = Path(xbmcvfs.translatePath('special://profile/advancedsettings.xml'))
    if not path.exists() or path.stat().st_size > 1024 * 1024:
        return result
    try:
        root = ET.fromstring(path.read_bytes())
        for key in ('buffermode', 'memorysize', 'readfactor', 'cachemembuffersize'):
            value = root.findtext('./cache/' + key) or root.findtext('./network/' + key)
            if value and re.fullmatch(r'\d+(?:\.\d+)?', value.strip()):
                result[key] = value.strip()
    except (OSError, ET.ParseError):
        result['read_error'] = True
    return result


class Journal:
    def __init__(self, root, limit=LIMIT):
        self.path = root / 'samples.jsonl'
        self.previous = root / 'samples.previous.jsonl'
        self.limit = limit
        self.lock = threading.Lock()

    def write(self, value):
        data = (json.dumps(value, ensure_ascii=True) + '\n').encode('utf-8')
        if len(data) > self.limit:
            return
        with self.lock:
            if self.path.exists() and self.path.stat().st_size + len(data) > self.limit:
                os.replace(str(self.path), str(self.previous))
            with self.path.open('ab') as stream:
                stream.write(data)


def log_extract(name):
    path = Path(xbmcvfs.translatePath('special://logpath/' + name))
    if not path.exists():
        return 'Registro no disponible.\n'
    with path.open('rb') as stream:
        stream.seek(max(0, path.stat().st_size - 512 * 1024))
        tail = stream.read(512 * 1024).decode('utf-8', errors='replace')
    return ''.join(filter(None, (sanitize_line(line) for line in tail.splitlines()[1:])))


def report():
    root = folder()
    (root / 'state.json').write_text(json.dumps(snapshot(True)), encoding='utf-8')
    result = root / 'latest-report.zip'
    temp = root / 'report.tmp.zip'
    with zipfile.ZipFile(temp, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in ('samples.previous.jsonl', 'samples.jsonl', 'session.json', 'state.json'):
            path = root / name
            if path.exists():
                archive.write(path, name)
        for name in ('kodi.log', 'kodi.old.log'):
            archive.writestr(name, log_extract(name))
        archive.writestr('LEEME.txt', 'Informe privado y saneado. Sin envío automático.\n'
            'Las muestras no disponibles son null. El informe no identifica por sí solo la causa.\n'
            'Sesiones interrumpidas: conservar el informe y anotar la hora del fallo.\n')
    os.replace(str(temp), str(result))
    return result


def recording():
    home = xbmcgui.Window(10000)
    try:
        return bool(home.getProperty(ACTIVE)) and time.time() - float(home.getProperty(BEAT)) < 30
    except ValueError:
        return False


def release(token):
    home = xbmcgui.Window(10000)
    if home.getProperty(ACTIVE) == token:
        for key in (ACTIVE, BEAT, STOP):
            home.clearProperty(key)


def record(token):
    home = xbmcgui.Window(10000)
    if home.getProperty(ACTIVE) != token:
        return
    root = folder()
    writer = Journal(root)
    monitor = xbmc.Monitor()
    session = {'started': time.time(), 'status': 'recording', 'interval_seconds': 5, 'maximum_seconds': 7200}
    (root / 'session.json').write_text(json.dumps(session), encoding='utf-8')
    writer.write({'event': 'start', 'snapshot': snapshot(True)})

    class Events(xbmc.Player):
        def event(self, name):
            writer.write({'time': time.time(), 'event': name})
        def onAVStarted(self): self.event('av_started')
        def onPlayBackStarted(self): self.event('started')
        def onPlayBackPaused(self): self.event('paused')
        def onPlayBackResumed(self): self.event('resumed')
        def onPlayBackStopped(self): self.event('stopped')
        def onPlayBackEnded(self): self.event('ended')
        def onPlayBackError(self): self.event('error')

    observer = Events()
    started = time.monotonic()
    try:
        while not monitor.abortRequested() and time.monotonic() - started < 7200:
            if home.getProperty(ACTIVE) != token or home.getProperty(STOP) == token:
                break
            home.setProperty(BEAT, str(time.time()))
            writer.write({'event': 'sample', 'snapshot': snapshot()})
            if monitor.waitForAbort(5):
                break
        session['status'] = 'interrupted' if monitor.abortRequested() else 'finished'
    except Exception:
        session['status'] = 'capture_error'
    finally:
        del observer
        session['finished'] = time.time()
        (root / 'session.json').write_text(json.dumps(session), encoding='utf-8')
        release(token)
        if not monitor.abortRequested():
            report()


def export():
    if recording():
        xbmcgui.Dialog().ok('Diagnóstico', 'Primero detén el registro.')
        return
    root = folder()
    config = root / 'export-target.json'
    try:
        target = json.loads(config.read_text(encoding='utf-8'))['folder']
    except (OSError, ValueError, KeyError):
        target = xbmcgui.Dialog().browse(0, 'Carpeta privada: laptop o USB', 'files')
    if not target:
        target = xbmcgui.Dialog().browse(0, 'Carpeta privada: laptop o USB', 'files')
    if not target:
        return
    if re.match(r'^[a-z]+://', target, re.I) and not target.lower().startswith(('smb://', 'nfs://', 'special://')):
        xbmcgui.Dialog().ok('Diagnóstico', 'Elige una carpeta local, USB o compartida; no un servicio web.')
        return
    source = report()
    name = 'cleanui-diagnostico-' + time.strftime('%Y%m%d-%H%M%S') + '.zip'
    destination = target.rstrip('/\\') + '/' + name
    if xbmcvfs.exists(destination) or not xbmcvfs.copy(str(source), destination):
        config.write_text(json.dumps({'folder': ''}), encoding='utf-8')
        xbmcgui.Dialog().ok('Diagnóstico', 'No se pudo copiar. El informe sigue guardado en Kodi.')
        return
    config.write_text(json.dumps({'folder': target}), encoding='utf-8')
    xbmcgui.Dialog().ok('Diagnóstico', 'Exportado: ' + name + '\nAdjunta ese ZIP en el chat; no lo publiques en GitHub.')
